# project2
该项目的基础配置SSM已经配置完成 请基于该项目开发

# 2019.12.25 21:10
提交修改：增加了json返回时间格式为yyyy-MM-dd HH:mm:ss

后台管理用户模块已经完成请测试

请修改mall-admin 下config的 dev.env.js 下的链接改为
http://localhost:8080/admin

修改src目录下api中的user.js：在每个请求前添加/user

如 /user/list修改为/user/user/list …… 整个文件的请求都需要修改

# 2019 12.27 上午会议纪要及进度更新

    * 刘晓涛
    完成行政区域的多级查询及返回
    今天目标完成商场管理模块
    * 张小林
    目前正在研究如何写
    今天目标两个接口
    * 肖晨暘
    已经完成大部分系统管理接口
    今天目标基本完成系统管理接口
    * 刘玉
    完成了推广管理的广告和优惠券管理
    今天目标完成推广管理
    * 陈雪松
    完成了配置管理模块
    今天目标 完成统计报表
    * 何永斌
    配置了部分shiro 完成了图片上传到阿里云oos接口
    今天目标 督促组员完成他们的目标
# 2019 12.27 更新
    解决了图片上传冲突 完成了回调以及保存到数据库
    所有图片上传接口均不用再写
    图片上传接口在controller下的 image_upload_hyb
    修改了部分mapper.xml
    若发现mapper.xml有字段是关键字 请修改后提交

# 2019 12.28 会议记录

    刘晓涛：
        完成 商场管理----品牌制造商 功能
        包括品牌商信息为空异常的处理
        品牌商名字重复异常的处理
    陈雪松：
        完成【配置管理】模块，并加入声明式参数校验
    张小林：
        写了如下接口：
        goods/list
        goods/delete
        goods/update
        comment/list
        comment/delete；
        
        遇到的问题：多表查询问题 
        
        明日任务：完成商品列表的剩下3个接口
    肖晨旸：
        基本完成系统管理
        异常处理已经完成部分
        
        今日完成授权
    刘玉：
        开始优惠券管理模块
        已经完成几个接口
        
        今日完成大部分接口
    何永斌：
        修正了几个无关紧要的小BUG
        提高了用户登录超时时间
        解决了不能logout问题
        创建了授权列表可供查询
        
    今日小组目标：解决商品添加 查询 编辑中的多表查询和事务 
                添加登录日志及权限操作日志 使用AOP进行日志管理
               
# 2019 12/28 更新
    系统配置、系统管理、用户管理、三个模块基本完成可以进行测试
    
    请修改前端文件：
        前端更改：将src/api/brand.js  中url前面全部添加/brand
        time: 12-27
            admin.js:
                listAdmin(query)→url: '/system/admin/list' 添加寻找功能
                createAdmin(data) url: '/system/admin/create' 完善创建功能
                updateAdmin(data) url: '/system/admin/update' 更新管理员
                deleteAdmin(data) url: '/system/admin/delete' 删除管理员
                
            log.js
                listLog(query) url: '/system/log/list' 查找对应日志
                
            role.js:
                listRole(query)→url: '/system/role/list' 获取对应的role
                createRole(data) url: '/system/role/create' 创建role
                updateRole(data) url: '/system/role/update' 更新role
                deleteRole(data) url: '/system/role/delete' 删除role
            storage.js:
                listStorage(query)→url: '/system/storage/list' 搜索图片
                updateStorage(data) url: '/system/storage/update' 更新图片名称
                deleteStorage(data) url: '/system/storage/delete' 删除图片

# 2019 12.31 会议纪要
    开启微信端：
        负责接口：
            刘晓涛：购物车
                    完成     CartList: WxApiRoot + 'cart/index', //获取购物车的数据
                    完成     CartAdd: WxApiRoot + 'cart/add', // 添加商品到购物车
                            CartFastAdd: WxApiRoot + 'cart/fastadd', // 立即购买商品
                            CartUpdate: WxApiRoot + 'cart/update', // 更新购物车的商品
                            CartDelete: WxApiRoot + 'cart/delete', // 删除购物车的商品
                            CartChecked: WxApiRoot + 'cart/checked', // 选择或取消选择商品
                            CartGoodsCount: WxApiRoot + 'cart/goodscount', // 获取购物车商品件数
                            CartCheckout: WxApiRoot + 'cart/checkout', // 下单前信息确认
            刘玉：
                    完成    AddressList: WxApiRoot + 'address/list', //收货地址列表
                    完成    AddressDetail: WxApiRoot + 'address/detail', //收货地址详情
                            AddressSave: WxApiRoot + 'address/save', //保存收货地址
                            AddressDelete: WxApiRoot + 'address/delete', //保存收货地址
                              
                            ExpressQuery: WxApiRoot + 'express/query', //物流查询
                              
                            RegionList: WxApiRoot + 'region/list', //获取区域列表
                              
                            
                            FeedbackAdd: WxApiRoot + 'feedback/submit', //添加反馈
                            FootprintList: WxApiRoot + 'footprint/list', //足迹列表
                            FootprintDelete: WxApiRoot + 'footprint/delete', //删除足迹
                              
                            UserFormIdCreate: WxApiRoot + 'formid/create', //用户FromId，用于发送模版消息
            张小林：
                    完成     CollectList: WxApiRoot + 'collect/list', //收藏列表
                            CollectAddOrDelete: WxApiRoot + 'collect/addordelete', //添加或取消收藏
                                           
                            CommentList: WxApiRoot + 'comment/list', //评论列表
                            CommentCount: WxApiRoot + 'comment/count', //评论总数
                            CommentPost: WxApiRoot + 'comment/post', //发表评论
                                           
                            TopicList: WxApiRoot + 'topic/list', //专题列表
                            TopicDetail: WxApiRoot + 'topic/detail', //专题详情
                            TopicRelated: WxApiRoot + 'topic/related', //相关专题
                                           
                            SearchIndex: WxApiRoot + 'search/index', //搜索关键字
                            SearchResult: WxApiRoot + 'search/result', //搜索结果
                            SearchHelper: WxApiRoot + 'search/helper', //搜索帮助
                            SearchClearHistory: WxApiRoot + 'search/clearhistory', //搜索历史清楚
            陈雪松：
                            OrderSubmit: WxApiRoot + 'order/submit', // 提交订单
                            OrderPrepay: WxApiRoot + 'order/prepay', // 订单的预支付会话
                   完成      OrderList: WxApiRoot + 'order/list', //订单列表
                            OrderDetail: WxApiRoot + 'order/detail', //订单详情
                            OrderCancel: WxApiRoot + 'order/cancel', //取消订单
                            OrderRefund: WxApiRoot + 'order/refund', //退款取消订单
                            OrderDelete: WxApiRoot + 'order/delete', //删除订单
                            OrderConfirm: WxApiRoot + 'order/confirm', //确认收货
                            OrderGoods: WxApiRoot + 'order/goods', // 代评价商品信息
                            OrderComment: WxApiRoot + 'order/comment', // 评价订单商品信息
                              
            肖晨旸：
                            GroupOnList: WxApiRoot + 'groupon/list', //团购列表
                            GroupOn: WxApiRoot + 'groupon/query', //团购API-查询
                            GroupOnMy: WxApiRoot + 'groupon/my', //团购API-我的团购
                            GroupOnDetail: WxApiRoot + 'groupon/detail', //团购API-详情
                            GroupOnJoin: WxApiRoot + 'groupon/join', //团购API-详情
                          
                   完成      CouponList: WxApiRoot + 'coupon/list', //优惠券列表
                   完成      CouponMyList: WxApiRoot + 'coupon/mylist', //我的优惠券列表
                            CouponSelectList: WxApiRoot + 'coupon/selectlist', //当前订单可用优惠券列表
                            CouponReceive: WxApiRoot + 'coupon/receive', //优惠券领取
                            CouponExchange: WxApiRoot + 'coupon/exchange', //优惠券兑换
                              
            何永斌：
                   完成     IndexUrl: WxApiRoot + 'home/index', //首页数据接口
                   完成     CatalogList: WxApiRoot + 'catalog/index', //分类目录全部分类数据接口
                   完成     CatalogCurrent: WxApiRoot + 'catalog/current', //分类目录当前分类数据接口
                            
                            AuthLoginByWeixin: WxApiRoot + 'auth/login_by_weixin', //微信登录
                   完成     AuthLoginByAccount: WxApiRoot + 'auth/login', //账号登录
                            AuthLogout: WxApiRoot + 'auth/logout', //账号登出1008002
                            AuthRegister: WxApiRoot + 'auth/register', //账号注册
                            AuthReset: WxApiRoot + 'auth/reset', //账号密码重置
                            AuthRegisterCaptcha: WxApiRoot + 'auth/regCaptcha', //验证码 
                            AuthBindPhone: WxApiRoot + 'auth/bindPhone', //绑定微信手机号
                       
                   完成    GoodsCount: WxApiRoot + 'goods/count', //统计商品总数??
                   完成    GoodsList: WxApiRoot + 'goods/list', //获得商品列表
                   完成    GoodsCategory: WxApiRoot + 'goods/category', //获得分类数据
                   完成    GoodsDetail: WxApiRoot + 'goods/detail', //获得商品的详情
                   完成    GoodsRelated: WxApiRoot + 'goods/related', //商品详情页的关联商品（大家都在看）
                            
                   完成     BrandList: WxApiRoot + 'brand/list', //品牌列表
                   完成     BrandDetail: WxApiRoot + 'brand/detail', //品牌详情
                            
                            StorageUpload: WxApiRoot + 'storage/upload', //图片上传,
                   完成      UserIndex: WxApiRoot + 'user/index', //个人页面用户相关信息
             
             遇上问题：
                刘晓涛：数据对比问题 需要时间
                陈雪松：订单处理问题
                肖晨旸：优惠卷过期问题
                何永斌：微信openid登陆问题
                张小林：逻辑问题
                刘玉：无
             
             目标：
                写完跨年！
        
        # 2019 12.31 更新记录
                后台基本完成：
                    遗留bug问题：
                        1. 商品更新没有实现 需要补充
                        2. 数据校验没有做 需要补充
                        3. 注解添加日志以及添加api注解未添加
                
                总体问题：
                    命名问题 开发完成后统一修改
                更新记录：
                wx端账号登陆认证已经完成，开发阶段shiro不会拦截所有wx开头的请求
                
                获取登陆信息请使用shiro的Subject进行获取
                
                Oos仍然可以使用
                
                对多表添加，订单扣除库存等涉及事务的问题请添加注解
                @Transactional(rollBackFor = Exception.class)
                
                druid的监视已经添加
                账号为a0123123a
                密码为admin
                若有错误请查看druid.yml
                
                密码加密算法请查看测试中的例子
#2020 1.1 会议纪要
    后台bug修复，前台基本实现逻辑，剩余接口：
    订单提交 1个
    收藏 2个
    专题 1个
    专题评论 3个
    会员足迹 1个
    会员登陆 1个
    优惠卷过期 1个

成员主要问题：
    优惠卷过期应该用什么实现
    
# 2020 1.2 更新
    1. 更新了关键字搜索
    2. 会员可领取优惠卷
    3. 主页 商品详情 等页面
    
                  
                  
                    
                  
                    

