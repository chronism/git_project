package cn.neepi.project2.typehandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.util.StringUtil;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/26
 **/
@MappedJdbcTypes(JdbcType.VARCHAR)
@MappedTypes(String[].class)
public class String2StringArray extends BaseTypeHandler<String[]> {
    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, String[] strings, JdbcType jdbcType) throws SQLException {


        ObjectMapper objectMapper = new ObjectMapper();

        String s=null;

        try {
            s = objectMapper.writeValueAsString(strings);
        } catch (JsonProcessingException e) {
            e.printStackTrace();

        }
        preparedStatement.setString(i,s);
    }

    @Override
    public String[] getNullableResult(ResultSet resultSet, String s) throws SQLException {
        String result = resultSet.getString(s);
        return transfer(result);
    }

    @Override
    public String[] getNullableResult(ResultSet resultSet, int i) throws SQLException {
        String result = resultSet.getString(i);
        return transfer(result);
    }

    @Override
    public String[] getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        String result = callableStatement.getString(i);
        return transfer(result);
    }


    private String[] transfer(String result){
        ObjectMapper objectMapper = new ObjectMapper();
        String[] strings = new String[0];
        if (StringUtil.isEmpty(result)){
            return strings;
        }
        try {
            strings = objectMapper.readValue(result,String[].class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return strings;

    }
}
