package cn.neepi.project2.util;

import cn.neepi.project2.model.Storage;
import com.aliyun.oss.OSSClient;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.UUID;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/26
 **/
public class OosUploadImageUtils {
    static String endpoint="oss-cn-beijing.aliyuncs.com";
    static String accesskey="LTAI4FpyPeyjk5RWAPuNSfMn";
    static String accesskeysecret="YibLLUvljpwJMlVYwjN3q3kHpArl1S";
    static String bucketname="projec2image";
    public static Storage picOSS(MultipartFile uploadFile , Storage storage) {
        // 创建OSSClient实例
        OSSClient ossClient = new OSSClient(endpoint, accesskey, accesskeysecret);
        // 上传
        Date date = new Date();

        String keyName = UUID.randomUUID().toString()+uploadFile.getOriginalFilename();
        try {
            ossClient.putObject(bucketname, keyName, new ByteArrayInputStream(uploadFile.getBytes()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 关闭client
        storage.setAddTime(date);
        storage.setUpdateTime(date);
        storage.setName(uploadFile.getOriginalFilename());
        storage.setKey(keyName);
        storage.setSize(uploadFile.getSize());
        storage.setType(uploadFile.getContentType());
        ossClient.shutdown();
        Date expiration = new Date(System.currentTimeMillis() + 3600L * 1000 * 24 * 365 * 10);
        String url = ossClient.generatePresignedUrl(bucketname, keyName, expiration).toString();
        System.out.println("url = " + url);
        storage.setUrl(url);
        return storage;
    }
}
