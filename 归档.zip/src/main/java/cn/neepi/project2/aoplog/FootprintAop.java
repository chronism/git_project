package cn.neepi.project2.aoplog;
import java.math.BigDecimal;

import cn.neepi.project2.aoplog.logannotation.LoginAndLogout;
import cn.neepi.project2.aoplog.logannotation.WxLoginAndFootprint;
import cn.neepi.project2.mapper.FootprintMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.Footprint;
import cn.neepi.project2.model.FootprintExample;
import cn.neepi.project2.model.User;
import com.github.pagehelper.util.StringUtil;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2020/01/02
 **/
@Aspect
@Component
public class FootprintAop {
    @Autowired
    UserMapper userMapper;

    @Autowired
    FootprintMapper footprintMapper;

    @Pointcut("@annotation(cn.neepi.project2.aoplog.logannotation.WxLoginAndFootprint)")
    public void log(){
    }

    @Around("log()")
    public Object log(ProceedingJoinPoint joinPoint) {


        Object proceed = null;

        try {
            WxLoginAndFootprint wxLoginAndFootprint = getDeclaredAnnotation(joinPoint);
            proceed = joinPoint.proceed();
            Subject subject = SecurityUtils.getSubject();
            User user = (User) subject.getPrincipal();
            if (user==null){
                return proceed;
            }
                String value = wxLoginAndFootprint.value();
                if (StringUtil.isEmpty(value)){
                    return proceed;
                }
                if ("登陆".equals(value)){
                    HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
                    String remoteAddr = request.getRemoteAddr();
                    User user1 = userMapper.selectByPrimaryKey(user.getId());
                    user1.setLastLoginIp(remoteAddr);
                    Date date = new Date();
                    user1.setLastLoginTime(date);
                    userMapper.updateByPrimaryKey(user1);

                }
                if ("会员足迹".equals(value)){
                    Object[] args = joinPoint.getArgs();
                    Integer arg = (Integer) args[0];
                    FootprintExample footprintExample = new FootprintExample();
                    footprintExample.createCriteria().andDeletedEqualTo(false).andGoodsIdEqualTo(arg).andUserIdEqualTo(user.getId());
                    List<Footprint> footprints = footprintMapper.selectByExample(footprintExample);
                    if (footprints!=null&&footprints.size()>0){
                        Footprint footprint = footprints.get(0);
                        footprint.setUpdateTime(new Date());
                        footprint.setAddTime(new Date());
                        footprintMapper.updateByPrimaryKey(footprint);
                        return proceed;
                    }

                    Footprint footprint = new Footprint();

                    footprint.setUserId(user.getId());
                    footprint.setGoodsId(arg);
                    Date date = new Date();
                    footprint.setAddTime(date);
                    footprint.setUpdateTime(date);
                    footprint.setDeleted(false);
                    footprintMapper.insert(footprint);


                }

        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }


        return proceed;
    }


    public WxLoginAndFootprint getDeclaredAnnotation(ProceedingJoinPoint joinPoint) throws NoSuchMethodException {
        // 获取方法名
        String methodName = joinPoint.getSignature().getName();
        // 反射获取目标类
        Class<?> targetClass = joinPoint.getTarget().getClass();
        // 拿到方法对应的参数类型
        Class<?>[] parameterTypes = ((MethodSignature) joinPoint.getSignature()).getParameterTypes();
        // 根据类、方法、参数类型（重载）获取到方法的具体信息
        Method objMethod = targetClass.getMethod(methodName, parameterTypes);
        // 拿到方法定义的注解信息
        WxLoginAndFootprint annotation = objMethod.getDeclaredAnnotation(WxLoginAndFootprint.class);
        // 返回
        return annotation;
    }
}
