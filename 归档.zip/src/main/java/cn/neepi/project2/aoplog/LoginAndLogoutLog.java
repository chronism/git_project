package cn.neepi.project2.aoplog;

import cn.neepi.project2.aoplog.logannotation.LoginAndLogout;
import cn.neepi.project2.mapper.LogMapper;
import cn.neepi.project2.model.Admin;
import cn.neepi.project2.model.Log;
import cn.neepi.project2.model.Result;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/29
 **/
@Aspect
@Component
public class LoginAndLogoutLog {
    @Autowired
    LogMapper logMapper;

    /**
     * 0: '一般操作',
     * 1: '安全操作',
     * 2: '订单操作',
     * 3: '商品操作',
     * 4: '管理操作', 管理员和角色
     * 5: '商场操作',
     * 6: '推广操作',
     * 7: '危险操作' 所有的删除
     */
    private static Map<String, Integer> TYPE_MAP = new HashMap<>();

    static {
        TYPE_MAP.put("登录", 1);
        TYPE_MAP.put("获取管理员", 1);
        TYPE_MAP.put("角色获取", 1);
        TYPE_MAP.put("获取日志", 1);
        TYPE_MAP.put("获取角色", 1);
        TYPE_MAP.put("权限获取", 1);
        TYPE_MAP.put("查找对象", 1);
        TYPE_MAP.put("对象修改", 4);
        TYPE_MAP.put("修改权限", 4);
        TYPE_MAP.put("角色创建", 4);
        TYPE_MAP.put("管理员创建", 4);
        TYPE_MAP.put("管理员更新", 4);
        TYPE_MAP.put("角色更新", 4);
        TYPE_MAP.put("删除管理员", 7);
        TYPE_MAP.put("删除角色", 7);
        TYPE_MAP.put("删除对象", 7);
    }


    @Pointcut("@annotation(cn.neepi.project2.aoplog.logannotation.LoginAndLogout)")
    public void loginAndLogout() {
    }

    @Around("loginAndLogout()")
    public Object log(ProceedingJoinPoint joinPoint) {
        Object proceed = null;
        try {
            LoginAndLogout declaredAnnotation = getDeclaredAnnotation(joinPoint);
            String value = declaredAnnotation.value();
            String comment = declaredAnnotation.comment();
            proceed = joinPoint.proceed();
            Result result = (Result) proceed;

            Subject subject = SecurityUtils.getSubject();
            Admin admin = (Admin) subject.getPrincipal();
            //获取request
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            String remoteAddr = request.getRemoteAddr();
            Log log = new Log();
            log.setAction(value);
            Date date = new Date();
            log.setAddTime(date);
            log.setAdmin(admin.getUsername());
            log.setDeleted(false);
            log.setUpdateTime(date);
            log.setStatus(result.getErrno() == 0 ? true : false);
            log.setIp(remoteAddr);
            log.setResult(result.getErrmsg());
            log.setComment(comment);
            log.setType(TYPE_MAP.get(value));
            logMapper.insert(log);

        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }


        return proceed;
    }



    public LoginAndLogout getDeclaredAnnotation(ProceedingJoinPoint joinPoint) throws NoSuchMethodException {
        // 获取方法名
        String methodName = joinPoint.getSignature().getName();
        // 反射获取目标类
        Class<?> targetClass = joinPoint.getTarget().getClass();
        // 拿到方法对应的参数类型
        Class<?>[] parameterTypes = ((MethodSignature) joinPoint.getSignature()).getParameterTypes();
        // 根据类、方法、参数类型（重载）获取到方法的具体信息
        Method objMethod = targetClass.getMethod(methodName, parameterTypes);
        // 拿到方法定义的注解信息
        LoginAndLogout annotation = objMethod.getDeclaredAnnotation(LoginAndLogout.class);
        // 返回
        return annotation;
    }
}
