package cn.neepi.project2.model;

import lombok.Data;

@Data
public class HandleOptionModel {
}
