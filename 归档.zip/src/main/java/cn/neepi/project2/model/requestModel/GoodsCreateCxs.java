package cn.neepi.project2.model.requestModel;

import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.GoodsAttribute;
import cn.neepi.project2.model.GoodsProduct;
import cn.neepi.project2.model.GoodsSpecification;
import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/29/029 下午 12:26
 */

@Data
@Component
public class GoodsCreateCxs {

    Goods goods;

    GoodsAttribute[] attributes;

    GoodsSpecification[] specifications;

    GoodsProduct[] products;


}
