package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.*;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import lombok.Data;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/29
 **/
@Data
public class HomeResp {
    private List<Ad> banner;
    private List<Brand> brandList;
    private List<CateGory> channel;
    private List<Coupon> couponList;
    private List<Goods> hotGoodsList;
    private List<Goods> newGoodsList;
    private List<FloorGoodsList> floorGoodsList;
    private List<GrouponList> grouponList;
    private List<Topic> topicList;
}
