package cn.neepi.project2.model.requestModel;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@Data
public class PageProperties {
    @NotNull
    private Integer page;

    private Integer limit;
    @NotNull
    private String sort;
    @NotNull
    private String order;

    private Integer size;
}
