package cn.neepi.project2.model.ResponseModel;

import lombok.Data;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/28/028 下午 03:47
 */
@Data
public class UserStatInfo {
    String day;

    Integer users;
}
