package cn.neepi.project2.model.wx_responseModel;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class CollectResponse {
    private Integer id;
    private Integer valueId;
    private String name;
    private String picUrl;
    private BigDecimal retailPrice;
    private Byte type;
    private String brief;
}
