package cn.neepi.project2.model;

import java.io.Serializable;
import lombok.Data;

@Data
public class CskaoyanMallSystemPermissions implements Serializable {
    private Integer tableId;

    private String id;

    private Integer pid;

    private String label;

    private String api;


}
