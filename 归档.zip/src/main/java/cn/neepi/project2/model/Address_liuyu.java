package cn.neepi.project2.model;

import lombok.Data;

import java.io.Serializable;
@Data
public class Address_liuyu implements Serializable {
    private  Integer id;
    private  String name;
    private  String mobile;
    private  String detailedAddress;
    private  Boolean isDefault;
}
