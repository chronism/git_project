package cn.neepi.project2.model.responseModel;

import lombok.Data;

import javax.validation.constraints.Min;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/26/026 下午 09:44
 */
@Data
public class OrderConfigCxs {
    @Min(value=0,message = "402.order.comment")
    String cskaoyan_mall_order_comment;
    @Min(value=0,message = "402.order.unpaid")
    String cskaoyan_mall_order_unpaid;
    @Min(value=0,message = "402.order.unconfirm")
    String cskaoyan_mall_order_unconfirm;
}
