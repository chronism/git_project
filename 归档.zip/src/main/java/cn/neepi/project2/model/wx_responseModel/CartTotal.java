package cn.neepi.project2.model.wx_responseModel;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CartTotal {
    private Integer goodsCount;
    private Integer checkedGoodsCount;
    private BigDecimal goodsAmount;
    private BigDecimal checkedGoodsAmount;
}
