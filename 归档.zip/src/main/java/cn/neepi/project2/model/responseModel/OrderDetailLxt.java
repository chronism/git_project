package cn.neepi.project2.model.responseModel;

import cn.neepi.project2.model.OrderGoods;
import cn.neepi.project2.model.ShoppingMallModel.Order;
import cn.neepi.project2.model.User;
import lombok.Data;

import java.util.List;

@Data
public class OrderDetailLxt {
    private List<OrderGoods> orderGoods;
    private User user;
    private Order order;
}
