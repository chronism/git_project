package cn.neepi.project2.model.responseModel;

import lombok.Data;

/**
 * 系统管理/管理员 返回用时对 role 的封装
 * @author xcy
 */
@Data
public class RoleResp {
    /**
     * 对应role id
     */
    Integer value;
    /**
     * 对应role name
     */
    String label;
}
