package cn.neepi.project2.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class UserInfoAndTopicComment {
    private UserInfo userInfo;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date addTime;
    private String[]  picList;
    private String content;

}
