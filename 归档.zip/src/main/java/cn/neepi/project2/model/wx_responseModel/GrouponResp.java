package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Goods;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class GrouponResp {
    Goods goods;
    int groupon_member;
    BigDecimal groupon_price;
}
