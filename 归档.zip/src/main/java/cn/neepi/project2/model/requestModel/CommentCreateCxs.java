package cn.neepi.project2.model.RequestModel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author niko
 * @version 1.0
 * @date 20/01/2/002 下午 06:08
 */

@Data
public class CommentCreateCxs {
    private Integer id;

    private Integer orderGoodsId;

    private Byte type;

    private String content;

    private Integer userId;

    private Boolean hasPicture;

    private String[] picUrls;

    private Short star;
}
