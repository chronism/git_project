package cn.neepi.project2.model.responseModel;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * permission封装成json所需的bean
 */
@Data
public class PermissionResp {
    String id;
    String label;
    String api;
    List<PermissionResp> children;
}
