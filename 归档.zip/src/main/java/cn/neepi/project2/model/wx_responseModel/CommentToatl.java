package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Comment;
import lombok.Data;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@Data
public class CommentToatl {
    private Long count;
    private List<Comment> data;
}
