package cn.neepi.project2.model.responseModel;

import lombok.Data;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@Data
public class ListItem<T> {
    private Long total;
    private T items;
}
