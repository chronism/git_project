package cn.neepi.project2.model;

import lombok.Data;

import java.util.List;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@Data
public class InfoData {
    String avatar;
    String name;
    List<String> perms;
    List<String> roles;
}
