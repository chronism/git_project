package cn.neepi.project2.model.responseModel;

import lombok.Data;

import javax.validation.constraints.Min;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/26/026 下午 09:46
 */
@Data
public class WxConfigCxs {
    @Min(value = 0, message = "402.wx.index.new")
    String cskaoyan_mall_wx_index_new;
    @Min(value = 0, message = "402.wx.catlog.goods")
    String cskaoyan_mall_wx_catlog_goods;
    @Min(value = 0, message = "402.wx.catlog.list")
    String cskaoyan_mall_wx_catlog_list;
    String cskaoyan_mall_wx_share;
    @Min(value = 0, message = "402.wx.index.brand")
    String cskaoyan_mall_wx_index_brand;
    @Min(value = 0, message = "402.wx.index.hot")
    String cskaoyan_mall_wx_index_hot;
    @Min(value = 0, message = "402.wx.index.topic")
    String cskaoyan_mall_wx_index_topic;
}
