package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import lombok.Data;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/29
 **/
@Data
public class HomeCategroyList {
    private List<CateGory> categoryList;
    private CateGory currentCategory;
    private List<CateGory> currentSubCategory;

}
