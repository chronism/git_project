package cn.neepi.project2.model.wx_requestModel;

import lombok.Data;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/31
 **/
@Data
public class WxRegister {

    /**
     * username : admin123
     * password : a0123123a
     * mobile : 15977777777
     * code : 123456
     * wxCode : the code is a mock one
     */

    private String username;
    private String password;
    private String mobile;
    private String code;
    private String wxCode;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getWxCode() {
        return wxCode;
    }

    public void setWxCode(String wxCode) {
        this.wxCode = wxCode;
    }
}
