package cn.neepi.project2.model.responseModel;

import lombok.Data;


/**
 * 微信端的返回bean
 */
@Data
public class WxListItem<T> {
    T data;
    Long count;
}
