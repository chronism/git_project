package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Groupon;
import cn.neepi.project2.model.GrouponRules;
import cn.neepi.project2.model.User;
import lombok.Data;

import java.util.List;

@Data
public class GrouponDetail {
    User creator;
    Groupon groupon;
    List<User> joiners;
    Integer linkGrouponId;
    List orderGoods;

    OrderInfoCxs orderInfo;
    GrouponRules rules;
}
