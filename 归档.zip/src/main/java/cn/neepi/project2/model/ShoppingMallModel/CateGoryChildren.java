package cn.neepi.project2.model.ShoppingMallModel;

import lombok.Data;

import java.io.Serializable;

@Data
public class CateGoryChildren implements Serializable {
    private Integer value;
    private String label;
}
