package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import lombok.Data;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@Data
public class GoodsCategroyGoodList {
    private List<Goods> goodsList;
    private Long count;
    private List<CateGory> filterCategoryList;
}
