package cn.neepi.project2.model.aliyunModel;

import lombok.Data;

@Data
public class Oss {
    private String bucket;
    private String endPoint;
}
