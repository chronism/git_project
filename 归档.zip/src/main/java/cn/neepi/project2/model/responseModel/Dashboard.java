package cn.neepi.project2.model.responseModel;

import lombok.Data;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@Data
public class Dashboard {

    /**
     * goodsTotal : 239
     * userTotal : 22
     * productTotal : 244
     * orderTotal : 0
     */

    private Long goodsTotal;
    private Long userTotal;
    private Long productTotal;
    private Long orderTotal;


}
