package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.*;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import lombok.Data;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@Data
public class GoodsDetail {
    private List<GoodsAttribute> attribute;
    private Brand brand;
    private CommentToatl comment;
    private List<GrouponRules> groupon;
    private Goods info;
    private List<Issue> issue;
    private List<GoodsProduct> productList;
    private String shareImage;
    private List<GoodsSpecificationList> specificationList;
    private Long userHasCollect;


}
