package cn.neepi.project2.model.responseModel;

import lombok.Data;

import javax.validation.constraints.Pattern;

@Data
public class MallConfigCxs {

    String cskaoyan_mall_mall_address;

    String cskaoyan_mall_mall_name;
    @Pattern(regexp = "^[1][34578][0-9]{9}$", message = "402.mall.mall.phone")
    String cskaoyan_mall_mall_phone;
    @Pattern(regexp = "[1-9][0-9]{4,14}", message = "402.mall.mall.qq")
    String cskaoyan_mall_mall_qq;
}
