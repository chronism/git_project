package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Address;
import cn.neepi.project2.model.Cart;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
@Data
public class CartConfirmation {
    private BigDecimal actualPrice;
    private Integer addressId;
    private Integer availableCouponLength;
    private Address checkedAddress;
    private List<Cart> checkedGoodsList;
    private Integer couponId;
    private BigDecimal couponPrice;
    private BigDecimal freightPrice;
    private BigDecimal goodsTotalPrice;
    private BigDecimal grouponPrice;
    private Integer grouponRulesId;
    private BigDecimal orderTotalPrice;
}
