package cn.neepi.project2.model.wx_responseModel;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/31/031 下午 08:30
 */
@Data
public class OrderInfoCxs {
    private String consignee;

    private String address;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date addTime;

    private String orderSn;

    private BigDecimal actualPrice;

    private String mobile;

    private String orderStatusText;

    private BigDecimal goodsPrice;

    private BigDecimal couponPrice;

    private Integer id;

    private BigDecimal freightPrice;

    private Map<String, Boolean> handleOption;
}
