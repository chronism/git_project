package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Cart;
import lombok.Data;

import java.util.List;
@Data
public class CartIndex {
    private List<Cart> cartList;
    private CartTotal cartTotal;
}
