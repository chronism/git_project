package cn.neepi.project2.model;

import lombok.Data;

@Data
public class UserInfo {
    private String nickName;
    private String avatarUrl;
}
