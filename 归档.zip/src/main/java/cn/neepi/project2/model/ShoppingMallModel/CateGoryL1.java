package cn.neepi.project2.model.ShoppingMallModel;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CateGoryL1 implements Serializable {
    private Integer value;
    private String label;
    List<CateGoryChildren> children;
}
