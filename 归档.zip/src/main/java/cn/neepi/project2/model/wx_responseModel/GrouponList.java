package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Goods;
import lombok.Data;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/31
 **/
@Data
public class GrouponList {
    private Double groupon_price;
    private Integer groupon_member;
    private Goods goods;
}
