package cn.neepi.project2.model.wx_responseModel;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
public class UserIndex {

    private Integer unrecv;
    private Integer uncomment;
    private Integer unpaid;
    private Integer unship;

    public Integer getUnrecv() {
        return unrecv;
    }

    public void setUnrecv(Integer unrecv) {
        this.unrecv = unrecv;
    }

    public Integer getUncomment() {
        return uncomment;
    }

    public void setUncomment(Integer uncomment) {
        this.uncomment = uncomment;
    }

    public Integer getUnpaid() {
        return unpaid;
    }

    public void setUnpaid(Integer unpaid) {
        this.unpaid = unpaid;
    }

    public Integer getUnship() {
        return unship;
    }

    public void setUnship(Integer unship) {
        this.unship = unship;
    }
}
