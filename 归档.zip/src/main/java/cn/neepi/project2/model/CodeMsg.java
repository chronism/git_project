package cn.neepi.project2.model;

/**
 * @ClassName CodeMsg
 * @Description: TODO
 * @Author heyongbin
 * @Date 2019-12-22
 * @Version V1.0
 **/
public class CodeMsg {


    public static CodeMsg SUCCESS = new CodeMsg(0, "success");
    public static CodeMsg SERVER_ERROR = new CodeMsg(502, "服务端异常");
    public static CodeMsg BIND_ERROR = new CodeMsg(402, "参数校验异常：%s");
    public static CodeMsg CODE_ERROR = new CodeMsg(502, "验证码错误");
    public static CodeMsg PASSWORD_ERROR = new CodeMsg(605, "用户帐号或密码不正确");
    public static CodeMsg WX_REGISTER = new CodeMsg(302, "请注册账号绑定微信");
    /**
     * author xcy
     */
    public static CodeMsg ADMIN_PASSWORD_SHORT = new CodeMsg(602, "管理员密码长度不能小于6");
    public static CodeMsg ADMIN_NAME_ERROR = new CodeMsg(602, "管理员名称不符合规范");
    public static CodeMsg ADMIN_EXSIT = new CodeMsg(602, "管理员已经存在");
    public static CodeMsg ROLE_NAME_ERROR = new CodeMsg(601, "角色名称不符合规定");
    public static CodeMsg ROLE_EXSIT = new CodeMsg(602, "角色已经存在");
    public static CodeMsg COUPON_HAS_RECEIVED = new CodeMsg(740, "优惠券已经领取过");
    public static CodeMsg COUPON_CODE_ERROR = new CodeMsg(742, "优惠券兑换码不正确");


    /**
     * author cxs
     */
    public static CodeMsg NOT_POSITIVE_INTEGER = new CodeMsg(402, "请输入大于0的正整数");
    public static CodeMsg NOT_QQ = new CodeMsg(402, "请输入正确的QQ号");
    public static CodeMsg NOT_PHONE = new CodeMsg(402, "请输入正确的手机号");
    public static CodeMsg GOODS_NAME_REPEAT = new CodeMsg(601, "商品名已经存在");
    public static CodeMsg CATEGORYID_NOTNULL = new CodeMsg(402, "类目不可为空");
    public static CodeMsg BRANDID_NOTNULL = new CodeMsg(402, "品牌不可为空");
    public static CodeMsg LOW_STOCKS = new CodeMsg(724,"库存不足");

    /**
     * author lxt
     */
    public static CodeMsg MANUFACTURER_NAME_ERROR = new CodeMsg(402, "制造商名字已注册");
    public static CodeMsg Brand_NAME_ERROR = new CodeMsg(401, "品牌商名称不能为空");
    public static CodeMsg Brand_DESC_ERROR = new CodeMsg(401, "品牌商介绍不能为空");
    public static CodeMsg Brand_PICURL_ERROR = new CodeMsg(401, "品牌商图片不能为空");
    public static CodeMsg Brand_FLOORPRICE_ERROR = new CodeMsg(401, "底价范围[0到100000000]");
    public static CodeMsg CATEGORY_NAME_ERROR = new CodeMsg(401, "商品类目名称不能为空");
    public static CodeMsg CATEGORY_DESC_ERROR = new CodeMsg(401, "类目简介不能为空");
    public static CodeMsg CATEGORY_PICURL_ERROR = new CodeMsg(401, "类目图片不能为空");
    public static CodeMsg CATEGORY_KEYWORDS_ERROR = new CodeMsg(401, "商品关键字不能为空");
    public static CodeMsg CATEGORY_ICONURL_ERROR = new CodeMsg(401, "类目图标不能为空");
    public static CodeMsg CATEGORY_PID_ERROR = new CodeMsg(401, "请选择父类目");
    public static CodeMsg ORDER_SHIP_ERROR = new CodeMsg(401, "订单发货失败");
    public static CodeMsg ORDER_REFUND_ERROR = new CodeMsg(621, "订单退款失败");
    public static CodeMsg ORDER_REPLY_ERROR = new CodeMsg(401, "订单回复失败");


    private int code;
    private String msg;

    private CodeMsg(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public CodeMsg fillArgs(Object... args) {
        int code = this.code;
        String message = String.format(this.msg, args);
        return new CodeMsg(code, message);
    }
}
