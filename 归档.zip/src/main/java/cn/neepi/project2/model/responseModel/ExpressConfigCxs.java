package cn.neepi.project2.model.responseModel;

import lombok.Data;

import javax.validation.constraints.Min;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/26/026 下午 09:41
 */
@Data
public class ExpressConfigCxs {
    @Min(value = 0, message = "402.express.freight.min")
    String cskaoyan_mall_express_freight_min;
    @Min(value = 0, message = "402.express.freight.value")
    String cskaoyan_mall_express_freight_value;
}
