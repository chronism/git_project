package cn.neepi.project2.model.responseModel;

import lombok.Data;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/26/026 下午 08:13
 */

@Data
public class OrderGoodStatInfo {
    Double amount;

    int products;

    String day;

    int orders;

}
