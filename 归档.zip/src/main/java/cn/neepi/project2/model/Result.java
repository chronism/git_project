package cn.neepi.project2.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @ClassName Result
 * @Description: TODO
 * @Author heyongbin
 * @Date 2019-12-22
 * @Version V1.0
 **/

public class Result<T> {
    private int errno;
    private String errmsg;
    private T data;

    /**
     * 参数校验出问题时需要的构造方法
     */
    public Result(int errno, String errmsg) {
        this.errmsg = errmsg;
        this.errno = errno;
    }

    /**
     * 请求成功时调用
     *
     * @param data
     * @return
     */
    public static <T> Result<T> success(T data) {
        return new Result<T>(data);
    }

    public static <T> Result<T> error(CodeMsg cm) {
        return new Result<T>(cm);
    }

    public static <T> Result<T> forward(CodeMsg cm, T data) {
        return new Result<T>(data, cm);
    }

    /**
     * 只传入数据默认成功，所以添加默认的code和msg
     *
     * @param data
     */
    private Result(T data) {
        this.errno = 0;
        this.errmsg = "success";
        this.data = data;
    }

    private Result(CodeMsg cm) {
        if (cm == null) {
            return;
        }
        this.errno = cm.getCode();
        this.errmsg = cm.getMsg();
    }

    private Result(T data, CodeMsg cm) {
        if (cm == null) {
            return;
        }
        this.errno = cm.getCode();
        this.errmsg = cm.getMsg();
        this.data = data;
    }

    public int getErrno() {
        return errno;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public T getData() {
        return data;
    }

}
