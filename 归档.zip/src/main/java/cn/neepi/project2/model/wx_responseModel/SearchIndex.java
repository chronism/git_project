package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Goods;
import lombok.Data;

import java.util.List;

/**
 * @author zxl
 * @time 2019/12/31
 * 搜索关键字接口的返回值类型
 */

@Data
public class SearchIndex {

    private Goods defaultKeyword;

    private List<Goods> hotKeywordList;

    private List<Goods> historyKeywordList;
}
