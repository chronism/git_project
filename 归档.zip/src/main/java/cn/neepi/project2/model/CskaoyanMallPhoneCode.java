package cn.neepi.project2.model;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class CskaoyanMallPhoneCode implements Serializable {
    private Integer id;

    private String phone;

    private String code;

    private Date deletetime;

    private static final long serialVersionUID = 1L;
}