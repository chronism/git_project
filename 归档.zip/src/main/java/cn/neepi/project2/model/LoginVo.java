package cn.neepi.project2.model;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@Data
public class LoginVo {
    @NotNull
    String username;
    @NotNull
    String password;
}
