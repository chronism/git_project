package cn.neepi.project2.model.wx_requestModel;

import cn.neepi.project2.model.User;
import lombok.Data;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/31
 **/
@Data
public class WxLoginRequest {
    private String code;
    private WxUserInfo userInfo;
}
