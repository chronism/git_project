package cn.neepi.project2.model.ResponseModel;

import lombok.Data;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/28/028 下午 03:45
 */
@Data
public class OrderStatInfo {

    double amount;

    int orders;

    int customers;

    String day;

    double pcr;
}
