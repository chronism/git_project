package cn.neepi.project2.model.wx_responseModel;

import cn.neepi.project2.model.Groupon;
import cn.neepi.project2.model.GrouponRules;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
public class MyGroupon {
    BigDecimal actualPrice;
    String creator;
    List goodsList;

    Groupon groupon;

    Map handleOption;

    int id;
    Boolean isCreator;
    int joinerCount;
    int orderId;
    String orderSn;
    String orderStatusText;

    GrouponRules rules;
}
