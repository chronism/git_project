package cn.neepi.project2.model.RequestModel;

import lombok.Data;

/**
 * @author niko
 * @version 1.0
 * @date 20/01/2/002 上午 07:49
 */

@Data
public class OrderSubmitConditionCxs {
    private Integer addressId;

    private Integer cartId;

    private Integer couponId;

    private Integer grouponLinkId;

    private Integer grouponRulesId;

    private String message;
}
