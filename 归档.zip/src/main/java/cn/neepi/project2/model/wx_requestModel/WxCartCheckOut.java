package cn.neepi.project2.model.wx_requestModel;

import lombok.Data;

@Data
public class WxCartCheckOut {
    private Integer cartId;
    private Integer addressId;
    private Integer couponId;
    private Integer grouponRulesId;
}
