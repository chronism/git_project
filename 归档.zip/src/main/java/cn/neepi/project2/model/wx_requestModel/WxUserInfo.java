package cn.neepi.project2.model.wx_requestModel;

import lombok.Data;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/31
 **/
@Data
public class WxUserInfo {

    /**
     * nickName : 十方一念
     * avatarUrl : http://wx.qlogo.cn/mmopen/vi_32/oBXVIQOt0EKTFCrHrepTycxkCPF4xzUOvtVJ4fM5b5oialMAcic2w00XOtaybicE48H2spGaiajIhJN1VNy9qn1uHw/132
     * gender : 1
     * province : Guangxi
     * city : Nanning
     */

    private String nickName;
    private String avatarUrl;
    private Integer gender;
    private String province;
    private String city;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
