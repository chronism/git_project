package cn.neepi.project2.mapper;

import cn.neepi.project2.model.Address;
import cn.neepi.project2.model.AddressExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface AddressMapper {
    long countByExample(AddressExample example);

    int deleteByExample(AddressExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Address record);

    int insertSelective(Address record);

    List<Address> selectByExample(AddressExample example);

    Address selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Address record, @Param("example") AddressExample example);

    int updateByExample(@Param("record") Address record, @Param("example") AddressExample example);

    int updateByPrimaryKeySelective(Address record);

    int updateByPrimaryKey(Address record);

    List<Address> selectByExampleAll(AddressExample example);

    Integer updateAddress(Address address);

    void updateAllAddressIsNotDefault();

    void updateNewstAddressIsDefaule(Integer id);

    List<Address> selectByIdOrName(@Param("userId") Integer userId, @Param("name") String name);
}
