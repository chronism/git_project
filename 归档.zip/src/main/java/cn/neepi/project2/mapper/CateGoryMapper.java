package cn.neepi.project2.mapper;

import cn.neepi.project2.model.ShoppingMallModel.*;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface CateGoryMapper {
    long countByExample(CateGoryExample example);

    int deleteByExample(CateGoryExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CateGory record);

    int insertSelective(CateGory record);

    List<CateGory> selectByExample(CateGoryExample example);

    CateGory selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CateGory record, @Param("example") CateGoryExample example);

    int updateByExample(@Param("record") CateGory record, @Param("example") CateGoryExample example);

    int updateByPrimaryKeySelective(CateGory record);

    int updateByPrimaryKey(CateGory record);

    List<CateGoryL1> selectAllCategory();

    List<CateGoryChildren> selectAllChildren(Integer value);

    List<Brand> selectAllBrand();
}
