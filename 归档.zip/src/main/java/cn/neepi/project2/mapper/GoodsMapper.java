package cn.neepi.project2.mapper;

import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.GoodsExample;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface GoodsMapper {
    long countByExample(GoodsExample example);

    int deleteByExample(GoodsExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Goods record);

    int insertSelective(Goods record);

    List<Goods> selectByExampleWithBLOBs(GoodsExample example);

    List<Goods> selectByExample(GoodsExample example);

    Goods selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Goods record, @Param("example") GoodsExample example);

    int updateByExampleWithBLOBs(@Param("record") Goods record, @Param("example") GoodsExample example);

    int updateByExample(@Param("record") Goods record, @Param("example") GoodsExample example);

    int updateByPrimaryKeySelective(Goods record);

    int updateByPrimaryKeyWithBLOBs(Goods record);

    int updateByPrimaryKey(Goods record);

    int insertByGoodsMap(@Param("goods") Goods goods, @Param("addTime") String addTime);

    void updateInfoOfLastInsert(@Param("goodsId") int goodsId, @Param("gallery") String gallery, @Param("shareUrl") String shareUrl);

    List<Goods> selectByGrouponRules(@Param("groupRulesId") List<Integer> groupRulesId);
}
