package cn.neepi.project2.mapper;

import cn.neepi.project2.model.ShoppingMallModel.CateGoryL1;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


import java.util.List;

public interface CateGoryL1Mapper {
    @Select(value = "select id as value ,name as label from cskaoyan_mall_category where level =#{level}and deleted =#{deleted} ")
    public List<CateGoryL1> getCateGoryList(@Param("level") String level, @Param("deleted") Boolean deleted);
}
