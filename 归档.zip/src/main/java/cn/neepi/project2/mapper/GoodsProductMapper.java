package cn.neepi.project2.mapper;

import cn.neepi.project2.model.GoodsProduct;
import cn.neepi.project2.model.GoodsProductExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface GoodsProductMapper {
    long countByExample(GoodsProductExample example);

    int deleteByExample(GoodsProductExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(GoodsProduct record);

    int insertSelective(GoodsProduct record);

    List<GoodsProduct> selectByExample(GoodsProductExample example);

    GoodsProduct selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") GoodsProduct record, @Param("example") GoodsProductExample example);

    int updateByExample(@Param("record") GoodsProduct record, @Param("example") GoodsProductExample example);

    int updateByPrimaryKeySelective(GoodsProduct record);

    int updateByPrimaryKey(GoodsProduct record);

    void insertByProductMap(@Param("product")GoodsProduct product, @Param("addTime")String addTime, @Param("goodsId")int goodsId);

    long countByProductsLeftJoninOrderGoods(@Param("orderId")Integer orderId);


    void updateSotckByProductId(@Param("number") Short number, @Param("productId") Integer productId);
}
