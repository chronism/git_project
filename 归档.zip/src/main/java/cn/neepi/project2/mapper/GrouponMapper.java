package cn.neepi.project2.mapper;

import cn.neepi.project2.model.Groupon;
import cn.neepi.project2.model.GrouponExample;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface GrouponMapper {
    long countByExample(GrouponExample example);

    int deleteByExample(GrouponExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Groupon record);

    int insertSelective(Groupon record);

    List<Groupon> selectByExample(GrouponExample example);

    Groupon selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Groupon record, @Param("example") GrouponExample example);

    int updateByExample(@Param("record") Groupon record, @Param("example") GrouponExample example);

    int updateByPrimaryKeySelective(Groupon record);

    int updateByPrimaryKey(Groupon record);


    int selectGrouponOrNotByOrderId(Integer id);

    void setPayedTrue(int id);

    @Select("select count(id) from cskaoyan_mall_groupon where user_id = #{creatorUserId} and rules_id = #{id}  ")
    Long countJoiner(@Param("creatorUserId") Integer creatorUserId, @Param("id") Integer ruleId);

    Groupon selectByGrouponRulesId(Integer id);

    List<Groupon> selectOrderIdAndUserId(Integer id);


}
