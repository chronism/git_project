package cn.neepi.project2.mapper;

import cn.neepi.project2.model.Permission;
import cn.neepi.project2.model.PermissionExample;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface PermissionMapper {
    long countByExample(PermissionExample example);

    int deleteByExample(PermissionExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Permission record);

    int insertSelective(Permission record);

    List<Permission> selectByExample(PermissionExample example);

    Permission selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Permission record, @Param("example") PermissionExample example);

    int updateByExample(@Param("record") Permission record, @Param("example") PermissionExample example);

    int updateByPrimaryKeySelective(Permission record);

    int updateByPrimaryKey(Permission record);

    List<String> selectByRoleIds(@Param("ids") Integer[] ids);

    @Select("select deleted from cskaoyan_mall_permission where permisson = #{perm}")
    boolean judgeIfDeleted(@Param("perm") String perm);

    @Update("update cskaoyan_mall_permission SET update_time = #{date,jdbcType=TIMESTAMP} , deleted = false where role_id = #{roleId} and permission = #{perm} ")
    Integer updateDateAndDeleted(@Param("date") Date date, @Param("roleId") Integer roleId, @Param("perm") String perm);

    @Update("update cskaoyan_mall_permission SET `deleted` = true where role_id = #{roleId} and permission = #{oldPerm}")
    Integer deleteByIdAndPermission(@Param("roleId") Integer roleId, @Param("oldPerm") String oldPerm);

    List<String> selectPermissionByExample(PermissionExample permissionExample);
}
