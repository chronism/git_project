package cn.neepi.project2.mapper;

import cn.neepi.project2.model.Cart;
import cn.neepi.project2.model.CartExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CartMapper {
    long countByExample(CartExample example);

    int deleteByExample(CartExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Cart record);

    int insertSelective(Cart record);

    List<Cart> selectByExample(CartExample example);

    Cart selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Cart record, @Param("example") CartExample example);

    int updateByExample(@Param("record") Cart record, @Param("example") CartExample example);

    int updateByPrimaryKeySelective(Cart record);

    int updateByPrimaryKey(Cart record);

    List<Cart> selectByUserIdAndChecked(@Param("userId") Integer userId);

    List<Cart> selectByCartId(@Param("cartId") Integer cartId);

    int deleteGoodsSubmitted();

    void deleteGoodsByCartId(Integer cartId);
}
