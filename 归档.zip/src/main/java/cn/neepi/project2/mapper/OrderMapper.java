package cn.neepi.project2.mapper;

import cn.neepi.project2.model.ShoppingMallModel.Order;
import cn.neepi.project2.model.ShoppingMallModel.OrderExample;

import java.util.List;

import cn.neepi.project2.model.ResponseModel.OrderStatInfo;
import org.apache.ibatis.annotations.Param;

public interface OrderMapper {
    long countByExample(OrderExample example);

    int deleteByExample(OrderExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Order record);

    int insertSelective(Order record);

    List<Order> selectByExample(OrderExample example);

    Order selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Order record, @Param("example") OrderExample example);

    int updateByExample(@Param("record") Order record, @Param("example") OrderExample example);

    int updateByPrimaryKeySelective(Order record);

    int updateByPrimaryKey(Order record);

    List<OrderStatInfo> queryOrderStatInfo();

    List<Order> listByExample(@Param("orderStatusArray") Integer[] orderStatusArray, @Param("userId") Integer userId, @Param("orderSn") String orderSn);

    int submitOrder(@Param("order") Order order);
}
