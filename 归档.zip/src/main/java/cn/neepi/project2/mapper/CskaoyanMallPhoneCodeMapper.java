package cn.neepi.project2.mapper;

import cn.neepi.project2.model.CskaoyanMallPhoneCode;
import cn.neepi.project2.model.CskaoyanMallPhoneCodeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CskaoyanMallPhoneCodeMapper {
    long countByExample(CskaoyanMallPhoneCodeExample example);

    int deleteByExample(CskaoyanMallPhoneCodeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CskaoyanMallPhoneCode record);

    int insertSelective(CskaoyanMallPhoneCode record);

    List<CskaoyanMallPhoneCode> selectByExample(CskaoyanMallPhoneCodeExample example);

    CskaoyanMallPhoneCode selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CskaoyanMallPhoneCode record, @Param("example") CskaoyanMallPhoneCodeExample example);

    int updateByExample(@Param("record") CskaoyanMallPhoneCode record, @Param("example") CskaoyanMallPhoneCodeExample example);

    int updateByPrimaryKeySelective(CskaoyanMallPhoneCode record);

    int updateByPrimaryKey(CskaoyanMallPhoneCode record);
}