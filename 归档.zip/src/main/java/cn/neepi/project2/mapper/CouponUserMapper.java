package cn.neepi.project2.mapper;

import cn.neepi.project2.model.CouponUser;
import cn.neepi.project2.model.CouponUserExample;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface CouponUserMapper {
    long countByExample(CouponUserExample example);

    int deleteByExample(CouponUserExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CouponUser record);

    int insertSelective(CouponUser record);

    List<CouponUser> selectByExample(CouponUserExample example);

    CouponUser selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CouponUser record, @Param("example") CouponUserExample example);

    int updateByExample(@Param("record") CouponUser record, @Param("example") CouponUserExample example);

    int updateByPrimaryKeySelective(CouponUser record);

    int updateByPrimaryKey(CouponUser record);

    @Select("select coupon_id from cskaoyan_mall_coupon_user where user_id = #{userId}")
    List<Integer> selectUsefulCoupon(@Param("userId") int userId);

    @Select("select coupon_id from cskaoyan_mall_coupon_user where user_id = #{userId} and status = #{status}")
    List<Integer> selectUsefulCouponByStatus(@Param("userId") int userId, @Param("status") Integer status);
}
