package cn.neepi.project2.mapper;

import cn.neepi.project2.model.CskaoyanMallSystemPermissions;
import cn.neepi.project2.model.responseModel.PermissionResp;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface CskaoyanMallSystemPermissionsMapper {
    int deleteByPrimaryKey(Integer tableId);

    int insert(CskaoyanMallSystemPermissions record);

    int insertSelective(CskaoyanMallSystemPermissions record);

    CskaoyanMallSystemPermissions selectByPrimaryKey(Integer tableId);

    int updateByPrimaryKeySelective(CskaoyanMallSystemPermissions record);

    int updateByPrimaryKey(CskaoyanMallSystemPermissions record);

    List<PermissionResp> selectAllPermissons();

    //超级权限对应查询
    @Select("select id from cskaoyan_mall_system_permissions where api != null")
    List<String> selectAllApis();

    List<String> selectUserPermison(@Param("permissions") List<String> permissions);
}
