package cn.neepi.project2.mapper;

import cn.neepi.project2.model.GoodsSpecification;
import cn.neepi.project2.model.GoodsSpecificationExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface GoodsSpecificationMapper {
    long countByExample(GoodsSpecificationExample example);

    int deleteByExample(GoodsSpecificationExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(GoodsSpecification record);

    int insertSelective(GoodsSpecification record);

    List<GoodsSpecification> selectByExample(GoodsSpecificationExample example);

    GoodsSpecification selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") GoodsSpecification record, @Param("example") GoodsSpecificationExample example);

    int updateByExample(@Param("record") GoodsSpecification record, @Param("example") GoodsSpecificationExample example);

    int updateByPrimaryKeySelective(GoodsSpecification record);

    int updateByPrimaryKey(GoodsSpecification record);

    void insertBySpecificationMap(@Param("specification") GoodsSpecification specification, @Param("addTime") String addTime, @Param("goodsId") int goodsId);

    void deleteNotInIds(@Param("deleteSpec") List<Integer> deleteSpec, @Param("goodsId") Integer goodsId);
}
