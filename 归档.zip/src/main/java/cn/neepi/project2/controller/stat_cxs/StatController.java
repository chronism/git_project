package cn.neepi.project2.controller.stat_cxs;

import cn.neepi.project2.model.Result;
import cn.neepi.project2.service.StatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/28/028 下午 05:31
 */

@RestController
@RequestMapping("admin/stat")
public class StatController {
    @Autowired
    StatService statService;

    /**
     * 用户报表统计
     * @return
     */
    @RequestMapping("user")
    public Result<Map> userStat() {

        return Result.success(statService.userStat());
    }

    /**
     * 订单商品报表统计
     * @return
     */
    @RequestMapping("goods")
    public Result<Map> orderGoodsStat() {
        return Result.success(statService.orderGoodStat());

    }

    /**
     * 订单报表统计
     * @return
     */
    @RequestMapping("order")
    public Result<Map> orderStat() {
        return Result.success(statService.orderStat());
    }

}
