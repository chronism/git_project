package cn.neepi.project2.controller.wx_controller.comment_topic_search_wx_zxl;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.Topic;
import cn.neepi.project2.service.wx_service.WxTopicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("wx/topic")
public class WxTopicController {

    @Autowired
    WxTopicService wxTopicService;

    /**
     * 专题详情
     */
    @GetMapping("detail")
    public Result getDetail(Integer id){
        Topic topic = wxTopicService.getDetail(id);
        if(topic == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        HashMap<Object, Object> map = new HashMap<>();
        map.put("topic",topic);
        return Result.success(map);
    }

    /**
     * 专题列表
     * @return Topic
     */
    @GetMapping("list")
    public Result getTopicList(Integer page,Integer size){
        Map topicList = wxTopicService.getTopicList(page,size);
        if(topicList == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
            return Result.success(topicList);
    }

    /**
     * 相关专题
     * @param id
     * @return
     */
    @GetMapping("related")
    public Result getRelatedTopicList(Integer id){
        List<Topic> topiclist = wxTopicService.getRelatedTopicList(id);
        if(topiclist == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }

        return Result.success(topiclist);
    }
}
