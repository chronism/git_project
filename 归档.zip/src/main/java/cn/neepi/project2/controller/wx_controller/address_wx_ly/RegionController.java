package cn.neepi.project2.controller.wx_controller.address_wx_ly;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.ShoppingMallModel.Region;
import cn.neepi.project2.service.wx_service.RegionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.CoderMalfunctionError;
import java.util.List;

@RestController
@RequestMapping("wx/region")
public class RegionController {
    @Autowired
    RegionService regionService;

    /**
     * 显示地区选项
     * @param pid
     * @return
     */
    @GetMapping("list")
    public Result showRegionalOptions(Integer pid) {
        List<Region> regionList = regionService.selectAllRegionByPid(pid);
        if(regionList == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(regionList);
    }
}
