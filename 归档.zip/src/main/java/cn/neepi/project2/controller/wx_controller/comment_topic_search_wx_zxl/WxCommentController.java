package cn.neepi.project2.controller.wx_controller.comment_topic_search_wx_zxl;

import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.service.wx_service.WxCommentService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("wx/comment")
public class WxCommentController {

    @Autowired
    WxCommentService wxCommentService;

    /**
     * 显示评论列表
     * @param valueId
     * @param page
     * @param showType
     * @param type
     * @return
     */
    @GetMapping("list")
    public Result getCommentList( Integer valueId,Integer page,Integer size,Byte showType,Byte type){

        HashMap map = wxCommentService.showCommentList(valueId,page,size,showType,type);
        if(map.isEmpty()) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(map);
    }

    /**
     * 发表评论
     * @param comment
     * @return
     */
    @PostMapping("post")
    public Result postComment(@RequestBody  Comment comment){
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        comment.setUserId(user.getId());
        Comment comment1 = wxCommentService.postComment(comment);
        if(comment1.getId() == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(comment1);
    }

    /**
     * 得到评论数量
     * @param valueId
     * @param type
     * @return
     */
    @GetMapping("count")
    public Result getCommentCount(Integer valueId,Byte type){
        HashMap map = wxCommentService.getCommentCount(valueId,type);
        if(map.isEmpty()){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(map);
    }

}
