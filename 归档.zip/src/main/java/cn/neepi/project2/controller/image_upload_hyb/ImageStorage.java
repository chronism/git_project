package cn.neepi.project2.controller.image_upload_hyb;

import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.Storage;
import cn.neepi.project2.service.ImageStorageService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.xml.ws.Action;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/27
 **/

@RestController
@Api("用于处理图片上传")
public class ImageStorage {

    @Autowired
    ImageStorageService imageStorageService;


    @RequestMapping(value = {"admin/storage/create","wx/storage/upload"})
    public Result imageUpload(MultipartFile file){

        Storage storage = imageStorageService.imageUpload(file, new Storage());
        if (storage==null){ return  new Result<>(602,"图片上传失败");
        }
        return Result.success(storage);

    }
}
