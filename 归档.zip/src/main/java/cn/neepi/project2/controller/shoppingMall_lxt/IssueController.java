package cn.neepi.project2.controller.shoppingMall_lxt;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Issue;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/29/029 下午 05:33
 */

@RestController
@RequestMapping("admin/issue/")
public class IssueController {
    @Autowired
    IssueService issueService;

    @GetMapping("issue/list")
    public Result listIssue(PageProperties pageProperties, String question) {
        ListItem<List<Issue>> listItem = issueService.queryIssues(pageProperties, question);
        List<Issue> list = listItem.getItems();
        if (list == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);

    }

    @PostMapping("issue/create")
    public Result createIssue(@RequestBody Issue issue) {

        if (issueService.createIssue(issue)) {
            return Result.success(issue);
        } else
            return Result.error(CodeMsg.SERVER_ERROR);

    }

    @PostMapping("issue/update")
    public Result updateIssue(@RequestBody Issue issue) {
        if (issueService.updateIssue(issue) != null) {
            return Result.success(issue);
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }

    @PostMapping("issue/delete")
    public Result deleteIssue(@RequestBody Issue issue) {
        if (issueService.deleteIssue(issue)) {
            return Result.success("");
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }

}
