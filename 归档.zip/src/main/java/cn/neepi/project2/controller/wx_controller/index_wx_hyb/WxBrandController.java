package cn.neepi.project2.controller.wx_controller.index_wx_hyb;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import cn.neepi.project2.service.wx_service.WxBrandService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@RestController
@RequestMapping("wx/brand")
public class WxBrandController {
    @Autowired
    WxBrandService wxBrandService;

    /**
     * 通过branId获取brand详细内容
     *
     * @param id
     * @return brand详情
     */
    @GetMapping("detail")
    public Result getBrandDetatil(Integer id) {
        Brand brand = wxBrandService.getBrandDetail(id);
        if (brand == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(new HashMap<String, Brand>() {{
            put("brand", brand);
        }});
    }

    @GetMapping("list")
    public Result getBrandList(Integer page, Integer size) {
        Map brandList = wxBrandService.getBrandList(page, size);
        if (brandList == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(brandList);
    }

}
