package cn.neepi.project2.controller.wx_controller.groupon_wx_xcy;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.responseModel.WxListItem;
import cn.neepi.project2.service.wx_service.WxGrouponService;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 团购管理
 *
 * @author xcy
 */
@RestController
@RequestMapping(value = "wx")
public class WxGrouponController {
    @Autowired
    WxGrouponService wxGrouponService;

    /**
     * 获取所有可参加团购的信息
     *
     * @param page
     * @param size
     * @return
     */
    @ApiOperation(value = "获取所有团购规则", notes = "获取团购", httpMethod = "GET")
    @RequestMapping(value = "groupon/list", method = RequestMethod.GET)
    public Result getGroupon(Integer page, Integer size) {
        WxListItem grouponList = wxGrouponService.getGroupList(page, size);
        if (grouponList != null) {
            return Result.success(grouponList);
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    @ApiOperation(value = "获取我的团购", notes = "我的团购", httpMethod = "GET")
    @RequestMapping(value = "groupon/my", method = RequestMethod.GET)
    public Result getMyGroupon(Integer showType) {
        // 0为发起的团购 1为参加的团购
        if (showType == 1 || showType == 0) {
            Subject subject = SecurityUtils.getSubject();
            User user = (User) subject.getPrincipal();
            Integer userId = user.getId();
            WxListItem myGrouponList = wxGrouponService.getMyGrouponList(userId, showType);
            if (myGrouponList != null) {
                return Result.success(myGrouponList);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    @ApiOperation(value = "团购的具体信息", notes = "团购细节", httpMethod = "GET")
    @RequestMapping(value = "groupon/detail", method = RequestMethod.GET)
    public Result getGrouponDetail(Integer grouponId) {
        if (grouponId > 0) {
            wxGrouponService.getGrouponDetail(grouponId);
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }
}
