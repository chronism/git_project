package cn.neepi.project2.controller.wx_controller.index_wx_hyb;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.wx_responseModel.HomeCategroyList;
import cn.neepi.project2.model.wx_responseModel.HomeResp;
import cn.neepi.project2.service.wx_service.WxIndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/29
 **/
@RestController
@RequestMapping("wx")
public class WxIndexController {

    @Autowired
    WxIndexService indexService;
    @GetMapping("home/index")
    public Result getHome(){
      HomeResp homeResp = indexService.getHome();
      if (homeResp==null){
          return Result.error(CodeMsg.SERVER_ERROR);
      }
        return Result.success(homeResp);
    }

    @GetMapping("goods/count")
    public Result getGoodsList(){
        Map<String,Long> map = new HashMap<>();
        Long goodsCount = indexService.getGoodsCount();
        map.put("goodsCount",goodsCount);
        return Result.success(map);
    }

    @GetMapping("catalog/index")
    public Result getCatalog(){
        HomeCategroyList homeCategroyList = indexService.getCatalog();
        if (homeCategroyList == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(homeCategroyList);
    }

    @GetMapping("catalog/current")
    public Result getCurrentCatalogList(Integer id){
        HomeCategroyList homeCategroyList = indexService.getCurrentCatalog(id);
        if (homeCategroyList == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(homeCategroyList);
    }

}
