package cn.neepi.project2.controller.wx_controller.collect_wx_lxt;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.wx_responseModel.CollectResponse;
import cn.neepi.project2.service.wx_service.WxCollectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("wx/collect")
public class WxCollectController {
    @Autowired
    WxCollectService wxCollectService;

    @PostMapping("addordelete")
    public Result addOrDeleteCollect(@RequestBody Map<String,Integer> map){
        Map map1 = wxCollectService.addOrDeleteCollect(map);
        if(map1==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(map1);
    }


    @GetMapping("list")
    public Result getCollectList(Byte type, PageProperties pageProperties){
        Map collectList = wxCollectService.getCollectList(type, pageProperties);
        if(collectList==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(collectList);
    }
}
