package cn.neepi.project2.controller.wx_controller.coupon_wx_xcy;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.responseModel.WxListItem;
import cn.neepi.project2.service.wx_service.WxCouponService;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 微信端优惠券管理
 *
 * @author xcy
 */
@RestController
@RequestMapping(value = "wx")
public class WxCouponController {

    @Autowired
    WxCouponService wxCouponService;

    @ApiOperation(value = "获得所有优惠券信息", notes = "查看所有优惠券", httpMethod = "GET", response = Result.class)
    @RequestMapping(value = "coupon/list", method = RequestMethod.GET)
    public Result getCouponList(Integer page, Integer size) {
        WxListItem couponList = wxCouponService.queryCouponList(page, size);
        if (couponList != null) {
            return Result.success(couponList);
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }


    @ApiOperation(value = "获取用户拥有的所有优惠券", notes = "我的优惠券", httpMethod = "GET", response = Result.class)
    @RequestMapping(value = "coupon/mylist", method = RequestMethod.GET)
    public Result getMyCoupons(Integer status, Integer page, Integer size) {
        // 获取当前用户对应信息
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Integer userId = user.getId();
        WxListItem myCouponList = wxCouponService.queryMyCouponList(userId, status, page, size);
        if (myCouponList != null) {
            return Result.success(myCouponList);
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    @ApiOperation(value = "领取优惠券", notes = "领取优惠券", httpMethod = "POST", response = Result.class)
    @RequestMapping(value = "coupon/receive", method = RequestMethod.POST)
    public Result receiveCoupon(@RequestBody Map map) {
        Integer couponId = (Integer) map.get("couponId");
        // 获取当前用户对应信息
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        if (user==null) {
            return new Result(502,"请登陆");
        }
        Integer userId = user.getId();
        if (couponId > 0) {
            int status = wxCouponService.receiveCoupon(couponId, userId);
            if (status == 1) {
                return Result.success(null);
            }
            if (status == 740) {
                return Result.error(CodeMsg.COUPON_HAS_RECEIVED);
            }
            if (status == 400) {
                return Result.error(CodeMsg.SERVER_ERROR);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 兑换优惠券
     *
     * @param map
     * @return
     */
    @ApiOperation(value = "兑换优惠券", notes = "兑换优惠券", httpMethod = "POST", response = Result.class)
    @RequestMapping(value = "coupon/exchange", method = RequestMethod.POST)
    public Result exchangeCoupon(@RequestBody Map map) {
        String code = (String) map.get("code");
        // 前端做过非空判断 但是不能相信前端
        if (code != null && !"".equals(code)) {
            // 获取当前用户对应信息
            Subject subject = SecurityUtils.getSubject();
            User user = (User) subject.getPrincipal();
            int userId = user.getId();
            int i = wxCouponService.exchangeCoupon(code, userId);
            if (i == 1) {
                return Result.success(null);
            }
            if (i == 742) {
                return Result.error(CodeMsg.COUPON_CODE_ERROR);
            }
            if (i == 740) {
                return Result.error(CodeMsg.COUPON_HAS_RECEIVED);
            }
            if (i == 400) {
                return Result.error(CodeMsg.SERVER_ERROR);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    @RequestMapping(value = "coupon/selectlist", method = RequestMethod.GET)
    public Result selectCoupon(Integer cartId, Integer grouponRulesId) {
        if (cartId >= 0 && grouponRulesId >= 0) {
            List coupons = wxCouponService.selectCoupon(cartId, grouponRulesId);
            if (coupons != null) {
                return Result.success(coupons);
            }
        }

        return Result.error(CodeMsg.SERVER_ERROR);
    }

}
