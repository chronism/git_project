package cn.neepi.project2.controller.wx_controller.index_wx_hyb;

import cn.neepi.project2.aoplog.logannotation.WxLoginAndFootprint;
import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.wx_responseModel.GoodsCategroyGoodList;
import cn.neepi.project2.model.wx_responseModel.GoodsCategroyList;
import cn.neepi.project2.model.wx_responseModel.GoodsDetail;
import cn.neepi.project2.service.wx_service.WxGoodsService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@RestController
@RequestMapping("wx/goods")
public class WxGoodsController {

    @Autowired
    WxGoodsService wxGoodsService;

    /**
     * 通过id获取类目列表
     * @param id
     * @return 类目列表
     */
    @GetMapping("category")
    public Result getGoodsCategoryList(Integer id){
        GoodsCategroyList goodsCategroyList = wxGoodsService.getGoodsCategoryList(id);
        if (goodsCategroyList==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(goodsCategroyList);
    }

    /**
     * 通过类目id获取子类目列表
     * @param categoryId
     * @param page
     * @param size
     * @return 子类目
     */
    @GetMapping(value = "list")
    public Result getCategoryGoods(Integer categoryId,Integer page, Integer size,Integer brandId){
        GoodsCategroyGoodList goodList = null;
        if (categoryId!=null) {
             goodList = wxGoodsService.getCategoryGoods(categoryId, page, size, CateGory.class);
        }else if (brandId !=null){
           goodList = wxGoodsService.getCategoryGoods(brandId,page,size, Brand.class);
        }
        if (goodList==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(goodList);
    }

    @GetMapping(value = "list",params = {"keyword","page","size","sort","order","categoryId"})
    public Result getSearch(PageProperties pageProperties,String keyword){
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        System.out.println("goods"+session.getId());
        User user = (User) subject.getPrincipal();
        List<Map<String,String>> keywordHistory = (List<Map<String, String>>) session.getAttribute("keywordHistory");
        if (user==null){
            if (keywordHistory == null){
                keywordHistory =new ArrayList<>();
                Map<String,String> map = new LinkedHashMap<>();
                map.put("keyword",keyword);
                keywordHistory.add(map);
                session.setAttribute("keywordHistory",keywordHistory);
            }else {
                Map<String,String> map = new LinkedHashMap<>();
                map.put("keyword",keyword);
                keywordHistory.add(map);
                session.setAttribute("keywordHistory",keywordHistory);
            }
        }else {
            wxGoodsService.addSearchHistory(keyword,user.getId());
        }

        GoodsCategroyGoodList goodList = wxGoodsService.getGoodsList(pageProperties,keyword);
        if (goodList==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(goodList);
    }

    /**
     * 通过id获取商品详情
     * @param id
     * @return 商品详情
     */
    @WxLoginAndFootprint("会员足迹")
    @GetMapping("detail")
    public Result getGoodsDetail(Integer id){

        GoodsDetail goodsDetail = wxGoodsService.getGoodsDetail(id);
        if (goodsDetail==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(goodsDetail);
    }

    /**
     * 通过商品id获取商品父类展示相关商品
     * @param id
     * @return 相关商品列表
     */
    @GetMapping("related")
    public Result getRelatedGoodsList(Integer id){
        List<Goods> goodsList = wxGoodsService.getRelatedGoodsList(id);
        if (goodsList==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        Map map = new HashMap();
        map.put("goodsList",goodsList);

        return Result.success(map);
    }

}
