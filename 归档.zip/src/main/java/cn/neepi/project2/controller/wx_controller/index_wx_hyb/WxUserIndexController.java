package cn.neepi.project2.controller.wx_controller.index_wx_hyb;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.wx_responseModel.UserIndex;
import cn.neepi.project2.service.wx_service.WxIndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@RestController
@RequestMapping("wx/user")
public class WxUserIndexController {

    @Autowired
    WxIndexService wxIndexService;

    @RequestMapping("index")
    public Result getUserIndex() {
        UserIndex userIndex = wxIndexService.getUserIndex();
        if (userIndex == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }

        return Result.success(new HashMap() {{
            put("order", userIndex);
        }});

    }

}
