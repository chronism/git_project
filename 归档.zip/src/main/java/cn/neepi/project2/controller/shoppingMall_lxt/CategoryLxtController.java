package cn.neepi.project2.controller.shoppingMall_lxt;

import cn.neepi.project2.exception.shoppingMallException.CategoryChangeInvalidException;
import cn.neepi.project2.exception.shoppingMallException.CategoryNameRepeatedException;
import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import cn.neepi.project2.model.ShoppingMallModel.CateGoryL1;
import cn.neepi.project2.service.ShoppingMallManagerService.CategoryManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("admin/category")
public class CategoryLxtController {
    @Autowired
    CategoryManagerService categoryManagerService;

    @RequestMapping(value = "category/list",method = RequestMethod.GET)
    public Result getCategoryList(){
        List<CateGory> categoryList = categoryManagerService.getCategoryList();
        if(categoryList ==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(categoryList);
    }

    @RequestMapping(value = "category/l1",method = RequestMethod.GET)
    public Result getCategoryL1(){
        List<CateGoryL1> categoryL1 = categoryManagerService.getCategoryL1();
        if(categoryL1==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(categoryL1);
    }

    @RequestMapping(value = "category/create",method = RequestMethod.POST)
    public Result createCategory(@RequestBody @Validated CateGory cateGory) throws CategoryNameRepeatedException {
        CateGory cateGory1 = categoryManagerService.addCateGory(cateGory);
        if(cateGory1==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(cateGory1);
    }

    @RequestMapping(value = "category/update",method = RequestMethod.POST)
    public Result updateCategory(@RequestBody @Validated CateGory cateGory) throws CategoryNameRepeatedException, CategoryChangeInvalidException {
        CateGory cateGory1 = categoryManagerService.updateCateGory(cateGory);
        if(cateGory1==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(cateGory1);
    }

    @RequestMapping(value = "category/delete",method = RequestMethod.POST)
    public Result deleteCategory(@RequestBody CateGory cateGory){
        Boolean aBoolean = categoryManagerService.deleteCateGory(cateGory);
        if(!aBoolean){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(null);
    }
}
