package cn.neepi.project2.controller.wx_controller.comment_topic_search_wx_zxl;


import cn.neepi.project2.mapper.GoodsMapper;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.wx_responseModel.SearchIndex;
import cn.neepi.project2.service.wx_service.WxSearchService;
import org.apache.commons.collections.map.LinkedMap;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.lang.System;
import java.util.*;


@RestController
@RequestMapping("wx/search")
public class WxSearchController {

    @Autowired
    WxSearchService wxSearchService;
    @Autowired
    GoodsMapper goodsMapper;


    /**
     * 搜索关键字
     */


    @GetMapping("index")
    public Result getIndex(){
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        User user = (User) subject.getPrincipal();
        List<Map<String,String>> keywordHistory = (List<Map<String, String>>) session.getAttribute("keywordHistory");
        System.out.println("index"+session.getId());
        if(user==null){
        if (keywordHistory==null){
             keywordHistory =new ArrayList<>();
             session.setAttribute("keywordHistory",keywordHistory);
        }
        }else {
            keywordHistory = wxSearchService.searchKeywords(user.getId());

        }
       List<Keyword> list = wxSearchService.searchHotKeywords();
       Keyword keyword = wxSearchService.searchDefaultKeyword();
        Map map = new LinkedHashMap();
        map.put("defaultKeyword",keyword);
        map.put("historyKeywordList",keywordHistory);
        map.put("hotKeywordList",list);

        return Result.success(map);
    }

    //@--Mapping("result")
/**
    //搜索帮助
    @GetMapping("helper")
    public Result getHelper(String keyword){

    }
*/
    //搜索历史清除
    @PostMapping("clearhistory")
    public Result clearHistory(){
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        User user = (User) subject.getPrincipal();
        List<Map<String,String>> keywordHistory = (List<Map<String, String>>) session.getAttribute("keywordHistory");
        System.out.println("clearhistory"+session.getId());
        if(user==null){
                keywordHistory =new ArrayList<>();
                session.setAttribute("keywordHistory",keywordHistory);
        }else {
            wxSearchService.clearKeyWords(user.getId());
        }
       return Result.success(0);
    }

    @GetMapping("helper")
    public Result searchHelper(String keyword){
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        System.out.println("helper"+session.getId());
        User user = (User) subject.getPrincipal();
        List<Map<String,String>> keywordHistory = (List<Map<String, String>>) session.getAttribute("keywordHistory");
        List<String> history = new ArrayList<>();
        if(user==null){
            if (keywordHistory!=null){
                for (Map<String, String> m :
                        keywordHistory) {

                    for (String key:m.keySet()){
                       if(m.get(key).contains(keyword)){
                           history.add(m.get(key));
                       }
                    }
                }
            }
        }else {
           history = wxSearchService.getHistory(keyword);
        }
        return Result.success(history);
    }

}
