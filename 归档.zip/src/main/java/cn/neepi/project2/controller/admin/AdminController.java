package cn.neepi.project2.controller.admin;

import cn.neepi.project2.aoplog.logannotation.LoginAndLogout;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.responseModel.Dashboard;
import cn.neepi.project2.service.AdminService;
import cn.neepi.project2.service.DashboardService;
import cn.neepi.project2.shiro.CustomToken;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.subject.Subject;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@RestController
@RequestMapping("admin")
@Api("用于处理后台管理员登录注册") //描述类/接口的主要用途
//@ApiOperation //描述方法用途
//@ApiImplicitParam //描述方法的参数
//@ApiImplicitParams //描述方法的参数(Multi-Params)
//@ApiIgnore //忽略某类/方法/参数的文档
public class AdminController {

    @Autowired
    AdminService adminService;

    @Autowired
    DashboardService dashboardService;

    @ApiOperation(value="用户登录", notes="用户登录接口",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "登录信息",value = "账号和密码", required = true, dataType = "loginVo")
    @RequestMapping(value = "auth/login",method = {RequestMethod.GET,RequestMethod.POST})
    @LoginAndLogout("登录")
    public Result login(@RequestBody LoginVo loginVo){
        CustomToken authenticationToken = new CustomToken(loginVo.getUsername(), loginVo.getPassword(),"admin");
        Subject subject = SecurityUtils.getSubject();
        try {
            subject.login(authenticationToken);
        } catch (AuthenticationException e) {
            return Result.error(CodeMsg.PASSWORD_ERROR);
            //e.printStackTrace();
        }
        Serializable id = subject.getSession().getId();

        return Result.success(id);
    }


    @ApiOperation(value="获取用户权限", notes="权限接口",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "口令",value = "token", required = true, dataType = "String")
    @RequestMapping(value = "auth/info",method = RequestMethod.GET)
    public Result info(String token){
        Subject subject = SecurityUtils.getSubject();
        Admin admin = (Admin) subject.getPrincipal();
        InfoData data = new InfoData();
        data.setAvatar(admin.getAvatar());
        data.setName(admin.getUsername());
        List<String> perms = adminService.getPermissions(admin);
        data.setPerms(perms);
        List<String> roles = adminService.getRoles(admin);
        data.setRoles(roles);
        return Result.success(data);
    }

    @ApiOperation(value="获取总条目数", notes="Dashboard接口",httpMethod = "GET",response = Result.class)
    @RequestMapping("dashboard")
    public Result dashboard(){
        Dashboard totalNumbers = dashboardService.getTotalNumbers();
        if (totalNumbers==null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(totalNumbers);
    }

    @PostMapping("auth/logout")
    public Result logout(){
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
        return Result.success(null);
    }

    @PostMapping("profile/password")
    public Result changePassword(@RequestBody Map<String ,String> map){
        String oldPassword = map.get("oldPassword");
        String newPassword = map.get("newPassword");
        String newPassword2 = map.get("newPassword2");
        Subject subject = SecurityUtils.getSubject();
        Admin admin = (Admin) subject.getPrincipal();
        if (!BCrypt.checkpw(oldPassword,admin.getPassword())) {
            return new Result(602,"旧密码错误");
        }
        if (!newPassword.equals(newPassword2)){
            return new Result(602,"两次输入的新密码不相同");
        }
        adminService.changePassword(newPassword,admin);
        return Result.success("重置密码成功");
    }


}
