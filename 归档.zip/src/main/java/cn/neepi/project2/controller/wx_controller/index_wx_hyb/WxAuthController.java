package cn.neepi.project2.controller.wx_controller.index_wx_hyb;

import cn.neepi.project2.aoplog.logannotation.WxLoginAndFootprint;
import cn.neepi.project2.config.AliyunConfig;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.wx_requestModel.WxLoginRequest;
import cn.neepi.project2.model.wx_requestModel.WxRegister;
import cn.neepi.project2.service.wx_service.WxAuthService;
import cn.neepi.project2.shiro.CustomToken;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@RestController
@RequestMapping("wx/auth")
public class WxAuthController {

    @Autowired
    WxAuthService authService;

    @Autowired
    AliyunConfig aliyunConfig;

    /**
     * 登陆认证
     *
     * @param loginVo
     * @return 成功或者失败
     */
    @WxLoginAndFootprint("登陆")
    @PostMapping("login")
    public Result wxLogin(@RequestBody LoginVo loginVo) {
        CustomToken authenticationToken = new CustomToken(loginVo.getUsername(), loginVo.getPassword(), "wxrealm");
        Subject subject = SecurityUtils.getSubject();

        try {
            subject.login(authenticationToken);
        } catch (AuthenticationException e) {
            return Result.error(CodeMsg.PASSWORD_ERROR);
            //e.printStackTrace();
        }
        Serializable id = subject.getSession().getId();

        User user = (User) subject.getPrincipal();
        Map map = new HashMap();
        map.put("token", id);
        map.put("userInfo", new HashMap() {{
            put("avatarUrl", user.getAvatar());
            put("nickName", user.getNickname());
        }});

        return Result.success(map);
    }

    @PostMapping("logout")
    public Result wxLogout() {
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
        return Result.success(null);
    }

    @WxLoginAndFootprint("登陆")
    @PostMapping("login_by_weixin")
    public Result loginByWx(@RequestBody WxLoginRequest loginRequest) {
        CustomToken authenticationToken = new CustomToken(loginRequest.getUserInfo().getAvatarUrl(), loginRequest.getUserInfo().getAvatarUrl(), "openid");
        Subject subject = SecurityUtils.getSubject();
        try {
            subject.login(authenticationToken);
        } catch (AuthenticationException e) {
            subject.getSession().setAttribute("wxOpenId", loginRequest);
            Serializable id = subject.getSession().getId();
            Map map = new HashMap();
            map.put("token", id);
            return Result.forward(CodeMsg.WX_REGISTER,map);
        }
        Serializable id = subject.getSession().getId();
        User user = (User) subject.getPrincipal();
        Map map = new HashMap();
        map.put("token", id);
        map.put("userInfo", new HashMap() {{
            put("avatarUrl", user.getAvatar());
            put("nickName", user.getNickname());
        }});

        return Result.success(map);
    }

    @WxLoginAndFootprint("登陆")
    @PostMapping("register")
    public Result register(@RequestBody WxRegister wxRegister){
        Subject subject = SecurityUtils.getSubject();
        WxLoginRequest wx = (WxLoginRequest) subject.getSession().getAttribute("wxOpenId");
        User user = null;
        if (wx==null){
         user = authService.register(wxRegister);
        }else {
           user = authService.register(wx,wxRegister);
        }
        if (user.getId()==-1){
            return Result.error(CodeMsg.CODE_ERROR);
        }
        if(user.getId()==-2){
            return new Result(402,"账号名重复");
        }
        CustomToken authenticationToken = new CustomToken(wxRegister.getUsername(), wxRegister.getPassword(), "wx");
        try {
            subject.login(authenticationToken);
        } catch (AuthenticationException e) {
            return Result.error(CodeMsg.PASSWORD_ERROR);
            //e.printStackTrace();
        }
        User principal = (User) subject.getPrincipal();
        Map map = new HashMap();
        map.put("token", subject.getSession().getId());
        map.put("userInfo", new HashMap() {{
            put("avatarUrl", principal.getAvatar());
            put("nickName", principal.getNickname());
        }});
        return Result.success(map);
    }
    @PostMapping("regCaptcha")
    public Result regCaptcha(@RequestBody Map<String,String> mobile ){
/*        if (!mobile.matches("^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$")){
            return Result.error(CodeMsg.SERVER_ERROR);
        }*/

        aliyunConfig.sendMsg(mobile.get("mobile"));
        return Result.success(null);
    }
}
