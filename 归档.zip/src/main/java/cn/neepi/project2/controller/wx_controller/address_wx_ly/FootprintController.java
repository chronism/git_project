package cn.neepi.project2.controller.wx_controller.address_wx_ly;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Footprint;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.User;
import cn.neepi.project2.service.wx_service.FootprintService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("wx/footprint")
public class FootprintController {

    @Autowired
    FootprintService footprintService;

    /**
     * 分页显示物流信息
     * @param page
     * @param size
     * @return
     */
    @GetMapping("list")
    public Result showFootprintList(Integer page,Integer size) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Integer id = user.getId();
        HashMap map = footprintService.selectFootprint(id,page,size);
        if(map == null) {
            return Result.error(CodeMsg.BIND_ERROR);
        }
        return Result.success(map);
    }

    /**
     * 删除足迹
     * @param footprint
     * @return
     */
    @PostMapping("delete")
    public Result deleteFootprint(@RequestBody Footprint footprint) {
        Integer footprintId = footprint.getId();
        Integer i = footprintService.deleteFootprint(footprintId);
        if(i == null) {
            return Result.error(CodeMsg.BIND_ERROR);
        }
        return Result.success(0);
    }
}
