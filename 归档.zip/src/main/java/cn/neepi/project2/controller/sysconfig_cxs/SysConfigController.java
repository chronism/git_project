package cn.neepi.project2.controller.sysconfig_cxs;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.responseModel.ExpressConfigCxs;
import cn.neepi.project2.model.responseModel.MallConfigCxs;
import cn.neepi.project2.model.responseModel.OrderConfigCxs;
import cn.neepi.project2.model.responseModel.WxConfigCxs;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.service.SysConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/26/026 下午 09:07
 */

@RestController
@RequestMapping("admin/config")
public class SysConfigController {
    @Autowired
    SysConfigService sysConfigService;

    /**
     * 商场配置
     * @return
     */
    @GetMapping("/mall")
    public Result queryMall() {
        MallConfigCxs mallConfigCxs = sysConfigService.queryMall();
        if (mallConfigCxs == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(mallConfigCxs);
    }

    @PostMapping("/mall")
    public Result updateMall(@RequestBody @Valid MallConfigCxs mallConfigCxs) {
        int num = sysConfigService.updateMall(mallConfigCxs);
        /*if (num == 1) {
            return Result.error(CodeMsg.BIND_ERROR.fillArgs("参数不全，更新失败"));
        } else if (num == 2) {
            return Result.error(CodeMsg.BIND_ERROR.fillArgs("电话号码格式有误，请重新输入"));
        } else if (num == 3) {
            return Result.error(CodeMsg.BIND_ERROR.fillArgs("qq号格式有误，请重新输入"));

        } else { }*/
            return Result.success("");
    }

    /**
     * 运费配置
     * @returnd
     */
    @GetMapping("/express")
    public Result queryExpress() {
        ExpressConfigCxs expressConfigCxs = sysConfigService.queryExpress();
        if (expressConfigCxs == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(expressConfigCxs);
    }

    @PostMapping("/express")
    public Result updateExpress(@RequestBody @Valid ExpressConfigCxs expressConfigCxs) {
        int num = sysConfigService.updateExpress(expressConfigCxs);
        if (num == 1) {
            return Result.error(CodeMsg.BIND_ERROR.fillArgs("输入非法,请输入大于0的正整数"));
        } else {
            return Result.success("");
        }
    }

    /**
     * 订单配置
     * @return
     */
    @GetMapping("/order")
    public Result queryOrder() {
        OrderConfigCxs orderConfigCxs = sysConfigService.queryOrder();
        if (orderConfigCxs == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(orderConfigCxs);
    }

    @PostMapping("/order")
    public Result updateOrder(@RequestBody @Valid OrderConfigCxs orderConfigCxs) {
        int num = sysConfigService.updateOrder(orderConfigCxs);
        if (num == 1) {
            return Result.error(CodeMsg.BIND_ERROR.fillArgs("输入非法,请输入大于0的正整数"));
        } else {
            return Result.success("");
        }
    }

    /**
     * 小程序配置
     * @return
     */
    @GetMapping("/wx")
    public Result queryWx() {
        WxConfigCxs wxConfigCxs = sysConfigService.queryWx();
        if (wxConfigCxs == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(wxConfigCxs);
    }

    @PostMapping("/wx")
    public Result updateWx(@RequestBody @Valid WxConfigCxs wxConfigCxs) {
        int num = sysConfigService.updateWx(wxConfigCxs);
        if (num == 1) {
            return Result.error(CodeMsg.BIND_ERROR.fillArgs("输入非法,请输入大于0的正整数"));
        } else {
            return Result.success("");
        }
    }

}
