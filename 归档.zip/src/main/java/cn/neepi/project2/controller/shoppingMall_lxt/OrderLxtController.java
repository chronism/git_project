package cn.neepi.project2.controller.shoppingMall_lxt;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.ShoppingMallModel.Order;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.responseModel.OrderDetailLxt;
import cn.neepi.project2.service.ShoppingMallManagerService.OrderManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("admin/order")
public class OrderLxtController {
    @Autowired
    OrderManagerService orderManagerService;

    @RequestMapping(value = "order/list", method = RequestMethod.GET)
    public Result getOrderList(PageProperties pageProperties, Integer userId, String orderSn, Short[] orderStatusArray){
        ListItem<List<Order>> orderList = orderManagerService.getOrderList(pageProperties, userId, orderSn, orderStatusArray);
        if(orderList==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }else{
            return Result.success(orderList);
        }
    }

    @RequestMapping(value = "order/detail" , method = RequestMethod.GET)
    public Result getOrderDetail(Integer id){
        OrderDetailLxt orderDetail = orderManagerService.getOrderDetail(id);
        if(orderDetail==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }else{
            return Result.success(orderDetail);
        }
    }

    @PostMapping("order/ship")
    public Result shipOrder(@RequestBody Map map){
        String s = orderManagerService.shipOrder(map);
        if(s==null){
            return Result.error(CodeMsg.ORDER_SHIP_ERROR);
        }else{
            return Result.success(s);
        }
    }
    @PostMapping("order/refund")
    public Result shipRefund(@RequestBody Map map){
        String s = orderManagerService.refundOrder(map);
        if(s==null){
            return Result.error(CodeMsg.ORDER_REFUND_ERROR);
        }else{
            return Result.success(s);
        }
    }
    @PostMapping("order/reply")
    public Result replyOrder(@RequestBody Map map){
        Integer commentId = (Integer) map.get("commentId");
        String content = (String) map.get("content");
       // orderManagerService.replyComment(commentId,)
        return new Result(402,"目前无法回复 请联系管理员添加该功能") ;
    }

}
