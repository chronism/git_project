package cn.neepi.project2.controller.shoppingMall_lxt;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Keyword;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.KeywordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/30/030 上午 08:57
 */
@RestController
@RequestMapping("admin/keyword")
public class KeywordController {
    @Autowired
    KeywordService keywordService;

    @GetMapping("/keyword/list")
    public Result listKeyWord(PageProperties pageProperties, String keyword,String url) {
        ListItem<List<Keyword>> listItem = keywordService.queryIssues(pageProperties,keyword,url);
        List<Keyword> list = listItem.getItems();
        if(list !=null){
            return Result.success(listItem);
        }else{
            return Result.error(CodeMsg.SERVER_ERROR);
        }
    }

    @PostMapping("/keyword/create")
    public Result createKeyWord(@RequestBody Keyword keyword){
        if(keywordService.createKeyword(keyword)){
            return Result.success(keyword);
        }else{
            return Result.error(CodeMsg.SERVER_ERROR);
        }
    }

    @PostMapping("/keyword/update")
    public Result updateKeyWord(@RequestBody Keyword keyword){
        if(keywordService.updateKeyword(keyword)){
            return Result.success(keyword);
        }else{
            return Result.error(CodeMsg.SERVER_ERROR);
        }
    }

    @PostMapping("/keyword/delete")
    public Result deleteKeyWord(@RequestBody Keyword keyword){
        if(keywordService.deleteKeyword(keyword)){
            return Result.success("");
        }else{
            return Result.error(CodeMsg.SERVER_ERROR);
        }
    }
}
