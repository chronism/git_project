package cn.neepi.project2.controller.wx_controller.address_wx_ly;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Feedback;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.User;
import cn.neepi.project2.service.wx_service.FeedbackService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("wx/feedback")
public class FeedbackController {
    @Autowired
    FeedbackService feedbackService;
    @PostMapping("submit")
    public Result submitFeedback(@RequestBody Feedback feedback) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Integer id = user.getId();
        feedback.setUserId(id);
        Integer i = feedbackService.insertFeedback(feedback);
        if(i == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(0);
    }
}
