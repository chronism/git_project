package cn.neepi.project2.controller.shoppingMall_lxt;

import cn.neepi.project2.exception.shoppingMallException.ManufacturerRepeatedException;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.service.ShoppingMallManagerService.BrandManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("admin/brand")
public class BrandLxtController {
    @Autowired
    BrandManagerService brandManagerService;

    @RequestMapping(value = "brand/list", method = RequestMethod.GET)
    public Result getBrandList(PageProperties pageProperties, String name, Integer id) {
        ListItem<List<Brand>> listItem = brandManagerService.getBrandList(pageProperties, name, id);
        if (listItem == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);
    }
    @RequestMapping(value = "brand/create",method = RequestMethod.POST)
    public Result createBrand(@RequestBody @Validated Brand brand) throws ManufacturerRepeatedException{
        Brand newBrand = brandManagerService.addBrand(brand);
        if (newBrand == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(brand);
    }

    @RequestMapping(value = "brand/update" ,method = RequestMethod.POST)
    public Result updateBrand(@RequestBody @Validated Brand brand) throws ManufacturerRepeatedException {
        Brand updateBrand = brandManagerService.updateBrand(brand);
        if (updateBrand == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(brand);
    }

    @RequestMapping(value = "brand/delete",method = RequestMethod.POST)
    public Result deleteBrand(@RequestBody Brand brand){
        Boolean aBoolean = brandManagerService.deleteBrand(brand);
        if(!aBoolean){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(null);
    }
}
