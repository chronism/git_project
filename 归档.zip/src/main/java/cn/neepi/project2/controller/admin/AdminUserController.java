package cn.neepi.project2.controller.admin;

import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@RestController
@Api("用于管理用户数据")
@RequestMapping("admin/user")
public class AdminUserController {
    @Autowired
    UserService userService;

    @ApiOperation(value="显示用户表单", notes="用户显示接口",httpMethod = "GET",response = Result.class)
    @GetMapping("user/list")
    public Result getUserList(PageProperties pageProperties,String username,String mobile){
        ListItem<List<User>> list = userService.getUserList(pageProperties,username,mobile);
        if (list==null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(list);
    }

    @ApiOperation(value = "显示用户地址",notes = "用户地址显示接口",httpMethod = "GET",response = Result.class)
    @GetMapping("address/list")
    @RequiresPermissions("admin:address:list")
    public Result getAddressList(PageProperties pageProperties,Integer userId,String name){
                ListItem<List<Address>> listItem = userService.getAddressList(pageProperties,userId,name);
                if (listItem==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);
    }

    @ApiOperation(value = "显示会员收藏商品",notes = "会员收藏商品接口",httpMethod = "GET",response = Result.class)
    @GetMapping("collect/list")
    public Result getCollectList(PageProperties pageProperties, @Validated Integer userId,@Validated Integer valueId){
        ListItem<List<Collect>> listItem = userService.getCollectList(pageProperties,userId,valueId);
        if (listItem==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);
    }

    @ApiOperation(value = "显示会员历史足迹",notes = "会员历史足迹接口",httpMethod = "GET",response = Result.class)
    @GetMapping("footprint/list")
    public Result getFootprintList(PageProperties pageProperties,@Validated Integer userId,@Validated Integer goodsId){
        ListItem<List<Footprint>> listItem = userService.getFootprintList(pageProperties,userId,goodsId);
        if (listItem==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);
    }

    @ApiOperation(value = "显示搜索历史",notes = "搜索历史接口",httpMethod = "GET",response = Result.class)
    @GetMapping("history/list")
    public Result getHistoryList(PageProperties pageProperties,@Validated Integer userId ,String keyword){
        ListItem<List<SearchHistory>> listItem = userService.getHistoryList(pageProperties,userId,keyword);

        if (listItem==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);

    }

    @ApiOperation(value = "意见反馈",notes = "意见反馈接口",httpMethod = "GET",response = Result.class)
    @GetMapping("feedback/list")
    public Result getFeedbackList(PageProperties pageProperties,String username,@Validated Integer id){
        ListItem<List<Feedback>> listItem=userService.getFeedbackList(pageProperties,username,id);
        if (listItem==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);
    }
}
