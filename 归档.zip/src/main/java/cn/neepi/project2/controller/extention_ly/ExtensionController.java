package cn.neepi.project2.controller.extention_ly;

import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.ExtensionService;
import com.github.pagehelper.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("admin")
@Api("用于处理推广模块") //描述类/接口的主要用途
//@ApiOperation //描述方法用途
//@ApiImplicitParam //描述方法的参数
//@ApiImplicitParams //描述方法的参数(Multi-Params)
//@ApiIgnore //忽略某类/方法/参数的文档
public class ExtensionController {

    @Autowired
    ExtensionService extensionService;

    @ApiOperation(value="分页显示广告", notes="分页显示广告接口，name，content模糊查询",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "广告信息",value = "广告内容", required = true, dataType = "loginVo")
    @GetMapping("ad/list")
    public Result showAdByList(PageProperties page,String name,String content) {
        ListItem<List<Ad>>  ads = extensionService.getAdByList(page,name,content);
        if (ads == null) {
            return Result.error(CodeMsg.BIND_ERROR);
        }
        return Result.success(ads);
    }

    @ApiOperation(value="新增广告", notes="新增广告",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "新增广告",value = "新增广告", required = true, dataType = "loginVo")
    @PostMapping("ad/create")
    public Result addAd(@RequestBody Ad ad) {
        Ad addAd =  extensionService.addAd(ad);
        if(addAd.getId() == null) {

            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(addAd);
    }
    @ApiOperation(value="更新广告", notes="更新广告",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "更新广告",value = "更新广告", required = true, dataType = "loginVo")
    @PostMapping("ad/update")
    public Result adUpdate(@RequestBody Ad ad) {
        Integer i = extensionService.adUpdate(ad);
        if(i == null) {

            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(ad);
    }
    @ApiOperation(value="删除广告", notes="删除广告",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "删除广告",value = "删除广告", required = true, dataType = "loginVo")
    @PostMapping("ad/delete")
    public Result deleteAd(@RequestBody Ad ad) {
        Integer i = extensionService.deleteAd(ad);
        if(i == null) {

            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.error(CodeMsg.SUCCESS);
    }


    @ApiOperation(value="分页显示优惠券", notes="分页显示优惠券接口",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "优惠券",value = "优惠券", required = true, dataType = "loginVo")
    @GetMapping("coupon/list")
    public Result showCoupon(PageProperties page,String name,Integer type,Integer status) {
        ListItem<List<Coupon>>  coupons = extensionService.getCoupon(page,name,type,status);
        if (coupons == null) {
            return Result.error(CodeMsg.BIND_ERROR);
        }
        return Result.success(coupons);
    }
    @ApiOperation(value="增加优惠券", notes="增加优惠券",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "优惠券",value = "优惠券", required = true, dataType = "loginVo")
    @PostMapping("coupon/create")
    public Result createCoupon(@RequestBody @Validated Coupon coupon) {
        Coupon coupon1 = extensionService.insertCoupon(coupon);
        if (coupon1 == null) {
            return Result.error(CodeMsg.BIND_ERROR);
        }
        return Result.success(coupon1);
    }  @ApiOperation(value="优惠券详情页", notes="优惠券详情页",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "优惠券",value = "优惠券", required = true, dataType = "loginVo")
    @GetMapping("coupon/read")
    public Result showCouponById(Integer id) {
        Coupon coupon = extensionService.getCouponById(id);
        if (coupon.getId() == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(coupon);
    }
    @ApiOperation(value="优惠券使用情况", notes="优惠券使用情况",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "优惠券",value = "优惠券", required = true, dataType = "loginVo")
    @GetMapping("coupon/listuser")
    public Result showCouponUser(PageProperties page,CouponUser couponUser) {
        ListItem<List<CouponUser>> couponUserList = extensionService.selectCouponUserByPage(page,couponUser);
        if(couponUserList == null ) {
        return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(couponUserList);
    }
    @ApiOperation(value="修改优惠券", notes="修改优惠券",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "优惠券",value = "优惠券", required = true, dataType = "loginVo")
    @PostMapping("coupon/update")
    public Result updateCoupon(@RequestBody Coupon coupon) {
        Integer i = extensionService.updateCoupon(coupon);
        if(i == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(coupon);
    }
    @ApiOperation(value="删除优惠券", notes="删除优惠券",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "优惠券",value = "优惠券", required = true, dataType = "loginVo")
    @PostMapping("coupon/delete")
    public Result deleteCoupon(@RequestBody  Coupon coupon) {
        Integer i = extensionService.deleteCoupon(coupon);
        if(i == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(0);
    }

    @ApiOperation(value="分页显示专题", notes="分页显示专题",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "专题",value = "专题", required = true, dataType = "loginVo")
    @GetMapping("topic/list")
    public Result showTopics(PageProperties page,String title ,String subtitle) {

        ListItem<List<Topic>> topics = extensionService.getTopicByPage(page,title,subtitle);
        if(topics == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(topics);
    }

    @ApiOperation(value="增加专题", notes="增加专题",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "增加专题",value = "增加专题", required = true, dataType = "loginVo")
    @PostMapping("topic/create")
    public Result createTopic(@RequestBody  Topic topic) {
        Topic topic1 = extensionService.insertTopic(topic);
        if(topic1.getId() == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(topic1);
    }
    @ApiOperation(value="修改专题", notes="修改专题",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "修改专题",value = "修改专题", required = true, dataType = "loginVo")
    @PostMapping("topic/update")
    public Result updateTopic(@RequestBody  Topic topic) {
        Integer i = extensionService.updateTopic(topic);
        if(i == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(topic);
    }
    @ApiOperation(value="删除专题", notes="删除专题",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "删除专题",value = "删除专题", required = true, dataType = "loginVo")
    @PostMapping("topic/delete")
    public Result deleteTopic(@RequestBody Topic topic) {
        Integer i = extensionService.deleteTopic(topic);
        if(i == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.error(CodeMsg.SUCCESS);
    }
    @ApiOperation(value="分页显示团购规则信息", notes="分页显示团购规则信息",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "团购规则",value = "团购规则", required = true, dataType = "loginVo")
    @GetMapping("groupon/list")
    public Result showGrouponRules(PageProperties page,Integer goodsId) {

        ListItem<List<GrouponRules>> grouponRules = extensionService.getGrouponRulesByPage(page,goodsId);
        if(grouponRules == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(grouponRules);
    }
    @ApiOperation(value="增加团购", notes="增加团购",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "增加团购",value = "增加团购", required = true, dataType = "loginVo")
    @PostMapping("groupon/create")
    public Result createGrouponRules(@RequestBody  GrouponRules grouponRules) {
        GrouponRules grouponRules1 = extensionService.createGrouponRules(grouponRules);
        if(grouponRules1.getId() == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(grouponRules1);
    }
    @ApiOperation(value="修改团购", notes="修改团购",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "修改团购",value = "修改团购", required = true, dataType = "loginVo")
    @PostMapping("groupon/update")
    public Result updateGroupon(@RequestBody  GrouponRules grouponRules) {
        Integer i = extensionService.updateGrouponRules(grouponRules);
        if(i == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.error(CodeMsg.SUCCESS);
    }
    @ApiOperation(value="删除团购", notes="删除团购",httpMethod = "POST",response = Result.class)
    @ApiImplicitParam(name = "删除团购",value = "删除团购", required = true, dataType = "loginVo")
    @PostMapping("groupon/delete")
    public Result deleteGrouponRules(@RequestBody  GrouponRules GrouponRules) {
        Integer i = extensionService.deleteGrouponRules(GrouponRules);
        if(i == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.error(CodeMsg.SUCCESS);
    }
    @ApiOperation(value="分页显示团购活动参与信息", notes="分页显示团购活动参与信息",httpMethod = "GET",response = Result.class)
    @ApiImplicitParam(name = "团购参与信息",value = "团购参与信息", required = true, dataType = "loginVo")
    @GetMapping("groupon/listRecord")
    public Result showGroupon(PageProperties page,Integer goodsId) {

        ListItem<List<Object>> groupons = extensionService.getGrouponByPage(page,goodsId);
        if(groupons == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(groupons);
    }
}
