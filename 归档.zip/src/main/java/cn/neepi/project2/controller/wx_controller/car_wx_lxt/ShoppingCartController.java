package cn.neepi.project2.controller.wx_controller.car_wx_lxt;

import cn.neepi.project2.model.Cart;
import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.wx_requestModel.WxCartCheckOut;
import cn.neepi.project2.model.wx_responseModel.CartConfirmation;
import cn.neepi.project2.model.wx_responseModel.CartIndex;
import cn.neepi.project2.service.wx_service.WxCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@RestController
@RequestMapping("wx/cart")
public class ShoppingCartController {
    @Autowired
    WxCartService wxCartService;

    @GetMapping("goodscount")
    public Result cartCount(){
        Integer cartGoodsCount = wxCartService.getCartGoodsCount();
        if(cartGoodsCount==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(cartGoodsCount);
    }

    @GetMapping("index")
    public Result getCartIndex(){
        CartIndex cartIndex = wxCartService.getCartIndex();
        if(cartIndex==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(cartIndex);
    }

    @Transactional(rollbackFor = Exception.class)
    @PostMapping("add")
    public Result addCart(@RequestBody Cart cart){
        Integer integer = wxCartService.addCart(cart);
        if(integer==null||integer==0){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(integer);
    }

    @Transactional(rollbackFor = Exception.class)
    @PostMapping("checked")
    public Result checkedCart(@RequestBody Map map){
        CartIndex cartIndex = wxCartService.checkedCart(map);
        if(cartIndex==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(cartIndex);
    }

    @PostMapping("update")
    public Result updateCart(@RequestBody Cart cart){
        Integer integer = wxCartService.updateCart(cart);
        if(integer==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(integer);
    }

    @PostMapping("delete")
    public Result deleteCart(@RequestBody Map map){
        CartIndex cartIndex = wxCartService.deleteCart(map);
        if(cartIndex==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(cartIndex);
    }

    @GetMapping("checkout")
    public Result checkoutCart(WxCartCheckOut wxCartCheckOut){
        CartConfirmation cartConfirmation = wxCartService.checkoutCart(wxCartCheckOut);
        if(cartConfirmation==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(cartConfirmation);
    }

    @PostMapping("fastadd")
    public Result fastAddCart(@RequestBody Map map){
        Integer integer = wxCartService.fastAddCart(map);
        if(integer==null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(integer);
    }
}
