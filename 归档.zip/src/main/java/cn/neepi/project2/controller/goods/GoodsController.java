package cn.neepi.project2.controller.goods;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Comment;
import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.Result;
import cn.neepi.project2.model.requestModel.GoodsCreateCxs;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.GoodsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



import java.util.HashMap;

import java.util.List;


@RestController
@Api("商品管理")
@RequestMapping("admin")
public class GoodsController {

    @Autowired
    GoodsService goodsService;

    @ApiOperation(value = "商品列表", notes = "商品显示接口", httpMethod = "GET", response = Result.class)
    @GetMapping("goods/list")
    public Result getGoodsList(PageProperties pageProperties, String goodsSn, String name) {
        ListItem<List<Goods>> list = goodsService.getGoodsList(pageProperties, goodsSn, name);
        if (list == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(list);
    }

    @ApiOperation(value = "商品删除", notes = "商品删除接口", httpMethod = "POST", response = Result.class)
    @PostMapping("goods/delete")
    public Result goodsDelete(@RequestBody Goods goods) {
        Integer i = goodsService.goodsDelete(goods);
        if (i == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(goods);
    }

    @ApiOperation(value = "商品更新", notes = "商品更新接口", httpMethod = "POST", response = Result.class)
    @PostMapping("goods/update")
    public Result goodsUpdate(@RequestBody GoodsCreateCxs info) {
        Integer integer = goodsService.goodsUpdate(info);
        if (integer!=0){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(null);
    }

    @ApiOperation(value="商品类别", notes="商品类别接口",httpMethod = "GET",response = Result.class)
    @GetMapping("goods/catAndBrand")
    public Result catAndBrand(){
        HashMap map = goodsService.queryCatAndBrand();
       if(map == null){
           return Result.error(CodeMsg.SERVER_ERROR);
       }
        return  Result.success(map);
    }

    @ApiOperation(value="商品评价", notes="商品评价接口",httpMethod = "GET",response = Result.class)
    @GetMapping("comment/list")
    public Result getCommentList(PageProperties pageProperties, Integer valueId, Integer userId) {
        ListItem<List<Comment>> list = goodsService.getCommentList(pageProperties, valueId, userId);
        if (list == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(list);
    }

    @ApiOperation(value = "评价删除", notes = "商品删除接口", httpMethod = "POST", response = Result.class)
    @PostMapping("comment/delete")
    public Result commentDelete(@RequestBody Comment comment) {
        Integer i = goodsService.commentDelete(comment);
        if (i == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(comment);
    }

    @ApiOperation(value = "商品上架", notes = "商品上架接口", httpMethod = "POST", response = Result.class)
    @PostMapping("goods/create")
    public Result create(@RequestBody GoodsCreateCxs info) {
        int i = goodsService.createGoods(info);
        if (i == 0) {
            return Result.success("");
        } else {
            return Result.error(CodeMsg.GOODS_NAME_REPEAT);
        }
    }

    @ApiOperation(value="显示商品详情", notes="显示商品详情",httpMethod = "GET",response = Result.class)
    @GetMapping("goods/detail")
    public Result showGoodsDetail(Integer id){
        HashMap map = goodsService.getGoodsDetail(id);
        if(map == null){
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(map);
    }
}
