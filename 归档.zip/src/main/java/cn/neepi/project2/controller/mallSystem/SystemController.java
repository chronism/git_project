package cn.neepi.project2.controller.mallSystem;

import cn.neepi.project2.aoplog.logannotation.LoginAndLogout;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.*;
import com.github.pagehelper.util.StringUtil;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * 系统管理模块
 *
 * @author xcy
 */
@RestController
@RequestMapping(value = "admin/system")
public class SystemController {
    @Autowired
    AdminService adminService;
    @Autowired
    RoleService roleService;
    @Autowired
    LogService logService;
    @Autowired
    ImageStorageService storageService;

    /**
     * 获得对应的admin
     *
     * @param pageProperties 分页信息
     * @return admin的list
     */
    @ApiOperation(value = "获取对应username的管理员", notes = "管理员查询", httpMethod = "GET", response = Result.class)
    @RequiresPermissions(value = {"admin:admin:list"})
    @LoginAndLogout("获取管理员")
    @RequestMapping(value = "/admin/list", method = RequestMethod.GET)
    public Result getAdminList(PageProperties pageProperties, String username) {
        ListItem<List<Admin>> listItem = adminService.queryAdmin(pageProperties, username);
        List<Admin> items = listItem.getItems();
        if (items == null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(listItem);
    }

    /**
     * 获得所有角色信息
     *
     * @return RoleResp的List
     */
    @ApiOperation(value = "获取所有的角色", notes = "角色获取", httpMethod = "GET", response = Result.class)
    // @RequiresPermissions(value = {"admin:admin:list"}) 没有对应权限要求
    @LoginAndLogout("角色获取")
    @RequestMapping(value = "/role/options")
    public Result getRoleOptions() {
        List roleList = roleService.queryRole();
        if (roleList == null) {
            Result<Object> error = Result.error(CodeMsg.SERVER_ERROR);
            return error;
        }
        Result<List> success = Result.success(roleList);
        return success;
    }

    /**
     * 创建admin 不能同名判断还没做
     *
     * @param admin username,password,roleIds
     * @return User
     */
    @ApiOperation(value = "新建管理员", notes = "管理员创建", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:admin:create"})
    @LoginAndLogout("管理员创建")
    @RequestMapping(value = "/admin/create", method = RequestMethod.POST)
    public Result creatAdmin(@RequestBody @Validated Admin admin) {
        if (admin != null && !StringUtil.isEmpty(admin.toString())) {
        /*int PASSWORD_LENGTH = 6;
        // 管理员名称不符合规定
        // 管理员密码长度不能小于6
        if (admin.getPassword().length() < PASSWORD_LENGTH) {
            Result<Object> error = Result.error(CodeMsg.ADMIN_PASSWORD_SHORT);
            return error;
        }*/
            Admin admin1 = adminService.createAdmin(admin);
            // 管理员已经存在 因为直接返回 所以deleted没设置
            if (admin1.getDeleted() == null) {
                return Result.error(CodeMsg.ADMIN_EXSIT);
            }

            if (admin1 == null) {
                Result<Object> error = Result.error(CodeMsg.SERVER_ERROR);
                return error;
            }
            Result<Admin> success = Result.success(admin1);
            return success;
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 更新admin 修改更新时间
     *
     * @param admin
     * @return
     */
    @ApiOperation(value = "根据传入的Admin对象更新管理员", notes = "管理员更新", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:admin:update"})
    @LoginAndLogout("管理员更新")
    @RequestMapping(value = "admin/update", method = RequestMethod.POST)
    public Result updateAdmin(@Validated @RequestBody Admin admin) {
        if (admin != null && !StringUtil.isEmpty(admin.toString())) {
            Admin admin1 = adminService.updateAdmin(admin);
            // 用户名已经存在
            if (admin1.getId() == 0) {
                Result.error(CodeMsg.ADMIN_EXSIT);
            }
            Result<Admin> success = Result.success(admin);
            return success;
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 删除admin 假删 把delete改成true
     *
     * @param admin
     * @return
     */
    @ApiOperation(value = "删除对应id的管理员", notes = "删除管理员", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:admin:delete"})
    @LoginAndLogout("删除管理员")
    @RequestMapping(value = "admin/delete", method = RequestMethod.POST)
    public Result deleteAdmin(@Validated @RequestBody Admin admin) {
        if (admin != null && !StringUtil.isEmpty(admin.toString())) {
            Integer integer = adminService.deleteAdmin(admin);
            if (integer == 1) {
                return Result.success(null);
            }
            if (integer == 500) {
                return Result.error(CodeMsg.SERVER_ERROR);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 获取对应的log记录 name为模糊查找的管理员名
     *
     * @param pageProperties
     * @param name
     * @return
     */
    @ApiOperation(value = "根据username获取日志", notes = "日志查询", httpMethod = "GET", response = Result.class)
    @RequiresPermissions(value = {"admin:log:list"})
    @LoginAndLogout("获取日志")
    @RequestMapping(value = "log/list", method = RequestMethod.GET)
    public Result getLogList(PageProperties pageProperties, String name) {
        if (pageProperties != null && !StringUtil.isEmpty(pageProperties.toString())) {
            ListItem listItem = logService.queryLogList(pageProperties, name);
            Result<ListItem> success = Result.success(listItem);
            return success;
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 获取对应的role
     *
     * @param pageProperties 分页信息
     * @param name           模糊查找role名
     * @return
     */
    @ApiOperation(value = "获取对应name的角色", notes = "角色查询", httpMethod = "GET", response = Result.class)
    @RequiresPermissions(value = {"admin:role:list"})
    @LoginAndLogout("获取角色")
    @RequestMapping(value = "role/list", method = RequestMethod.GET)
    public Result getRoleList(PageProperties pageProperties, String name) {
        if (pageProperties != null && !StringUtil.isEmpty(pageProperties.toString())) {
            ListItem listItem = roleService.queryRoleList(pageProperties, name);
            Result<ListItem> success = Result.success(listItem);
            return success;
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 新建role
     *
     * @param role
     * @return
     */
    @ApiOperation(value = "根据传入的Role创建角色", notes = "角色创建", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:role:create"})
    @LoginAndLogout(value = "角色创建")
    @RequestMapping(value = "role/create", method = RequestMethod.POST)
    public Result createRole(@RequestBody @Validated Role role) {
        if (role != null && !StringUtil.isEmpty(role.toString())) {
            Role role1 = roleService.createRole(role);
            if (role1 == null) {
                return Result.error(CodeMsg.SERVER_ERROR);
            }
            Result<Role> success = Result.success(role1);
            return success;
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 更新role
     *
     * @param role
     * @return
     */
    @ApiOperation(value = "根据传入的Role更新角色", notes = "角色更新", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:role:update"})
    @LoginAndLogout(value = "角色更新")
    @RequestMapping(value = "role/update", method = RequestMethod.POST)
    public Result updateRole(@RequestBody @Validated Role role) {
        if (role != null && !StringUtil.isEmpty(role.toString())) {
            Role role1 = roleService.updateRole(role);
            if (role1 != null) {
                // 角色已经存在
                if (role1.getId() == 0) {
                    return Result.error(CodeMsg.ROLE_EXSIT);
                }
                return Result.success(role1);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 删除role
     *
     * @param role
     * @return
     */
    @ApiOperation(value = "根据传入的Role删除角色", notes = "角色删除", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:role:delete"})
    @LoginAndLogout(value = "删除角色")
    @RequestMapping(value = "role/delete", method = RequestMethod.POST)
    public Result deleteRole(@RequestBody @Validated Role role) {
        if (role != null && !StringUtil.isEmpty(role.toString())) {
            Role role1 = roleService.deleteRole(role);
            if (role1 != null) {
                Result<Role> success = Result.success(role1);
                return success;
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 查找对应的storage
     *
     * @param pageProperties
     * @param key
     * @param name
     * @return
     */
    @ApiOperation(value = "根据传入的key和name搜索对象", notes = "查找对象", httpMethod = "GET", response = Result.class)
    @RequiresPermissions(value = {"admin:storage:list"})
    @LoginAndLogout(value = "查找对象")
    @RequestMapping(value = "storage/list", method = RequestMethod.GET)
    public Result getStorageList(PageProperties pageProperties, String key, String name) {
        if (pageProperties != null && !StringUtil.isEmpty(pageProperties.toString())) {
            ListItem listItem = storageService.queryStorage(pageProperties, key, name);
            // 是否需要做判断
            Result<ListItem> success = Result.success(listItem);
            return success;
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 更新图片名
     *
     * @param storage
     * @return
     */
    @ApiOperation(value = "根据传入的Storage修改对象名", notes = "对象修改", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:storage:update"})
    @LoginAndLogout(value = "对象修改")
    @RequestMapping(value = "storage/update", method = RequestMethod.POST)
    public Result updateStorageName(@RequestBody @Validated Storage storage) {
        if (storage != null && !StringUtil.isEmpty(storage.toString())) {
            Storage storage1 = storageService.updateStorage(storage);
            if (storage1 != null) {
                return Result.success(storage1);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 删除图片
     *
     * @param storage
     * @return
     */
    @ApiOperation(value = "删除对应对象", notes = "对象删除", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:storage:delete"})
    @LoginAndLogout(value = "删除对象")
    @RequestMapping(value = "storage/delete", method = RequestMethod.POST)
    public Result deleteStorage(@RequestBody @Validated Storage storage) {
        if (storage != null && !StringUtil.isEmpty(storage.toString())) {
            Storage storage1 = storageService.deleteStorage(storage);
            if (storage1 != null) {
                return Result.success(storage1);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 获取所有的permissions
     *
     * @return
     */
    @ApiOperation(value = "获取所有的权限", notes = "权限获取", httpMethod = "GET", response = Result.class)
    @RequiresPermissions(value = {"admin:role:permissions:get"})
    @LoginAndLogout(value = "权限获取")
    @RequestMapping(value = "role/permissions", method = RequestMethod.GET)
    public Result getRolePermissions(Integer roleId) {
        if (roleId != 0) {
            Map data = roleService.getPermissions(roleId);
            if (data != null && !"".equals(data)) {
                return Result.success(data);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }

    /**
     * 设置role的权限 增加和减少的相关逻辑都要做
     *
     * @return
     */
    @ApiOperation(value = "修改role对应的权限", notes = "权限修改", httpMethod = "POST", response = Result.class)
    @RequiresPermissions(value = {"admin:role:permissions:update"})
    @LoginAndLogout(value = "修改权限")
    @RequestMapping(value = "role/permissions", method = RequestMethod.POST)
    public Result setRolePermission(@RequestBody Map map) {
        Integer roleId = (Integer) map.get("roleId");
        List<String> permissions = (List<String>) map.get("permissions");
        if (roleId != 0) {
            int sum = roleService.setPermission(roleId, permissions);
            if (sum >= -1) {
                return Result.success(null);
            }
        }
        return Result.error(CodeMsg.SERVER_ERROR);
    }
}
