package cn.neepi.project2.controller.shoppingMall_lxt;

import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.ShoppingMallModel.Region;
import cn.neepi.project2.model.Result;

import cn.neepi.project2.service.ShoppingMallManagerService.RegionManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("admin/region")
public class RegionLxtController {
    @Autowired
    RegionManagerService regionManagerService;

    @RequestMapping("region/list")
    public Result getRegionList(){
        int pid =0;
        List<Region> regionList = regionManagerService.getRegionList(pid);
        if (regionList==null) {
            return Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(regionList);
    }

}
