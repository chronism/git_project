package cn.neepi.project2.controller.wx_controller.order_wx_cxs;

import cn.neepi.project2.exception.order_wx_exception.LowStocksException;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.RequestModel.CommentCreateCxs;
import cn.neepi.project2.model.RequestModel.OrderSubmitConditionCxs;
import cn.neepi.project2.service.WxOrderService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.aspectj.apache.bcel.classfile.Code;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/31/031 上午 07:35
 */

@RequestMapping("wx/order/")
@RestController
public class WxOrderController {
    @Autowired
    WxOrderService wxOrderService;

    @RequestMapping("list")
    public Result list(Integer showType, int page, int size) {
        Map<String, Object> map = wxOrderService.orderList(showType, page, size);
        if (map != null) {
            return Result.success(map);
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }

    @RequestMapping("detail")
    public Result detail(Integer orderId) {
        Map<String, Object> map = wxOrderService.orderDetail(orderId);
        if (map != null) {
            return Result.success(map);
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }


    @RequestMapping("cancel")
    public Result cancel(@RequestBody Map<String, String> map) {
        //取消订单（待付款阶段）
        String orderId = map.get("orderId");
        int update = wxOrderService.orderCancel(orderId);
        if (update != 0) {
            return Result.success("");
        } else
            //语句出错报RuntimeException会直接逐级向上抛到Controller层后,
            //被GlobalExceptionHandler捕获异常并return Result.error(CodeMsg.SERVER_ERROR);
            return Result.error(CodeMsg.SERVER_ERROR);
    }

    @RequestMapping("refund")
    public Result refund(@RequestBody Map<String, String> map) {
        //取消订单（已付款阶段）
        String orderId = map.get("orderId");
        int update = wxOrderService.orderRefund(orderId);
        if (update != 0) {
            return Result.success("");
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }

    @RequestMapping("confirm")
    public Result confirm(@RequestBody Map<String, String> map) {

        String orderId = map.get("orderId");
        int update = wxOrderService.orderConfirm(orderId);
        if (update != 0) {
            return Result.success("");
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }

    @RequestMapping("prepay")
    public Result prepay(@RequestBody Map<String, String> map) throws LowStocksException {
        String orderId = map.get("orderId");
        int update = wxOrderService.orderPrepay(orderId);
        if (update != 0) {
            return Result.success("");
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }

    @RequestMapping("delete")
    public Result delete(@RequestBody Map<String, String> map) {
        String orderId = map.get("orderId");
        int update = wxOrderService.orderDelete(orderId);
        if (update != 0) {
            return Result.success("");
        } else
            return Result.error(CodeMsg.SERVER_ERROR);
    }

    @RequestMapping("goods")
    public Result goods(Integer orderId, Integer goodsId) {
        List<OrderGoods> orderGoodsList = wxOrderService.commentGoods(orderId, goodsId);
        if(orderGoodsList !=null){
            return Result.success(orderGoodsList.get(0));
        }else
            return Result.error(CodeMsg.SERVER_ERROR);

    }

    @PostMapping("comment")
    public Result comment(@RequestBody CommentCreateCxs comment) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        wxOrderService.commitComment(comment.getOrderGoodsId(), comment.getContent(), comment.getStar(), comment.getHasPicture(), user.getId(),comment.getPicUrls());
       return Result.success("");

    }

    @RequestMapping("submit")
    public Result submit(@RequestBody OrderSubmitConditionCxs orderSubmitCondition){
        //提交订单,返回新创建的订单id
        Integer orderId = wxOrderService.submit(orderSubmitCondition);
        if(orderId != null){
            HashMap<String, Integer> map = new HashMap<>();
            map.put("orderId",orderId);
            return Result.success(map);
        }else
        return Result.error(CodeMsg.SERVER_ERROR);
    }

}
