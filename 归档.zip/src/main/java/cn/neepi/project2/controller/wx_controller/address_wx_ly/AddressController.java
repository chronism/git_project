package cn.neepi.project2.controller.wx_controller.address_wx_ly;

import cn.neepi.project2.model.*;
import cn.neepi.project2.service.wx_service.RegionService;
import cn.neepi.project2.service.wx_service.WxAddressService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("wx")
public class AddressController {

    @Autowired
    WxAddressService wxAdressService;
    /**
     * 显示用户地址管理列表
     * @return
     */
    @GetMapping("address/list")
    public Result showAllAdressByUserId() {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Integer id = user.getId();
        List<Address_liuyu> addressList = wxAdressService.selectAllAdressByUserId(id);
        if(addressList == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(addressList);
    }

    /**
     * 显示地址详情
     * @return
     */
    @GetMapping("address/detail")
    public Result showDeatilAdressById(Integer id) {
        Address address = wxAdressService.selectAddressById(id);
        if( address == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(address);
    }
    /**
     * 保存地址
     * 保存更新或新建的地址，将原地址置为不可见
     * @return
     */
    @PostMapping("address/save")
    public Result saveAddress(@RequestBody Address address) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        address.setUserId(user.getId());
        Integer i = wxAdressService.updateAddress(address);
        if( i == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(0);
    }
    /**
     * 删除地址
     * 将地址置为不可见
     * @return
     */
    @PostMapping("address/delete")
    public Result saveAddress(@RequestBody User address) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Integer userId = user.getId();
        Integer id = address.getId();
        Integer i = wxAdressService.deleteAddress(id,userId);
        if( i == null) {
            return  Result.error(CodeMsg.SERVER_ERROR);
        }
        return Result.success(0);
    }

}
