package cn.neepi.project2.config;

import cn.neepi.project2.shiro.*;

import org.apache.shiro.realm.Realm;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;
import java.util.*;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/26
 **/
@Configuration
public class ShiroConfig {


    @Bean
    public ShiroFilterFactoryBean shiroFilterFactoryBean(DefaultWebSecurityManager securityManager){
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        shiroFilterFactoryBean.setSecurityManager(securityManager);

        shiroFilterFactoryBean.setLoginUrl("/admin/redirect");

        LinkedHashMap<String,String> filterChainDefinitionMap = new LinkedHashMap<>();
        filterChainDefinitionMap.put("/admin/auth/login","anon");

        /**swagger拦截配置*/
        filterChainDefinitionMap.put("/swagger-ui.html", "anon");
        filterChainDefinitionMap.put("/swagger-resources/**", "anon");
        filterChainDefinitionMap.put("/swagger-resources", "anon");
        filterChainDefinitionMap.put("/v2/api-docs", "anon");
        filterChainDefinitionMap.put("/webjars/springfox-swagger-ui/**", "anon");
        filterChainDefinitionMap.put("/druid/**","anon");

        /*微信放行*/

        filterChainDefinitionMap.put("/wx/order/**","authc");
        filterChainDefinitionMap.put("/wx/user/**","authc");
        filterChainDefinitionMap.put("/wx/**","anon");
        filterChainDefinitionMap.put("/wx/auth/**","anon");
        filterChainDefinitionMap.put("/wx/home/**","anon");
        filterChainDefinitionMap.put("/wx/goods/**","anon");
        filterChainDefinitionMap.put("/wx/cart/goodscount","anon");
        filterChainDefinitionMap.put("/wx/catalog/**","anon");
        filterChainDefinitionMap.put("/wx/brand/**","anon");
        filterChainDefinitionMap.put("/wx/topic/**","anon");
        filterChainDefinitionMap.put("/wx/comment/**","anon");
        filterChainDefinitionMap.put("/wx/feedback/**","anon");
        filterChainDefinitionMap.put("/wx/search/**","anon");

        Map<String, Filter> filters = new HashMap<>();
        filters.put("authc",new ShiroAuthFilter());
        shiroFilterFactoryBean.setFilters(filters);

        filterChainDefinitionMap.put("/**","authc");
        shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
        return shiroFilterFactoryBean;
    }

    @Bean
    public DefaultWebSecurityManager defaultWebSecurityManager(CustomSessionManager sessionManager,
                                                               CustomRealmAuthenticator authenticator,
                                                               AdminRealm adminRealm,
                                                               WxRealm wxRealm,
                                                               WxOpenIdRealm wxOpenIdRealm){
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        List<Realm> list =new ArrayList<>();
        list.add(adminRealm);
        list.add(wxRealm);
        list.add(wxOpenIdRealm);
        securityManager.setRealms(list);
        securityManager.setSessionManager(sessionManager);
        securityManager.setAuthenticator(authenticator);
        return securityManager;
    }

    /**
     * 声明式鉴权 注解所需要的组件
     * @param securityManager
     * @return
     */
    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(DefaultWebSecurityManager securityManager){
        AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor=new AuthorizationAttributeSourceAdvisor();
        authorizationAttributeSourceAdvisor.setSecurityManager(securityManager);
        return authorizationAttributeSourceAdvisor;
    }

    @Bean
    public static DefaultAdvisorAutoProxyCreator getDefaultAdvisorAutoProxyCreator() {

        DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
        defaultAdvisorAutoProxyCreator.setUsePrefix(true);

        return defaultAdvisorAutoProxyCreator;
    }

    @Bean
    public CustomSessionManager sessionManager(){
        CustomSessionManager sessionManager = new CustomSessionManager();
        sessionManager.setDeleteInvalidSessions(true);
        sessionManager.setGlobalSessionTimeout(3600000);
        return sessionManager;
    }

    @Bean
    public CustomRealmAuthenticator customRealmAuthenticator(AdminRealm adminRealm,
                                                             WxRealm wxRealm,
                                                             WxOpenIdRealm wxOpenIdRealm){
        CustomRealmAuthenticator authenticator = new CustomRealmAuthenticator();
        ArrayList<Realm> realms = new ArrayList<>();
        realms.add(adminRealm);
        realms.add(wxRealm);
        realms.add(wxOpenIdRealm);
        authenticator.setRealms(realms);
        return authenticator;
    }

}
