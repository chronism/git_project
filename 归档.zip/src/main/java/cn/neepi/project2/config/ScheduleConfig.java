package cn.neepi.project2.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;


/**
 * 用于启动定时任务 → 刷新coupon
 *
 * @author xcy
 */
@SpringBootApplication
@EnableScheduling
public class ScheduleConfig {

    public static void main(String[] args) {
        SpringApplication.run(ScheduleConfig.class, args);
    }
}
