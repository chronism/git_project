package cn.neepi.project2.shiro;

import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.UserExample;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/31
 **/
@Component
public class WxOpenIdRealm extends AuthorizingRealm {

    @Autowired
    UserMapper userMapper;

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        return null;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        String username = token.getUsername();

        UserExample userExample = new UserExample();
        userExample.createCriteria().andWeixinOpenidEqualTo(username);
        List<User> users = userMapper.selectByExample(userExample);
        if (users.isEmpty()){
            return null;
        }
        User user = users.get(0);
        String openId = user.getWeixinOpenid();
        return new SimpleAuthenticationInfo(user,openId,getName());
    }
}
