package cn.neepi.project2.shiro;

import cn.neepi.project2.mapper.AdminMapper;
import cn.neepi.project2.mapper.PermissionMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.*;
import com.github.pagehelper.util.StringUtil;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authc.credential.SimpleCredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/26
 **/
@Component
public class AdminRealm extends AuthorizingRealm {

    @Autowired
    AdminMapper adminMapper;
    @Autowired
    PermissionMapper permissionMapper;
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        Admin admin = (Admin) principalCollection.getPrimaryPrincipal();
        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();

        List<String> permissions = permissionMapper.selectByRoleIds(admin.getRoleIds());
        authorizationInfo.addStringPermissions(permissions);
        return authorizationInfo;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        String username = token.getUsername();

        AdminExample adminExample= new AdminExample();
        adminExample.createCriteria().andUsernameEqualTo(username);

        List<Admin> admins = adminMapper.selectByExample(adminExample);
        if (admins.size()<1){
            return null;
        }
        Admin admin = admins.get(0);
        String passwordFromDb = admin.getPassword();


        return new SimpleAuthenticationInfo(admin,passwordFromDb,getName());
    }

    @PostConstruct
    public void initCredentialsMatcher(){
        setCredentialsMatcher(new BCryptCredentialsMatcher());
    }

}
