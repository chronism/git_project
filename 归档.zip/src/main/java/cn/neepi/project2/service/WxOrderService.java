package cn.neepi.project2.service;

import cn.neepi.project2.exception.order_wx_exception.LowStocksException;
import cn.neepi.project2.model.OrderGoods;
import cn.neepi.project2.model.RequestModel.OrderSubmitConditionCxs;

import java.util.List;
import java.util.Map;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/31/031 上午 07:36
 */
public interface WxOrderService {
    Map<String,Object> orderList(Integer showType,int page, int size);

    Map<String,Object> orderDetail(Integer orderId);

    int orderPrepay(String orderId) throws LowStocksException;

    int orderCancel(String orderId);

    int orderRefund(String orderId);

    int orderConfirm(String orderId);

    int orderDelete(String orderId);

    List<OrderGoods> commentGoods(Integer orderId, Integer goodsId);

    void commitComment(Integer orderGoodsId, String content, Short star, Boolean hasPicture, Integer id, String[] picUrls);

    Integer submit(OrderSubmitConditionCxs orderSubmitCondition);

}
