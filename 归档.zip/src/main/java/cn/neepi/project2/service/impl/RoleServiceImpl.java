package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.AdminMapper;
import cn.neepi.project2.mapper.CskaoyanMallSystemPermissionsMapper;
import cn.neepi.project2.mapper.PermissionMapper;
import cn.neepi.project2.mapper.RoleMapper;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.responseModel.PermissionResp;
import cn.neepi.project2.model.responseModel.RoleResp;
import cn.neepi.project2.service.RoleService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    RoleMapper roleMapper;
    @Autowired
    CskaoyanMallSystemPermissionsMapper permissionRespMapper;
    @Autowired
    PermissionMapper permissionMapper;
    @Autowired
    AdminMapper adminMapper;

    @Override
    public List queryRole() {
        RoleExample roleExample = new RoleExample();
        // 需要未被删除的role
        RoleExample.Criteria criteria = roleExample.createCriteria();
        criteria.andDeletedEqualTo(false);
        //error
        List<Role> roles = roleMapper.selectByExample(roleExample);
        List<RoleResp> roleResps = new ArrayList<>();
        for (Role role : roles) {
            RoleResp roleResp = new RoleResp();
            roleResp.setValue(role.getId());
            roleResp.setLabel(role.getName());
            roleResps.add(roleResp);
        }
        return roleResps;
    }

    @Override
    public ListItem queryRoleList(PageProperties pageProperties, String name) {
        RoleExample roleExample = new RoleExample();
        RoleExample.Criteria criteria = roleExample.createCriteria();
        if (name != null) {
            criteria.andNameLike("%" + name + "%");
        }
        // 需要未被删除的role
        criteria.andDeletedEqualTo(false);
        // 排序 分页
        roleExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        // 调用mapper
        List<Role> roles = roleMapper.selectByExample(roleExample);
        ListItem<List<Role>> roleListItem = new ListItem<>();
        roleListItem.setItems(roles);
        roleListItem.setTotal(roleMapper.countByExample(roleExample));
        return roleListItem;
    }

    @Override
    public Role createRole(Role role) {
        // enable
        role.setEnabled(true);
        // addTime updateTime
        Date date = new Date();
        role.setAddTime(date);
        role.setUpdateTime(date);
        // deleted
        role.setDeleted(false);
        int insert = roleMapper.insert(role);
        if (insert == 1) {
            return role;
        } else {
            return null;
        }
    }

    @Override
    public Role updateRole(Role role) {
        // 判断同名 如果存在将id设为0后返回
        String name = role.getName();
        RoleExample roleExample = new RoleExample();
        RoleExample.Criteria criteria = roleExample.createCriteria();
        criteria.andIdNotEqualTo(role.getId());
        criteria.andNameEqualTo(name);
        List<Role> roles = roleMapper.selectByExample(roleExample);
        if (roles.size() != 0) {
            role.setId(0);
            return role;
        }
        // 更新时间
        Date date = new Date();
        role.setUpdateTime(date);
        // update
        int i = roleMapper.updateByPrimaryKey(role);
        if (i == 1) {
            return role;
        }
        return null;
    }

    @Override
    public Role deleteRole(Role role) {
        // 更新时间
        Date date = new Date();
        role.setUpdateTime(date);
        // 假删除
        role.setDeleted(true);
        int i = roleMapper.updateByPrimaryKey(role);
        if (i == 1) {
            return role;
        }
        return null;
    }

    @Override
    public Map getPermissions(Integer roleId) {
        // 需要systemPermissions,assignedPermissions两个键值对
        // systemPermissions
        List<PermissionResp> systemPermissions = permissionRespMapper.selectAllPermissons();
        HashMap<String, List> respMap = new HashMap<>();
        respMap.put("systemPermissions", systemPermissions);
        // assignedPermissions
        List<String> assignedPermissions = new ArrayList<>();
        // 超级管理员 有所有权限 permission一开始是个* 所以需要从system_permission查所有api ！= null的值
        if (roleId == 1) {
            assignedPermissions = permissionRespMapper.selectAllApis();
        } else {
            Integer[] roleIds = {roleId};
            assignedPermissions = permissionMapper.selectByRoleIds(roleIds);
        }
        respMap.put("assignedPermissions", assignedPermissions);
        return respMap;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Integer setPermission(Integer roleId, List<String> permissions) {
        // 基础建设
        Permission permission = new Permission();
        permission.setRoleId(roleId);
        // String format1 = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        LocalDateTime now = LocalDateTime.now();
        Date date = new Date();
        SimpleDateFormat simpleDateFormat =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // String format = simpleDateFormat.format(date);
        permission.setAddTime(date);
        permission.setUpdateTime(date);
        permission.setDeleted(false);
        // 具体逻辑 先增后减
        Integer[] id = {roleId};
        List<String> roleOldPerm = permissionMapper.selectByRoleIds(id);
        // 如果不为0 判断新增了哪些 并插入
        int sum = 0;
        for (String perm : permissions) {
            // 是新增的 则插入
            if (!roleOldPerm.contains(perm)) {
                permission.setPermission(perm);
                int insert = permissionMapper.insert(permission);
                sum += insert;
            }
            // 原来有的 做更新 并把这个perm从old表删除
            if (roleOldPerm.contains(perm)) {
                permission.setPermission(perm);
                Integer integer = permissionMapper.updateDateAndDeleted(date, roleId, perm);
                sum += integer;
                roleOldPerm.remove(perm);
            }
        }
        // old表中剩下的 假删
        if (roleOldPerm.size() != 0) {
            for (String oldPerm : roleOldPerm) {
                Integer integer = permissionMapper.deleteByIdAndPermission(roleId, oldPerm);
                sum += integer;
            }
        }
        return sum;
    }
}
