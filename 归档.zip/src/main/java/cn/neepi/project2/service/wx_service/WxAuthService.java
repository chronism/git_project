package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.LoginVo;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.wx_requestModel.WxLoginRequest;
import cn.neepi.project2.model.wx_requestModel.WxRegister;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
public interface WxAuthService {
    public User getUser(LoginVo loginVo) ;

    User register(WxRegister wxRegister);

    User register(WxLoginRequest wx, WxRegister wxRegister);
}
