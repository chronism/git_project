package cn.neepi.project2.service;

import cn.neepi.project2.model.Issue;

import java.util.List;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
/**
 * @author niko
 * @version 1.0
 * @date 19/12/29/029 下午 06:50
 */
public interface IssueService {
    ListItem<List<Issue>> queryIssues(PageProperties properties, String issue);

   boolean createIssue(Issue issue);

    Issue updateIssue(Issue issue);

    boolean deleteIssue(Issue issue);
}
