package cn.neepi.project2.service.ShoppingMallManagerServiceImpl;

import cn.neepi.project2.mapper.RegionMapper;
import cn.neepi.project2.model.ShoppingMallModel.Region;
import cn.neepi.project2.service.ShoppingMallManagerService.RegionManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegionManagerServiceImpl implements RegionManagerService {
    @Autowired
    RegionMapper regionMapper;

    @Override
    public List<Region> getRegionList(int pid) {

        return regionMapper.getRegionList(pid);
    }
}
