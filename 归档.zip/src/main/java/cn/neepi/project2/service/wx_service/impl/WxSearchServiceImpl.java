package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.GoodsMapper;
import cn.neepi.project2.mapper.KeywordMapper;
import cn.neepi.project2.mapper.SearchHistoryMapper;
import cn.neepi.project2.model.*;
import cn.neepi.project2.service.wx_service.WxSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


@Service
public class WxSearchServiceImpl implements WxSearchService {

    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    SearchHistoryMapper searchHistoryMapper;
    @Autowired
    KeywordMapper keywordMapper;

    @Override
    public List<String> getHelper(String keyword) {

        return null;
    }

    @Override
    public List<Map<String, String>> searchKeywords(Integer id) {
        SearchHistoryExample historyExample = new SearchHistoryExample();
        historyExample.createCriteria().andUserIdEqualTo(id).andDeletedEqualTo(false);
        List<SearchHistory> searchHistories = searchHistoryMapper.selectByExample(historyExample);
        List<Map<String, String>> list = new ArrayList<>();
        if (searchHistories!=null){
            for (SearchHistory s :
                    searchHistories) {
                Map<String, String> map = new LinkedHashMap<>();
                map.put("keyword",s.getKeyword());
                list.add(map);
            }
        }
        return list;
    }

    @Override
    public List<Keyword> searchHotKeywords() {
        KeywordExample keywordExample = new KeywordExample();
        keywordExample.createCriteria().andDeletedEqualTo(false).andIsHotEqualTo(true).andIsDefaultEqualTo(true);
        keywordExample.setOrderByClause("sort_order desc");
        List<Keyword> list = keywordMapper.selectByExample(keywordExample);
        return list;
    }

    @Override
    public Keyword searchDefaultKeyword() {
        KeywordExample keywordExample = new KeywordExample();
        keywordExample.createCriteria().andDeletedEqualTo(false).andIsHotEqualTo(true).andIsDefaultEqualTo(true);
        keywordExample.setOrderByClause("add_time desc");
        List<Keyword> list = keywordMapper.selectByExample(keywordExample);
        if (list!=null){
            return list.get(0);
        }
        return null;
    }

    @Override
    public void clearKeyWords(Integer id) {

        searchHistoryMapper.deleteHistoryKey(id);
    }

    @Override
    public List<String> getHistory(String keyword) {
        SearchHistoryExample searchHistoryExample = new SearchHistoryExample();
        searchHistoryExample.createCriteria().andDeletedEqualTo(false).andKeywordLike("%"+keyword+"%");
        List<SearchHistory> searchHistories = searchHistoryMapper.selectByExample(searchHistoryExample);
        List<String> list = new ArrayList<>();
        if (searchHistories!=null){
            for (SearchHistory s :
                    searchHistories) {
                list.add(s.getKeyword());
            }
        }
        return list;
    }

}
