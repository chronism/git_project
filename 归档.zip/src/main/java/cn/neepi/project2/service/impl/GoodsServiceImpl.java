package cn.neepi.project2.service.impl;


import cn.neepi.project2.mapper.BrandMapper;
import cn.neepi.project2.mapper.CommentMapper;
import cn.neepi.project2.mapper.GoodsMapper;
import cn.neepi.project2.model.*;
import cn.neepi.project2.mapper.*;


import cn.neepi.project2.model.Comment;
import cn.neepi.project2.model.CommentExample;
import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.GoodsExample;
import cn.neepi.project2.model.ShoppingMallModel.*;
import cn.neepi.project2.model.requestModel.GoodsCreateCxs;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.GoodsService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    BrandMapper brandMapper;
    @Autowired
    GoodsAttributeMapper goodsAttributeMapper;

    @Autowired
    GoodsProductMapper goodsProductMapper;

    @Autowired
    GoodsSpecificationMapper goodsSpecificationMapper;

    @Autowired
    CommentMapper commentMapper;

    @Autowired
    CateGoryMapper cateGoryMapper;


    @Override
    public ListItem getGoodsList(PageProperties pageProperties, String goodsSn, String name) {
        GoodsExample goodsExample = new GoodsExample();
        goodsExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());

        GoodsExample.Criteria criteria = goodsExample.createCriteria();
        if (goodsSn != null && StringUtil.isNotEmpty(goodsSn)) {
            criteria.andGoodsSnLike("%" + goodsSn + "%");
        }
        if (name != null && StringUtil.isNotEmpty(name)) {
            criteria.andNameLike("%" + name + "%");
        }
        // 查找没被删除的数据
        criteria.andDeletedEqualTo(false);
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Goods> goodsList = goodsMapper.selectByExample(goodsExample);
        ListItem<List<Goods>> listItem = new ListItem<>();
        listItem.setItems(goodsList);
        listItem.setTotal(goodsMapper.countByExample(goodsExample));
        return listItem;
    }

    @Override
    public ListItem getCommentList(PageProperties pageProperties, Integer valueId, Integer userId) {
        CommentExample commentExample = new CommentExample();
        commentExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());

        CommentExample.Criteria criteria = commentExample.createCriteria();
        if (valueId != null && valueId != 0) {
            criteria.andValueIdEqualTo(valueId);
        }
        if (userId != null && userId != 0) {
            criteria.andValueIdEqualTo(userId);
        }
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Comment> comments = commentMapper.selectByExample(commentExample);
        ListItem<List<Comment>> listItem = new ListItem<>();
        listItem.setItems(comments);
        listItem.setTotal(commentMapper.countByExample(commentExample));
        return listItem;
    }

    /**
     * 删除商品
     *
     * @param goods
     * @return
     */
    @Override
    public Integer goodsDelete(Goods goods) {
        goods.setDeleted(true);
        int i = goodsMapper.updateByPrimaryKey(goods);
        return i;
    }

    /**
     * 商品编辑
     *
     * @param info
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer goodsUpdate(GoodsCreateCxs info) {
        Date date = new Date();
        Goods goods = info.getGoods();
        goods.setUpdateTime(date);
        goods.setAddTime(date);
        goodsMapper.updateByPrimaryKey(goods);
        GoodsAttribute[] attributes = info.getAttributes();
        GoodsAttributeExample attributeExample = new GoodsAttributeExample();
        attributeExample.createCriteria().andGoodsIdEqualTo(goods.getId());
        List<GoodsAttribute> goodsAttributes = goodsAttributeMapper.selectByExample(attributeExample);
        Set<Integer> deleteAttributeIds=new HashSet<>();

        for (int i = 0; i < attributes.length; i++) {
        for (GoodsAttribute g :
                goodsAttributes) {

                if (attributes[i].getId()!=null&&!g.getId().equals(attributes[i].getId())){
                    deleteAttributeIds.add(g.getId());
                    break;
                }
                if (attributes[i].getId()==null){
                    attributes[i].setGoodsId(goods.getId());
                    attributes[i].setAddTime(date);
                    attributes[i].setUpdateTime(date);
                    goodsAttributeMapper.insert(attributes[i]);
                    break;
                }
                if (g.getId().equals(attributes[i].getId())){
                    if (g.equals(attributes[i])){
                        break;
                    }else {
                        goodsAttributeMapper.updateByPrimaryKey(attributes[i]);
                        break;
                    }
                }
            }
        }
        for (Integer i :
                deleteAttributeIds) {
            goodsAttributeMapper.deleteById(i);
        }

        List<Integer> deleteSpec = new ArrayList<>();
        GoodsSpecification[] specifications = info.getSpecifications();
        for (int i = 0; i < specifications.length ; i++) {
            if (specifications[i].getId()==null){
                specifications[i].setDeleted(false);
                specifications[i].setAddTime(date);
                specifications[i].setGoodsId(goods.getId());
                specifications[i].setUpdateTime(date);
                goodsSpecificationMapper.insert(specifications[i]);
                continue;
            }else {
                deleteSpec.add(specifications[i].getId());
            }
        }

        goodsSpecificationMapper.deleteNotInIds(deleteSpec,goods.getId());

        GoodsProduct[] products = info.getProducts();
        GoodsProductExample productExample = new GoodsProductExample();
        productExample.createCriteria().andGoodsIdEqualTo(goods.getId());
        goodsProductMapper.deleteByExample(productExample);

        for (int i = 0; i < products.length; i++) {
            products[i].setId(null);
            products[i].setAddTime(date);
            products[i].setUpdateTime(date);
            products[i].setGoodsId(goods.getId());
            products[i].setDeleted(false);
            goodsProductMapper.insert(products[i]);
        }
        return 0;
    }

    /**
     * 删除评价
     *
     * @param comment
     * @return
     */
    @Override
    public Integer commentDelete(Comment comment) {
        comment.setDeleted(true);
        int i = commentMapper.updateByPrimaryKey(comment);
        return i;
    }

    @Override
    public HashMap queryCatAndBrand() {

        List<CateGoryL1> categoryList = cateGoryMapper.selectAllCategory();
        for (CateGoryL1 cateGoryL1 : categoryList) {
            Integer value = cateGoryL1.getValue();
            List<CateGoryChildren> children = cateGoryMapper.selectAllChildren(value);
            cateGoryL1.setChildren(children);
        }
            List<BrandL1> brandList = brandMapper.selectAllBrand();

        HashMap<String,Object> hashMap=new HashMap<>();
        hashMap.put("categoryList",categoryList);
        hashMap.put("brandList",brandList);
        return hashMap;
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer createGoods(GoodsCreateCxs info) {
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String addTime = simpleDateFormat.format(date);
        Goods goods = info.getGoods();
        goods.setShareUrl("");
        goodsMapper.insertByGoodsMap(goods, addTime);

        Integer goodsId = goods.getId();
        GoodsSpecification[] specifications = info.getSpecifications();
        for (GoodsSpecification specification : specifications) {

            goodsSpecificationMapper.insertBySpecificationMap(specification, addTime, goodsId);
        }

        GoodsProduct[] products = info.getProducts();
        for (GoodsProduct product : products) {
            goodsProductMapper.insertByProductMap(product, addTime, goodsId);
        }

        GoodsAttribute[] attributes = info.getAttributes();
        for (GoodsAttribute attribute : attributes) {
            goodsAttributeMapper.insertByAttributeMap(attribute, addTime, goodsId);
        }
        return 0;
    }
    /**
     * 显示商品详情
     * @param id
     * @return
     */
    @Override
    public HashMap getGoodsDetail(Integer id) {
        //查出来goods
        Goods goods = goodsMapper.selectByPrimaryKey(id);
        //查出来goodsAttributes
        GoodsAttributeExample goodsAttributeExample = new GoodsAttributeExample();
        GoodsAttributeExample.Criteria criteria = goodsAttributeExample.createCriteria();
        criteria.andGoodsIdEqualTo(id);
        criteria.andDeletedEqualTo(false);
        List<GoodsAttribute> goodsAttributes = goodsAttributeMapper.selectByExample(goodsAttributeExample);
        //查出来specifications
        GoodsSpecificationExample goodsSpecificationExample = new GoodsSpecificationExample();
        GoodsSpecificationExample.Criteria criteria2 = goodsSpecificationExample.createCriteria();
        criteria2.andGoodsIdEqualTo(id);
        criteria2.andDeletedEqualTo(false);
        List<GoodsSpecification> goodsSpecifications = goodsSpecificationMapper.selectByExample(goodsSpecificationExample);
        //查出来prodeucts
        GoodsProductExample goodsProductExample = new GoodsProductExample();
        GoodsProductExample.Criteria criteria1 = goodsProductExample.createCriteria();
        criteria1.andGoodsIdEqualTo(id);
        criteria1.andDeletedEqualTo(false);
        List<GoodsProduct> goodsProducts = goodsProductMapper.selectByExample(goodsProductExample);
        //查出categoryID
        CateGoryExample cateGoryExample = new CateGoryExample();
        CateGoryExample.Criteria criteria3 = cateGoryExample.createCriteria();
        criteria3.andIdEqualTo(goods.getCategoryId());
        criteria3.andDeletedEqualTo(false);
        List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExample);
        //拼装数据
        ArrayList<Integer> categoryIds = new ArrayList<>();
        if(cateGories != null && !cateGories.isEmpty()) {
            CateGory cateGory = cateGories.get(0);
            categoryIds.add(cateGory.getPid());
            categoryIds.add(cateGory.getId());

        }

        HashMap<Object, Object> map = new HashMap<>();
        map.put("categoryIds",categoryIds);
        map.put("goods",goods);
        map.put("attributes",goodsAttributes);
        map.put("specifications",goodsSpecifications);
        map.put("products",goodsProducts);
        return map;
    }
}
