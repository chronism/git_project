package cn.neepi.project2.service;

import cn.neepi.project2.model.responseModel.ExpressConfigCxs;
import cn.neepi.project2.model.responseModel.MallConfigCxs;
import cn.neepi.project2.model.responseModel.OrderConfigCxs;
import cn.neepi.project2.model.responseModel.WxConfigCxs;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/26/026 下午 09:24
 */
public interface SysConfigService {

    MallConfigCxs queryMall();

    int updateMall(MallConfigCxs mall);

    ExpressConfigCxs queryExpress();

    int updateExpress(ExpressConfigCxs express);

    OrderConfigCxs queryOrder();

    int updateOrder(OrderConfigCxs order);

    WxConfigCxs queryWx();

    int updateWx(WxConfigCxs wx);
}
