package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.Topic;

import java.util.List;
import java.util.Map;

public interface WxTopicService {

    List<Topic> getRelatedTopicList(Integer id);

    Map getTopicList(Integer page, Integer size);

    Topic getDetail(Integer id);
}
