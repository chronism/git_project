package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.AdminMapper;
import cn.neepi.project2.mapper.CskaoyanMallSystemPermissionsMapper;
import cn.neepi.project2.mapper.PermissionMapper;
import cn.neepi.project2.mapper.RoleMapper;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.AdminService;
import com.github.pagehelper.PageHelper;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * @author heyongbin  xcy
 * @date  2019/12/24  12/26
 * @version V1.0
 **/
@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    AdminMapper adminMapper;

    @Autowired
    PermissionMapper permissionMapper;

    @Autowired
    RoleMapper roleMapper;
    @Autowired
    CskaoyanMallSystemPermissionsMapper mallSystemPermissionsMapper;

    @Override
    public Admin login(LoginVo loginVo) {
        AdminExample adminExample = new AdminExample();
        adminExample.createCriteria().andUsernameEqualTo(loginVo.getUsername());
        List<Admin> admins = adminMapper.selectByExample(adminExample);
        if (admins.size()==1){
            Admin admin = admins.get(0);
            boolean checkpw = BCrypt.checkpw(loginVo.getPassword(), admin.getPassword());
            if (checkpw) {return admin;}
        }
        return null;
    }

    @Override
    public ListItem queryAdmin(PageProperties pageProperties, String username) {
        AdminExample adminExample = new AdminExample();
        AdminExample.Criteria criteria = adminExample.createCriteria();
        if (username != null) {
            criteria.andUsernameLike("%" + username + "%");
        }
        // 判断是否被删除 需要false
        criteria.andDeletedEqualTo(false);
        adminExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        // 分页插件
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        // 调用mapper
        List<Admin> admins = adminMapper.selectByExample(adminExample);
        ListItem<List<Admin>> listListItem = new ListItem<>();
        listListItem.setItems(admins);
        listListItem.setTotal(adminMapper.countByExample(adminExample));
        return listListItem;
    }

    @Override
    public Admin createAdmin(Admin admin) {
        // 判断同名 如果存在直接返回
        String username = admin.getUsername();
        AdminExample adminExample = new AdminExample();
        adminExample.createCriteria().andUsernameEqualTo(username);
        List<Admin> admins = adminMapper.selectByExample(adminExample);
        if (admins.size() != 0) {
            return admin;
        }
        /*LocalDateTime localDateTime = LocalDateTime.now();
        String formatTime = localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));*/
        // 更新时间
        Date date = new Date();
        admin.setAddTime(date);
        admin.setUpdateTime(date);
        // 密码加密
        String hashpw = BCrypt.hashpw(admin.getPassword(), BCrypt.gensalt());
        admin.setPassword(hashpw);
        // deleted
        admin.setDeleted(false);
        // roleIds直接传 typehandle做了转型
        // String roleIdsStr = admin.getRoleIds().toString();
        int insert = adminMapper.insert(admin);
        if (insert == 1) {
            return admin;
        } else {
            return null;
        }
    }

    @Override
    public Admin updateAdmin(Admin admin) {
        // 判断同名 不加自己 如果存在直接返回
        String username = admin.getUsername();
        AdminExample adminExample = new AdminExample();
        AdminExample.Criteria criteria = adminExample.createCriteria();
        criteria.andUsernameEqualTo(username);
        criteria.andIdNotEqualTo(admin.getId());
        List<Admin> admins = adminMapper.selectByExample(adminExample);
        if (admins.size() != 0) {
            admin.setId(0);
            return admin;
        }
        // 密码加密
        String hashpw = BCrypt.hashpw(admin.getPassword(), BCrypt.gensalt());
        admin.setPassword(hashpw);
        // 更新时间
        Date date = new Date();
        admin.setUpdateTime(date);
        int i = adminMapper.updateByPrimaryKey(admin);
        if (i == 1) {
            return admin;
        }
        return null;
    }

    @Override
    public Integer deleteAdmin(Admin admin) {
        admin.setUpdateTime(new Date());
        admin.setDeleted(true);
        int i = adminMapper.updateByPrimaryKey(admin);
        if (i == 1) {
            return i;
        }
        return 500;
    }

    @Override
    public List<String> getPermissions(Admin admin) {
        PermissionExample permissionExample = new PermissionExample();
        PermissionExample.Criteria criteria = permissionExample.createCriteria();
        criteria.andRoleIdIn(Arrays.asList(admin.getRoleIds()));
        criteria.andDeletedEqualTo(false);
        List<String> permissions = permissionMapper.selectPermissionByExample(permissionExample);
        if (permissions.contains("*")){
            return permissions;
        }
        List<String> permissionsApi = mallSystemPermissionsMapper.selectUserPermison(permissions);

        return permissionsApi;
    }

    @Override
    public List<String> getRoles(Admin admin) {
        RoleExample roleExample = new RoleExample();
        RoleExample.Criteria criteria = roleExample.createCriteria();
        criteria.andIdIn(Arrays.asList(admin.getRoleIds()));
        criteria.andDeletedEqualTo(false);
        List<String> roles = roleMapper.selectRolesByExample(roleExample);
        return roles;
    }

    @Override
    public void changePassword(String newPassword, Admin admin) {
        admin.setPassword(BCrypt.hashpw(newPassword,BCrypt.gensalt()));
        Date date = new Date();
        admin.setUpdateTime(date);
        adminMapper.updateByPrimaryKey(admin);
    }
}
