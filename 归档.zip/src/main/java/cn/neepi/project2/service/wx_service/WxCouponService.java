package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.responseModel.WxListItem;

import java.util.List;


public interface WxCouponService {
    /**
     * 获取当前用户所拥有的所有优惠券
     *
     * @param userId
     * @param page
     * @param size
     * @return
     */
    WxListItem queryMyCouponList(int userId, Integer status, Integer page, Integer size);

    /**
     * 查看所有能领取的优惠券
     *
     * @param page
     * @param size
     * @return
     */
    WxListItem queryCouponList(Integer page, Integer size);

    /**
     * 领取优惠券
     *
     * @param couponId
     * @param userId
     * @return
     */
    int receiveCoupon(Integer couponId, Integer userId);

    /**
     * 兑换优惠券
     *
     * @param code
     * @param userId
     * @return
     */
    int exchangeCoupon(String code, int userId);

    List selectCoupon(Integer cartId, Integer grouponRules);
}
