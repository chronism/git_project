package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.*;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.ShoppingMallModel.*;
import cn.neepi.project2.model.wx_responseModel.*;
import cn.neepi.project2.service.wx_service.WxIndexService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/29
 **/
@Service
public class WxIndexServiceImpl implements WxIndexService {
    @Autowired
    AdMapper adMapper;
    @Autowired
    BrandMapper brandMapper;
    @Autowired
    CateGoryMapper cateGoryMapper;
    @Autowired
    CouponMapper couponMapper;
    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    CateGoryMapper getCateGoryMapper;
    @Autowired
    OrderMapper orderMapper;

    @Autowired
    GrouponMapper grouponMapper;
    @Autowired
    GrouponRulesMapper grouponRulesMapper;

    @Autowired
    TopicMapper topicMapper;

    @Override
    public HomeResp getHome() {
        HomeResp homeResp = new HomeResp();
        AdExample adExample = new AdExample();
        adExample.createCriteria().andDeletedEqualTo(false).andEnabledEqualTo(true);
        adExample.setOrderByClause("add_time desc");
        List<Ad> ads = adMapper.selectByExample(adExample);
        homeResp.setBanner(ads);

        BrandExample brandExample = new BrandExample();
        brandExample.createCriteria().andDeletedEqualTo(false);
        brandExample.setOrderByClause("add_time desc limit 10");
        List<Brand> brands = brandMapper.selectByExample(brandExample);
        homeResp.setBrandList(brands);

        CateGoryExample cateGoryExample = new CateGoryExample();
        cateGoryExample.createCriteria().andDeletedEqualTo(false).andPidEqualTo(0);
        List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExample);
        homeResp.setChannel(cateGories);

        List<FloorGoodsList>  floorGoodsLists = new ArrayList<>();
        if (cateGories!=null){
        for (CateGory gory :
                cateGories) {
            FloorGoodsList floorGoodsList = new FloorGoodsList();
            CateGoryExample subExample = new CateGoryExample();
            subExample.createCriteria().andDeletedEqualTo(false).andPidEqualTo(gory.getId());
            List<CateGory> subGory = cateGoryMapper.selectByExample(subExample);
            for (CateGory c : subGory) {
                GoodsExample goodsExample = new GoodsExample();
                goodsExample.createCriteria().andCategoryIdEqualTo(c.getId());
                List<Goods> goodsList = goodsMapper.selectByExample(goodsExample);
                floorGoodsList.setGoodsList(goodsList);
                if (floorGoodsList.getGoodsList().size()>0){
                    break;
                }
            }

            floorGoodsList.setId(gory.getId());
            floorGoodsList.setName(gory.getName());
            floorGoodsLists.add(floorGoodsList);
           if ( floorGoodsLists.size()==5) {
               break;
           }
        }
        }
        homeResp.setFloorGoodsList(floorGoodsLists);

        List<GrouponList> grouponLists = new ArrayList<>();
        GrouponExample grouponExampl = new GrouponExample();
        grouponExampl.setOrderByClause("add_time desc limit 5");
        grouponExampl.createCriteria().andDeletedEqualTo(false);
        List<Groupon> groupons = grouponMapper.selectByExample(grouponExampl);

        if (groupons!=null) {
            List<Integer> groupRulesId = new ArrayList<>();
            for (Groupon groupon :
                    groupons) {
                groupRulesId.add(groupon.getRulesId());
            }
            GrouponRulesExample grouponRulesExample = new GrouponRulesExample();
            grouponExampl.createCriteria().andCreatorUserIdIn(groupRulesId).andDeletedEqualTo(false);
            List<GrouponRules> grouponRules = grouponRulesMapper.selectByExample(grouponRulesExample);
            List<Goods> goodsList = goodsMapper.selectByGrouponRules(groupRulesId);
            if (goodsList!=null){
                for (Goods g :
                        goodsList) {
                    for (GrouponRules gRules:
                            grouponRules) {
                        if (g.getId().equals(gRules.getGoodsId())){
                        GrouponList grouponList = new GrouponList();
                        grouponList.setGoods(g);
                        grouponList.setGroupon_member(gRules.getDiscountMember());
                        grouponList.setGroupon_price(new Double(g.getCounterPrice().subtract(gRules.getDiscount()).doubleValue()));
                        grouponLists.add(grouponList);
                        break;
                        }
                    }

                }
            }
        }
        homeResp.setGrouponList(grouponLists);

        TopicExample topicExample = new TopicExample();
        List<Topic> topics = topicMapper.selectByExample(topicExample);
        homeResp.setTopicList(topics);


        CouponExample couponExample = new CouponExample();
        couponExample.createCriteria().andDeletedEqualTo(false).andStatusEqualTo(0);
        couponExample.setOrderByClause("add_time desc limit 5");
        List<Coupon> coupons = couponMapper.selectByExample(couponExample);
        homeResp.setCouponList(coupons);

        GoodsExample goodsExample = new GoodsExample();
        goodsExample.createCriteria().andDeletedEqualTo(false);
        goodsExample.createCriteria().andIsHotEqualTo(true);
        goodsExample.setOrderByClause("add_time desc limit 10");
        List<Goods> goodsHot = goodsMapper.selectByExample(goodsExample);
        homeResp.setHotGoodsList(goodsHot);

        GoodsExample goodsExampleNew = new GoodsExample();
        goodsExampleNew.createCriteria().andDeletedEqualTo(false);
        goodsExampleNew.createCriteria().andIsNewEqualTo(true);
        goodsExampleNew.setOrderByClause("add_time desc limit 10");
        List<Goods> goodsNew = goodsMapper.selectByExample(goodsExample);
        homeResp.setNewGoodsList(goodsNew);

        return homeResp;
    }

    @Override
    public Long getGoodsCount() {
        GoodsExample goodsExample = new GoodsExample();
        goodsExample.createCriteria().andDeletedEqualTo(false);
        long l = goodsMapper.countByExample(goodsExample);
        return l;
    }

    @Override
    public HomeCategroyList getCatalog() {
        CateGoryExample cateGoryExample = new CateGoryExample();
        cateGoryExample.setOrderByClause("id limit 17");
        List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExample);
        HomeCategroyList homeCategroyList=new HomeCategroyList();
        homeCategroyList.setCategoryList(cateGories.subList(0,7));
        homeCategroyList.setCurrentCategory(cateGories.get(0));
        homeCategroyList.setCurrentSubCategory(cateGories.subList(8,16));
        return homeCategroyList;
    }

    @Override
    public HomeCategroyList getCurrentCatalog(Integer id) {
        CateGoryExample cateGoryExample = new CateGoryExample();
        CateGory cateGory = cateGoryMapper.selectByPrimaryKey(id);
        HomeCategroyList homeCategroyList = new HomeCategroyList();
        homeCategroyList.setCurrentCategory(cateGory);

        cateGoryExample.createCriteria().andPidEqualTo(id);
        List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExample);
        homeCategroyList.setCurrentSubCategory(cateGories);
        return homeCategroyList;
    }

    @Override
    public UserIndex getUserIndex() {
        OrderExample orderExample = new OrderExample();
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        orderExample.createCriteria().andUserIdEqualTo(user.getId());
        List<Order> orders = orderMapper.selectByExample(orderExample);
        Integer uncomment = 0;
        Integer unpaid = 0;
        Integer unrecv = 0;
        Integer unship = 0;

        if (orders!=null){
        for (Order o :
                orders) {
            switch (o.getOrderStatus()){
                case 101:
                    unpaid++;
                    break;
                case 201:
                case 202:
                    unship++;
                    break;
                case 301:
                    unrecv++;
                    break;
                case 401:
                case 402:
                case 203:
                    uncomment++;
                    break;
            }
        }
        }

        UserIndex userIndex = new UserIndex();
        userIndex.setUnrecv(unrecv);
        userIndex.setUncomment(uncomment);
        userIndex.setUnpaid(unpaid);
        userIndex.setUnship(unship);



        return userIndex;
    }
}
