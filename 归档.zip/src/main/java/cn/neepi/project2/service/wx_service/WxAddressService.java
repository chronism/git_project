package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.Address;
import cn.neepi.project2.model.Address_liuyu;

import java.util.List;

public interface WxAddressService {
    /**
     * 显示用户地址管理列表
     * @return
     * @param id
     */
    List<Address_liuyu> selectAllAdressByUserId(Integer id);

    /**
     * 查询地址详情
     * @param id
     * @return
     */
    Address selectAddressById(Integer id);

    /**
     * 更新地址详情
     * @param address
     * @return
     */
    Integer updateAddress(Address address);

    /**
     * 删除地址
     * @param id,userId
     * @return
     */
    Integer deleteAddress(Integer id, Integer userId);
}
