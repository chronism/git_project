package cn.neepi.project2.service.ShoppingMallManagerService;

import cn.neepi.project2.model.ShoppingMallModel.Region;

import java.util.List;

public interface RegionManagerService {
    /**
     * 根据pid，三级联动查询区域
     * @param pid
     * @return 获取区域列表
     */
    List<Region> getRegionList(int pid);
}
