package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.StorageMapper;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.Storage;
import cn.neepi.project2.model.StorageExample;
import cn.neepi.project2.service.ImageStorageService;
import cn.neepi.project2.util.OosUploadImageUtils;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/27
 **/
@Service
public class ImageStorageServiceImpl implements ImageStorageService {
    @Autowired
    StorageMapper storageMapper;

    @Override
    public Storage imageUpload(MultipartFile multipartFile, Storage storage) {
        Storage image = OosUploadImageUtils.picOSS(multipartFile, storage);
        image.setDeleted(false);
        int insert = storageMapper.insert(image);
        if (insert==1){
            return image;
        }
        return null;
    }

    @Override
    public ListItem queryStorage(PageProperties pageProperties, String key, String name) {
        StorageExample storageExample = new StorageExample();
        StorageExample.Criteria criteria = storageExample.createCriteria();
        if (key != null) {
            criteria.andKeyLike("%" + key + "%");
        }
        if (name != null) {
            criteria.andNameLike("%" + name + "%");
        }
        // deleted
        criteria.andDeletedEqualTo(false);
        // 排序 分页
        storageExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        // 调用mapper
        List<Storage> storages = storageMapper.selectByExample(storageExample);
        ListItem<List<Storage>> storageListItem = new ListItem<>();
        storageListItem.setItems(storages);
        storageListItem.setTotal(storageMapper.countByExample(storageExample));
        return storageListItem;
    }

    @Override
    public Storage updateStorage(Storage storage) {
        // 更新时间
        storage.setUpdateTime(new Date());
        int i = storageMapper.updateByPrimaryKey(storage);
        if (i == 1) {
            return storage;
        }
        return null;
    }

    @Override
    public Storage deleteStorage(Storage storage) {
        storage.setUpdateTime(new Date());
        storage.setDeleted(true);
        int i = storageMapper.updateByPrimaryKey(storage);
        if (i == 1) {
            return storage;
        }
        return null;
    }
}
