package cn.neepi.project2.service;

import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.Storage;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/27
 **/
public interface ImageStorageService {
    /**
     * 上传图片逻辑
     * @param multipartFile
     * @param storage
     * @return
     */
    Storage imageUpload(MultipartFile multipartFile, Storage storage);

    /**
     * 查找storage
     * @param pageProperties
     * @param key
     * @param name
     * @return
     */
    ListItem queryStorage(PageProperties pageProperties, String key, String name);

    /**
     * 更新图片名
     * @param storage
     * @return
     */
    Storage updateStorage(Storage storage);

    /**
     * 删除图片
     * @param storage
     * @return
     */
    Storage deleteStorage(Storage storage);
}
