package cn.neepi.project2.service.ShoppingMallManagerService;

import cn.neepi.project2.model.ShoppingMallModel.Order;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.responseModel.OrderDetailLxt;
import io.swagger.models.auth.In;

import java.util.List;
import java.util.Map;

public interface OrderManagerService {
    /**
     * 根据查询条件 获取订单列表
     * @param pageProperties
     * @param userId
     * @param orderSn
     * @param orderStatusArray
     * @return
     */
    ListItem<List<Order>> getOrderList(PageProperties pageProperties ,Integer userId , String orderSn , Short[] orderStatusArray);

    /**
     * 根据订单id 获取订单详情
     * @param id
     * @return
     */
    OrderDetailLxt getOrderDetail(Integer id);

    String shipOrder(Map map);
    String refundOrder(Map map);

}
