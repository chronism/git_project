package cn.neepi.project2.service;

import java.util.Map;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/28/028 下午 03:26
 */

public interface StatService {
    Map<String, Object> orderGoodStat();

    Map<String, Object> orderStat();

    Map<String, Object> userStat();


}
