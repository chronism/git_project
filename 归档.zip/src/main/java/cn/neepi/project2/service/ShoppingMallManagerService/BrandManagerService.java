package cn.neepi.project2.service.ShoppingMallManagerService;

import cn.neepi.project2.exception.shoppingMallException.ManufacturerRepeatedException;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.ShoppingMallModel.Brand;


import java.util.List;

public interface BrandManagerService {

    /**
     * 根据品牌商 id和name 获取品牌商列表
     * @param pageProperties
     * @param name
     * @param id
     * @return 获取品牌商列表
     */
    ListItem<List<Brand>> getBrandList(PageProperties pageProperties, String name, Integer id);


    /**
     * 添加品牌制造商
     * @param brand
     * @return 新品牌
     */
    Brand addBrand(Brand brand) throws ManufacturerRepeatedException;

    /**
     * 更新品牌信息
     * @param brand
     * @return 更新品牌
     * @throws ManufacturerRepeatedException
     */
    Brand updateBrand(Brand brand) throws ManufacturerRepeatedException;

    /**
     * 删除品牌信息
     * @param brand
     */
    Boolean deleteBrand(Brand brand);
}
