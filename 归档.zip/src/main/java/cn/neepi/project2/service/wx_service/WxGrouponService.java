package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.responseModel.WxListItem;
import cn.neepi.project2.model.wx_responseModel.GrouponDetail;

public interface WxGrouponService {
    WxListItem getGroupList(Integer page, Integer size);

    WxListItem getMyGrouponList(Integer userId, Integer showType);

    GrouponDetail getGrouponDetail(Integer grouponId);
}
