package cn.neepi.project2.service;

import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.Role;

import java.util.List;
import java.util.Map;

public interface RoleService {

    /**
     * 获取所有role选项
     * @return
     */
    List queryRole();

    /**
     * 获取对应role信息
     * @param pageProperties 分页信息
     * @param name 模糊查找角色名
     * @return
     */
    ListItem queryRoleList(PageProperties pageProperties, String name);

    /**
     * 创建role
     * @param role
     * @return
     */
    Role createRole(Role role);

    /**
     * 更新role
     * @param role
     * @return
     */
    Role updateRole(Role role);


    /**
     * 删除role
     * @param role
     * @return
     */
    Role deleteRole(Role role);

    /**
     * 获取所有permission
     * @param roleId
     * @return
     */
    Map getPermissions(Integer roleId);

    /**
     * 设置role对应权限
     * @param roleId
     * @return
     */
    Integer setPermission(Integer roleId, List<String> permissions);
}
