package cn.neepi.project2.service.wx_service.impl;
import java.util.Date;
import cn.neepi.project2.mapper.*;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.wx_responseModel.*;
import com.github.pagehelper.PageHelper;

import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import cn.neepi.project2.model.ShoppingMallModel.CateGoryExample;
import cn.neepi.project2.service.wx_service.WxGoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@Service
public class WxGoodsServiceImpl implements WxGoodsService {

    @Autowired
    CateGoryMapper cateGoryMapper;
    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    GoodsAttributeMapper goodsAttributeMapper;
    @Autowired
    GoodsSpecificationMapper goodsSpecificationMapper;
    @Autowired
    IssueMapper issueMapper;
    @Autowired
    GrouponMapper grouponMapper;
    @Autowired
    GoodsProductMapper productMapper;
    @Autowired
    CommentMapper commentMapper;
    @Autowired
    CollectMapper collectMapper;
    @Autowired
    BrandMapper brandMapper;
    @Autowired
    GrouponRulesMapper grouponRulesMapper;
    @Autowired
    SearchHistoryMapper searchHistoryMapper;

    @Override
    public GoodsCategroyList getGoodsCategoryList(Integer id) {
        CateGory parentCateGory = cateGoryMapper.selectByPrimaryKey(id);

        CateGoryExample cateGoryExample = new CateGoryExample();
        CateGoryExample.Criteria criteria = cateGoryExample.createCriteria();
        if (parentCateGory.getPid()==0){
        criteria.andPidEqualTo(parentCateGory.getId());
        }else {
            criteria.andPidEqualTo(parentCateGory.getPid());

        }
        cateGoryExample.setOrderByClause("add_time desc");
        List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExample);

        GoodsCategroyList categroyList = new GoodsCategroyList();
        categroyList.setBrotherCategory(cateGories);
        if (parentCateGory.getPid()==0){
        categroyList.setCurrentCategory(cateGories.get(0));
        categroyList.setParentCategory(parentCateGory);
        }else {
            categroyList.setCurrentCategory(parentCateGory);
            CateGory cateGory = cateGoryMapper.selectByPrimaryKey(parentCateGory.getPid());
            categroyList.setParentCategory(cateGory);
        }


        return categroyList;
    }

    @Override
    public GoodsCategroyGoodList getCategoryGoods(Integer categoryId,Integer page,Integer size,Class type) {
        List<Goods> goods = new ArrayList<>();
        List<CateGory> cateGories = new ArrayList<>();
        long count = 0L;
        try {
            if (type.newInstance() instanceof CateGory){
            GoodsExample goodsExample = new GoodsExample();
            goodsExample.createCriteria().andDeletedEqualTo(false).andCategoryIdEqualTo(categoryId);
            goodsExample.setOrderByClause("add_time desc");
            PageHelper.startPage(page,size);
            goods = goodsMapper.selectByExample(goodsExample);
            count = goodsMapper.countByExample(goodsExample);
            }
            if(type.newInstance() instanceof Brand ){
                GoodsExample goodsExample = new GoodsExample();
                goodsExample.createCriteria().andDeletedEqualTo(false).andBrandIdEqualTo(categoryId);
                goodsExample.setOrderByClause("add_time desc");
                PageHelper.startPage(page,size);
                goods = goodsMapper.selectByExample(goodsExample);
                count = goodsMapper.countByExample(goodsExample);

            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        List<Integer> CategoryList= new ArrayList<>();
        if (!goods.isEmpty()){
        for (Goods good:goods){
            if(!CategoryList.contains(good.getCategoryId())) {
                CategoryList.add(good.getCategoryId());
            }
        }
            CateGoryExample cateGoryExample = new CateGoryExample();
            cateGoryExample.createCriteria().andIdIn(CategoryList);
            cateGories = cateGoryMapper.selectByExample(cateGoryExample);
        }

        GoodsCategroyGoodList goodsCategroyGoodList = new GoodsCategroyGoodList();
        goodsCategroyGoodList.setGoodsList(goods);
        goodsCategroyGoodList.setCount(count);
        goodsCategroyGoodList.setFilterCategoryList(cateGories);
        return goodsCategroyGoodList;

    }

    @Override
    public GoodsDetail getGoodsDetail(Integer id) {
        GoodsDetail goodsDetail = new GoodsDetail();

        Goods goods = goodsMapper.selectByPrimaryKey(id);
        goodsDetail.setInfo(goods);
        Brand brand = brandMapper.selectByPrimaryKey(goods.getBrandId());
        goodsDetail.setBrand(brand);

        CollectExample collectExample = new CollectExample();
        collectExample.createCriteria().andDeletedEqualTo(false).andValueIdEqualTo(id);
        long count = collectMapper.countByExample(collectExample);
        goodsDetail.setUserHasCollect(count);

        goodsDetail.setShareImage(goods.getShareUrl());

        GoodsProductExample goodsProductExample = new GoodsProductExample();
        goodsProductExample.createCriteria().andDeletedEqualTo(false).andGoodsIdEqualTo(id);
        List<GoodsProduct> goodsProducts = productMapper.selectByExample(goodsProductExample);
        goodsDetail.setProductList(goodsProducts);

        IssueExample issueExample = new IssueExample();
        issueExample.createCriteria().andDeletedEqualTo(false);
        List<Issue> issues = issueMapper.selectByExample(issueExample);
        goodsDetail.setIssue(issues);

        GrouponExample grouponExample = new GrouponExample();
        grouponExample.createCriteria().andDeletedEqualTo(false);
        List<Groupon> groupons = grouponMapper.selectByExample(grouponExample);
        List<Integer> groupRulesId= new ArrayList<>();

        for (Groupon g:groupons){
            groupRulesId.add(g.getRulesId());
        }
        GrouponRulesExample grouponRulesExample = new GrouponRulesExample();
        grouponRulesExample.createCriteria().andDeletedEqualTo(false).andGoodsIdEqualTo(goods.getId());
        List<GrouponRules> grouponRules = grouponRulesMapper.selectByExample(grouponRulesExample);

        for (Iterator<GrouponRules> iterator = grouponRules.iterator(); iterator.hasNext() ; ) {
            GrouponRules next = iterator.next();
            if (!groupRulesId.contains(next.getId())){
                iterator.remove();
            }
        }

        goodsDetail.setGroupon(grouponRules);

        CommentExample commentExample = new CommentExample();
        commentExample.createCriteria().andDeletedEqualTo(false).andValueIdEqualTo(id);
        List<Comment> comments = commentMapper.selectByExample(commentExample);
        long count1 = commentMapper.countByExample(commentExample);
        CommentToatl commentToatl = new CommentToatl();
        commentToatl.setCount(count1);
        commentToatl.setData(comments);
        goodsDetail.setComment(commentToatl);

        GoodsSpecificationExample specificationExample = new GoodsSpecificationExample();
        specificationExample.createCriteria().andDeletedEqualTo(false).andGoodsIdEqualTo(id);
        List<GoodsSpecification> goodsSpecifications = goodsSpecificationMapper.selectByExample(specificationExample);

        Set set = new HashSet<>();
        List<GoodsSpecificationList> goodsSpecificationLists = new ArrayList<>();
        for (GoodsSpecification spec:goodsSpecifications) {
            boolean add = set.add(spec.getSpecification());
            if (!add){
                continue;
            }
            GoodsSpecificationList specificationList =  new GoodsSpecificationList();
            specificationList.setName(spec.getSpecification());

            GoodsSpecificationExample specExample= new GoodsSpecificationExample();
            specExample.createCriteria().andDeletedEqualTo(false).andSpecificationEqualTo(spec.getSpecification()).andGoodsIdEqualTo(id);
            List<GoodsSpecification> goodsSpecifications1 = goodsSpecificationMapper.selectByExample(specExample);
            specificationList.setValueList(goodsSpecifications1);
            goodsSpecificationLists.add(specificationList);
        }
        goodsDetail.setSpecificationList(goodsSpecificationLists);

        GoodsAttributeExample goodsAttributeExample= new GoodsAttributeExample();
        goodsAttributeExample.createCriteria().andDeletedEqualTo(false).andGoodsIdEqualTo(id);
        List<GoodsAttribute> goodsAttributes = goodsAttributeMapper.selectByExample(goodsAttributeExample);

        goodsDetail.setAttribute(goodsAttributes);

        return goodsDetail;
    }

    @Override
    public List<Goods> getRelatedGoodsList(Integer id) {
        Goods goods = goodsMapper.selectByPrimaryKey(id);

        GoodsExample goodsExample = new GoodsExample();
        goodsExample.createCriteria().andDeletedEqualTo(false).andCategoryIdEqualTo(goods.getCategoryId());
        List<Goods> goodsList = goodsMapper.selectByExample(goodsExample);

        return goodsList;
    }

    @Override
    public GoodsCategroyGoodList getGoodsList(PageProperties pageProperties, String keyword) {
        GoodsExample goodsExample = new GoodsExample();
        goodsExample.createCriteria().andDeletedEqualTo(false).andKeywordsLike("%"+keyword+"%");
        goodsExample.setOrderByClause(pageProperties.getSort()+" "+pageProperties.getOrder());
        PageHelper.startPage(pageProperties.getPage(),pageProperties.getSize());
        List<Goods> goodsList = goodsMapper.selectByExample(goodsExample);
        List<CateGory> cateGoryList = new ArrayList<>();
        if (goodsList!=null){
            for (Goods g :
                    goodsList) {
                cateGoryList.add(cateGoryMapper.selectByPrimaryKey(g.getCategoryId()));
            }
        }
        GoodsCategroyGoodList goodsCategroyGoodList = new GoodsCategroyGoodList();
        goodsCategroyGoodList.setCount(goodsMapper.countByExample(goodsExample));
        goodsCategroyGoodList.setFilterCategoryList(cateGoryList);
        goodsCategroyGoodList.setGoodsList(goodsList);

        return goodsCategroyGoodList;
    }

    @Override
    public void addSearchHistory(String keyword, Integer id) {
        SearchHistoryExample historyExample = new SearchHistoryExample();
        historyExample.createCriteria().andKeywordEqualTo(keyword);
        List<SearchHistory> searchHistories = searchHistoryMapper.selectByExample(historyExample);
        if (searchHistories!=null&&searchHistories.size()>0){
            return;
        }
        SearchHistory searchHistory = new SearchHistory();

        searchHistory.setUserId(id);
        searchHistory.setKeyword(keyword);
        Date addTime = new Date();
        searchHistory.setFrom("wx");
        searchHistory.setAddTime(addTime);
        searchHistory.setUpdateTime(addTime);
        searchHistory.setDeleted(false);
        searchHistoryMapper.insert(searchHistory);

    }
}
