package cn.neepi.project2.service;

import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019-12-24
 **/
public interface UserService {
    /**
     * 获取用户list 可根据条件查询
     *
     * @param pageProperties 分页属性
     * @param username       根据用户名模糊查询
     * @param mobile         格局手机模糊查询
     * @return ListItem 返回对应数据
     */
    ListItem getUserList(PageProperties pageProperties, String username, String mobile);

    /**
     * 获取用户收货地址
     *
     * @param pageProperties 分页属性
     * @param userId         通过用户id查询
     * @param name           通过用户姓名查询
     * @return 用户地址列表
     */
    ListItem<List<Address>> getAddressList(PageProperties pageProperties, Integer userId, String name);

    /**
     * 获取会员收藏商品列表
     *
     * @param pageProperties 分页属性
     * @param userId         通过用户id查询
     * @param valueId        通过商品id查询
     * @return 用户收藏列表
     */
    ListItem<List<Collect>> getCollectList(PageProperties pageProperties, Integer userId, Integer valueId);

    /**
     * 获取用户足迹
     *
     * @param pageProperties 分页属性
     * @param userId         通过用户id查询
     * @param goodsId        通过商品id查询
     * @return 历史足迹表单
     */
    ListItem<List<Footprint>> getFootprintList(PageProperties pageProperties, Integer userId, Integer goodsId);

    /**
     * 获取用户搜索记录
     *
     * @param pageProperties 分页属性
     * @param userId         根据用户id搜索
     * @param keyword        根据关键字搜索
     * @return 返回搜索历史列表
     */
    ListItem<List<SearchHistory>> getHistoryList(PageProperties pageProperties, Integer userId, String keyword);

    /**
     * 获取用户投诉列表
     *
     * @param pageProperties 分页属性
     * @param username       根据用户名查找
     * @param id             根据id查找
     * @return 获取的用户投诉列表
     */
    ListItem<List<Feedback>> getFeedbackList(PageProperties pageProperties, String username, Integer id);
}
