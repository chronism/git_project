package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.Keyword;

import java.util.List;
import java.util.Map;

public interface WxSearchService {

    List<String> getHelper(String keyword);

    List<Map<String, String>> searchKeywords(Integer id);

    List<Keyword> searchHotKeywords();

    Keyword searchDefaultKeyword();

    void clearKeyWords(Integer id);

    List<String> getHistory(String keyword);
}
