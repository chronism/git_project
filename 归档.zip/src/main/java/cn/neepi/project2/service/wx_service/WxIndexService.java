package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.wx_responseModel.HomeCategroyList;
import cn.neepi.project2.model.wx_responseModel.HomeResp;
import cn.neepi.project2.model.wx_responseModel.UserIndex;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/29
 **/
public interface WxIndexService {
    HomeResp getHome();

    Long getGoodsCount();

    HomeCategroyList getCatalog();

    HomeCategroyList getCurrentCatalog(Integer id);

    UserIndex getUserIndex();
}
