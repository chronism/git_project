package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.Comment;

import java.util.HashMap;


public interface WxCommentService {

   Comment postComment(Comment comment);

   HashMap showCommentList(Integer valueId, Integer page, Integer size, Byte showType, Byte type);

   HashMap getCommentCount(Integer valueId, Byte type);
}
