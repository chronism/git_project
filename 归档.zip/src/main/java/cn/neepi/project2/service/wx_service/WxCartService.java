package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.mapper.CartMapper;
import cn.neepi.project2.model.Cart;
import cn.neepi.project2.model.wx_requestModel.WxCartCheckOut;
import cn.neepi.project2.model.wx_responseModel.CartConfirmation;
import cn.neepi.project2.model.wx_responseModel.CartIndex;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

public interface WxCartService {

    /**
     * 获取购物车列表
     * @return 购物车信息
     */
    CartIndex getCartIndex();

    /**
     * 添加商品到购物车
     * @param cart
     * @return 购物车中deleted为false的商品数目
     */
    Integer addCart(Cart cart);

    /**
     * 选择或取消选择商品
     * @param map
     * @return
     */
    CartIndex checkedCart(Map map);

    /**
     * 获取购物车商品数目
     * @return 购物车商品数量
     */
    Integer getCartGoodsCount();

    /**
     * 更新购物车
     * @param cart
     * @return
     */
    Integer updateCart(Cart cart);

    /**
     * 删除购物车
     * @param map
     * @return 返回购物车列表信息
     */
    CartIndex deleteCart(Map map);

    /**
     * 下单前确认信息
     * @param wxCartCheckOut
     * @return 下单前确认信息
     */
    CartConfirmation checkoutCart(WxCartCheckOut wxCartCheckOut);

    /**
     * 获取新的订单号
     * @param map
     * @return 新的订单号
     */
    Integer fastAddCart(Map map);
}
