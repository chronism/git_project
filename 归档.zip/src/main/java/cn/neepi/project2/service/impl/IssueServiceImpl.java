package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.IssueMapper;
import cn.neepi.project2.model.Issue;
import cn.neepi.project2.model.IssueExample;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.IssueService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Date;
import java.util.List;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/29/029 下午 07:10
 */

@Service
public class IssueServiceImpl implements IssueService {
    @Autowired
    IssueMapper issueMapper;

    @Override
    public ListItem<List<Issue>> queryIssues(PageProperties pageProperties, String issue) {
        ListItem<List<Issue>> listListItem = new ListItem<>();
        IssueExample issueExample = new IssueExample();
        IssueExample.Criteria criteria = issueExample.createCriteria();
        if (issue != null) {
            criteria.andQuestionLike("%" + issue + "%");
        }
        // 判断是否删除 需要false-假删除
        criteria.andDeletedEqualTo(false);
        issueExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        //分页插件
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Issue> issues = issueMapper.selectByExample(issueExample);

        PageInfo<Issue> issuePageInfo = new PageInfo<>(issues);
        long total = issuePageInfo.getTotal();
        listListItem.setItems(issues);
        listListItem.setTotal(total);
        return listListItem;
    }

    @Override
        public boolean createIssue(Issue issue) {
            if (issueMapper.insertIssue(issue) == 1) {
                return true;
            } else
                return false;
    }

    @Override
    public Issue updateIssue(Issue issue) {
        Date date = new Date();
        issue.setUpdateTime(date);
        IssueExample issueExample = new IssueExample();
        IssueExample.Criteria criteria = issueExample.createCriteria();
        criteria.andIdEqualTo(issue.getId());
        Integer i = issueMapper.updateByExampleSelective(issue, issueExample);
        if (i == 1) {
            return issue;
        }
        return null;
    }

    @Override
    public boolean deleteIssue(Issue issue) {
        issue.setUpdateTime(new Date());
        issue.setDeleted(true);
        if (issueMapper.updateByPrimaryKeySelective(issue) > 0) {
            return true;
        }
        return false;
    }
}
