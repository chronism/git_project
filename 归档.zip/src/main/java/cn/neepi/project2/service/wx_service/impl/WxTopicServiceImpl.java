package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.TopicMapper;
import cn.neepi.project2.model.Topic;
import cn.neepi.project2.model.TopicExample;
import cn.neepi.project2.service.wx_service.WxTopicService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class WxTopicServiceImpl implements WxTopicService {

    @Autowired
    TopicMapper topicMapper;

    @Override
    public List<Topic> getRelatedTopicList(Integer id) {
        List<Topic> topic = topicMapper.selectRund4();

        return topic;
    }

    @Override
    public Map getTopicList(Integer page,Integer size) {

        TopicExample topicExample = new TopicExample();
        //？add_time desc
        TopicExample.Criteria criteria = topicExample.createCriteria();
        criteria.andDeletedEqualTo(false);
        topicExample.setOrderByClause("add_time desc");
        PageHelper.startPage(page,size);
        List<Topic> topicList = topicMapper.selectByExample(topicExample);
        long count = topicMapper.countByExample(topicExample);
        Map map = new HashMap();
        map.put("count",count);
        map.put("data",topicList);
        return map;
    }

    @Override
    public Topic getDetail(Integer id) {
        Topic topic = topicMapper.selectByPrimaryKey(id);
        Map map = new HashMap();
        map.put("topic",topic);
        return topic;
    }
}
