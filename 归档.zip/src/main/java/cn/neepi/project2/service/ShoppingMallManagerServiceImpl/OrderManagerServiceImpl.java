package cn.neepi.project2.service.ShoppingMallManagerServiceImpl;

import cn.neepi.project2.mapper.OrderGoodsMapper;
import cn.neepi.project2.mapper.OrderMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.OrderGoods;
import cn.neepi.project2.model.OrderGoodsExample;
import cn.neepi.project2.model.ShoppingMallModel.Order;
import cn.neepi.project2.model.ShoppingMallModel.OrderExample;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.UserExample;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.responseModel.OrderDetailLxt;
import cn.neepi.project2.service.ShoppingMallManagerService.OrderManagerService;
import com.alibaba.druid.util.StringUtils;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class OrderManagerServiceImpl implements OrderManagerService {
    @Autowired
    OrderMapper orderMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    OrderGoodsMapper orderGoodsMapper;

    /**
     * 根据查询信息，获取订单信息，并分页
     * @param pageProperties
     * @param userId
     * @param orderSn
     * @param orderStatusArray
     * @return 获取订单信息
     */
    @Override
    public ListItem<List<Order>> getOrderList(PageProperties pageProperties, Integer userId, String orderSn, Short[] orderStatusArray) {
        OrderExample orderExample = new OrderExample();
        orderExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());

        OrderExample.Criteria criteria = orderExample.createCriteria();
        if(userId!=null && userId!=0){
            criteria.andUserIdEqualTo(userId);
        }
        if(orderSn!=null && !StringUtils.isEmpty(orderSn)){
            criteria.andOrderSnEqualTo(orderSn);
        }
        if(orderStatusArray!=null && orderStatusArray.length!=0){
            for (Short orderStatus : orderStatusArray) {
                criteria.andOrderStatusEqualTo(orderStatus);
            }
        }
        criteria.andDeletedEqualTo(false);

        PageHelper.startPage(pageProperties.getPage(),pageProperties.getLimit());
        List<Order> orderList = orderMapper.selectByExample(orderExample);

        ListItem<List<Order>> listListItem = new ListItem<>();
        listListItem.setItems(orderList);
        listListItem.setTotal(orderMapper.countByExample(orderExample));
        return listListItem;
    }

    /**
     *
     * 根据订单id 查看订单详情
     * @param id
     * @return
     */
    @Override
    public OrderDetailLxt getOrderDetail(Integer id) {
        OrderDetailLxt orderDetailLxt = new OrderDetailLxt();

        Order order = orderMapper.selectByPrimaryKey(id);

        User user = userMapper.selectByPrimaryKey(order.getUserId());

        OrderGoodsExample orderGoodsExample = new OrderGoodsExample();
        OrderGoodsExample.Criteria criteria = orderGoodsExample.createCriteria();
        criteria.andOrderIdEqualTo(order.getId());
        List<OrderGoods> orderGoodsList = orderGoodsMapper.selectByExample(orderGoodsExample);

        orderDetailLxt.setOrder(order);
        orderDetailLxt.setOrderGoods(orderGoodsList);
        orderDetailLxt.setUser(user);
        return orderDetailLxt;
    }

    @Override
    public String shipOrder(Map map) {
        Integer orderId = (Integer) map.get("orderId");
        String shipChannel = (String) map.get("shipChannel");
        String shipSn = (String) map.get("shipSn");
        Date date = new Date();
        Order order = orderMapper.selectByPrimaryKey(orderId);
        order.setShipChannel(shipChannel);
        order.setShipSn(shipSn);
        order.setShipTime(date);
        order.setUpdateTime(date);
        order.setOrderStatus((short) 301);
        int i = orderMapper.updateByPrimaryKey(order);
        if(i==1){
            return "发货成功";
        }else {
            return null;
        }

    }

    @Override
    public String refundOrder(Map map) {
        Integer orderId = (Integer) map.get("orderId");
        Object refundMoney = map.get("refundMoney");
        Date date = new Date();
        Order order = orderMapper.selectByPrimaryKey(orderId);
        order.setUpdateTime(date);
        order.setOrderStatus((short) 203);
        int i = orderMapper.updateByPrimaryKey(order);
        if(i==1){
            return "退款成功";
        }else {
            return null;
        }

    }


}
