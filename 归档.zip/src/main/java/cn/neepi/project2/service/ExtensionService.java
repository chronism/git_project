package cn.neepi.project2.service;

import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;

import java.util.List;

/**
 * 推广
 */
public interface ExtensionService {

    /**
     * 分页得到广告
     *
     * @param page
     * @param name
     * @param content
     */
    ListItem<List<Ad>> getAdByList(PageProperties page, String name, String content);

    /**
     * 新增广告
     * @param ad
     */
    Ad addAd(Ad ad);

    /**
     * 更新该广告
     * @param ad
     * @return
     */
    Integer adUpdate(Ad ad);

    /**
     * 删除该广告
     * @param ad
     * @return
     */
    Integer deleteAd(Ad ad);

    /**
     * 分页显示优惠券，带模糊查询
     * @param page
     * @param name
     * @param type
     * @param status
     * @return
     */
    ListItem<List<Coupon>> getCoupon(PageProperties page, String name, Integer type, Integer status);

    /**
     * 新增优惠券信息
     * @param coupon
     * @return
     */
    Coupon insertCoupon(Coupon coupon);

    /**
     * 根据id查询优惠券
     * @param id
     * @return
     */
    Coupon getCouponById(Integer id);

    /**
     * 修改优惠券
     * @param coupon
     * @return
     */
    Integer updateCoupon(Coupon coupon);

    /**
     * 删除优惠券
     * 假删除：将删除状态改为ture
     * @param coupon
     * @return
     */
    Integer deleteCoupon(Coupon coupon);

    /**
     * 分页显示专题
     * @param page
     * @param title
     * @param subtitle
     * @return
     */
    ListItem<List<Topic>> getTopicByPage(PageProperties page, String title, String subtitle);

    /**
     * 向数据库中插入专题
     * @param topic
     * @return
     */
    Topic insertTopic(Topic topic);

    /**
     * 在数据库中更新专题
     * @param topic
     * @return
     */
    Integer updateTopic(Topic topic);

    /**
     * 删除专题
     * 假删除：将deleted属性置为true
     * @param topic
     * @return
     */
    Integer deleteTopic(Topic topic);

    /**
     * 分页显示团购规则信息
     * 带查询
     * @param page
     * @param goodsId
     * @return
     */
    ListItem<List<GrouponRules>> getGrouponRulesByPage(PageProperties page, Integer goodsId);

    /**
     * 新增团购规则
     * @param grouponRules
     * @return
     */
    GrouponRules createGrouponRules(GrouponRules grouponRules);

    /**
     * 修改团购规则
     * @param grouponRules
     * @return
     */
    Integer updateGrouponRules(GrouponRules grouponRules);

    /**
     * 删除团购规则
     * @param grouponRules
     * @return
     */
    Integer deleteGrouponRules(GrouponRules grouponRules);

    /**
     * 分页得到团购活动信息
     * @param page
     * @param goodsId
     * @return
     */
    ListItem<List<Object>> getGrouponByPage(PageProperties page, Integer goodsId);

    /**
     * 显示优惠券详情
     * @param page
     * @param couponUser
     * @return
     */
    ListItem<List<CouponUser>> selectCouponUserByPage(PageProperties page, CouponUser couponUser);
}
