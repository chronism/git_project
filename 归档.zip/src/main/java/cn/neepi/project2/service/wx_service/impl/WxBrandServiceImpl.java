package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.BrandMapper;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import cn.neepi.project2.model.ShoppingMallModel.BrandExample;
import cn.neepi.project2.service.wx_service.WxBrandService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@Service
public class WxBrandServiceImpl implements WxBrandService {
    @Autowired
    BrandMapper brandMapper;


    @Override
    public Brand getBrandDetail(Integer brandId) {

        Brand brand = brandMapper.selectByPrimaryKey(brandId);

        return brand;
    }

    @Override
    public Map getBrandList(Integer page, Integer size) {

        BrandExample brandExample = new BrandExample();
        brandExample.setOrderByClause("add_time desc");
        PageHelper.startPage(page,size);
        List<Brand> brandList = brandMapper.selectByExample(brandExample);
        long count = brandMapper.countByExample(brandExample);
        Map map = new HashMap();
        map.put("totalPages",count);
        map.put("brandList",brandList);
        return map;
    }
}
