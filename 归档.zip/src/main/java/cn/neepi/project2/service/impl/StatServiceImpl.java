package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.OrderGoodsMapper;
import cn.neepi.project2.mapper.OrderMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.ResponseModel.OrderStatInfo;
import cn.neepi.project2.model.ResponseModel.UserStatInfo;
import cn.neepi.project2.model.responseModel.OrderGoodStatInfo;
import cn.neepi.project2.service.StatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/28/028 下午 03:32
 */
@Service
public class StatServiceImpl implements StatService {
    @Autowired
    OrderMapper orderMapper;
    @Autowired
    OrderGoodsMapper orderGoodsMapper;
    @Autowired
    UserMapper userMapper;

    @Override
    public Map<String, Object> orderGoodStat() {
        HashMap<String, Object> data = new HashMap<>();
        String[] columns = {"day", "orders", "products", "amount"};
        data.put("columns", columns);
        List<OrderGoodStatInfo> rows = orderGoodsMapper.queryOrderGoodsStatInfo();
        data.put("rows", rows);
        return data;
    }

    @Override
    public Map<String, Object> orderStat() {
        HashMap<String, Object> data = new HashMap<>();
        String[] columns = {"day", "orders", "customers", "amount", "pcr"};
        data.put("columns", columns);
        List<OrderStatInfo> rows = orderMapper.queryOrderStatInfo();
        data.put("rows", rows);
        return data;
    }

    @Override
    public Map<String, Object> userStat() {
        HashMap<String, Object> data = new HashMap<>();
        String[] columns = {"day", "users"};
        data.put("columns", columns);
        List<UserStatInfo> rows = userMapper.queryUserStatInfo();
        data.put("rows", rows);
        return data;
    }
}
