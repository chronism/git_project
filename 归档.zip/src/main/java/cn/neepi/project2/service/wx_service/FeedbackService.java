package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.Feedback;

public interface FeedbackService {
    Integer insertFeedback(Feedback feedback);
}
