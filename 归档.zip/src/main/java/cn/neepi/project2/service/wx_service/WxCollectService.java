package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.wx_responseModel.CollectResponse;

import java.util.List;
import java.util.Map;

public interface WxCollectService {
    Map getCollectList(Byte type , PageProperties pageProperties);
    Map addOrDeleteCollect(Map<String , Integer> map);
}
