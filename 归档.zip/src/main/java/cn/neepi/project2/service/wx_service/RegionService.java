package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.ShoppingMallModel.Region;

import java.util.List;

public interface RegionService {

    List<Region> selectAllRegionByPid(Integer pid);
}
