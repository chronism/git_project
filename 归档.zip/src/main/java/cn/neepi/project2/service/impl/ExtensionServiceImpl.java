package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.*;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.ExtensionService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * 推广
 */
@Service
public class ExtensionServiceImpl implements ExtensionService {

    @Autowired
    AdMapper adMapper;
    @Autowired
    CouponMapper couponMapper;
    @Autowired
    TopicMapper topicMapper;
    @Autowired
    GrouponRulesMapper grouponRulesMapper;
    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    GrouponMapper grouponMapper;
    @Autowired
    CouponUserMapper couponUserMapper;
    /**
     * 分页得到广告
     * 带查询
     * @param page
     * @param name
     * @param content
     */
    @Override
    public ListItem<List<Ad>> getAdByList(PageProperties page, String name, String content) {
        page.setSort("id");
        AdExample adExample = new AdExample();
        //拼接模糊查询信息：name\content
        AdExample.Criteria criteria = adExample.createCriteria();
        if (name!=null&&!StringUtil.isEmpty(name)) {
            criteria.andNameLike("%"+name+"%");
        }
        if (content!=null&&!StringUtil.isEmpty(content)) {
            criteria.andContentLike("%"+content+"%");
        }
        criteria.andDeletedEqualTo(false);
        //开启分页查询
        PageHelper.startPage(page.getPage(),page.getLimit());
        //查询分页广告
        adExample.setOrderByClause(page.getSort());
        List<Ad> ads = adMapper.selectByExample(adExample);
        //查询广告条数并拼装
        ListItem<List<Ad>> adlist = new ListItem<>();
        adlist.setTotal(adMapper.countByExample(adExample));
        adlist.setItems(ads);
        return adlist;
    }
    /**
     * 新增广告
     * @param ad
     */
    @Override
    public Ad addAd(Ad ad) {
        ad.setAddTime(new Date());
        ad.setUpdateTime(new Date());
        ad.setEnabled(true);
        ad.setDeleted(false);
        adMapper.insert(ad);
        int i = adMapper.selectLastInsertId();
        ad.setId(i);
        return ad;
    }

    /**
     * 更新该条广告
     * @param ad
     * @return
     */
    @Override
    public Integer adUpdate(Ad ad) {
        ad.setUpdateTime(new Date());
        int i = adMapper.updateByPrimaryKey(ad);

        return i;
    }

    /**
     * 删除该广告
     * 假删除：将该广告不可见
     * @param ad
     * @return
     */
    @Override
    public Integer deleteAd(Ad ad) {
        ad.setDeleted(true);
        ad.setEnabled(false);
        ad.setUpdateTime(new Date());
        int i = adMapper.updateByPrimaryKey(ad);
        return i;
    }

    /**
     * 分页得到优惠券信息，带条件查询
     * 查询删除状态deleted为false的数据
     * @param page
     * @param name
     * @param type
     * @param status
     * @return
     */
    @Override
    public ListItem<List<Coupon>> getCoupon(PageProperties page, String name, Integer type, Integer status) {
        page.setSort("id");
        CouponExample couponExample = new CouponExample();
        //条件
        CouponExample.Criteria criteria1 = couponExample.createCriteria();
        if (name!=null&&!StringUtil.isEmpty(name)) {
            criteria1.andNameLike("%"+name+"%");
        }
        if (type!=null) {
            criteria1.andTypeEqualTo(type);
        }
        if (status !=null) {
            criteria1.andStatusEqualTo(status);
        }
        criteria1.andDeletedEqualTo(false);
        //开启分页查询
        PageHelper.startPage(page.getPage(),page.getLimit());
        //排序，查询
        couponExample.setOrderByClause(page.getSort());
        List<Coupon> coupons = couponMapper.selectByExample(couponExample);
        //查询广告条数并拼装
        ListItem<List<Coupon>> conponlist= new ListItem<>();
        conponlist.setItems(coupons);
        conponlist.setTotal(couponMapper.countByExample(couponExample));
        return conponlist;
    }

    /**
     * 新增优惠券信息
     * @param coupon
     * @return
     */
    @Override
    public Coupon insertCoupon(Coupon coupon) {
        //参数判断
        if(judgeCouponDate(coupon)) {
            return null;
        }
        coupon.setAddTime(new Date());
        coupon.setUpdateTime(new Date());
        coupon.setDeleted(false);
        couponMapper.insertSelective(coupon);
        return coupon;
    }

    /**
     * coupon 传入的日期参数判断
     * @param coupon
     * @return
     */
    public Boolean judgeCouponDate(Coupon coupon) {
        if (coupon.getDays() == 0 ) {
            if(coupon.getStartTime() == null ||coupon.getEndTime() == null) {
                return  true;
            }
            if (coupon.getStartTime().after(coupon.getEndTime())||coupon.getEndTime().equals(coupon.getStartTime())) {
                return true;
            }
        } else if(coupon.getStartTime() != null ||coupon.getEndTime() != null ){
            return true;
        }
        return false;
    }

    /**
     * 根据id查询优惠券
     * @param id
     * @return
     */
    @Override
    public Coupon getCouponById(Integer id) {

        Coupon coupon = couponMapper.selectByPrimaryKey(id);
        return coupon;
    }

    /**
     * 修改优惠券
     * @param coupon
     * @return
     */
    @Override
    public Integer updateCoupon(Coupon coupon) {
        //参数判断
        if(judgeCouponDate(coupon)) {
            return null;
        }
        coupon.setUpdateTime(new Date());
        int i = couponMapper.updateByPrimaryKeySelective(coupon);
        return i;
    }

    /**
     * 删除优惠券
     * 假删除：将删除状态改为ture
     * @param coupon
     * @return
     */
    @Override
    public Integer deleteCoupon(Coupon coupon) {
        coupon.setUpdateTime(new Date());
        coupon.setDeleted(true);
        Integer i = couponMapper.updateByPrimaryKeySelective(coupon);
        return i;
    }

    /**
     * 分页显示专题
     * @param page
     * @param title
     * @param subtitle
     * @return
     */
    @Override
    public ListItem<List<Topic>> getTopicByPage(PageProperties page, String title, String subtitle) {
        TopicExample topicExample = new TopicExample();
        TopicExample.Criteria criteria = topicExample.createCriteria();
        //查询条件拼接
        if ( StringUtil.isNotEmpty(title)) {
            criteria.andTitleLike("%"+title+"%");
        }
        if ( StringUtil.isNotEmpty(subtitle)) {
            criteria.andSubtitleLike("%"+subtitle+"%");
        }
        criteria.andDeletedEqualTo(false);
        //分页查询
        PageHelper.startPage(page.getPage(),page.getLimit());
        topicExample.setOrderByClause(page.getSort()+" "+page.getOrder());
        List<Topic> topics = topicMapper.selectByExample(topicExample);
        long l = topicMapper.countByExample(topicExample);
        //组装数据
        ListItem<List<Topic>> listListItem = new ListItem<>();
        listListItem.setItems(topics);
        listListItem.setTotal(l);
        return listListItem;
    }

    /**
     * 向数据库中插入专题
     * @param topic
     * @return
     */
    @Override
    public Topic insertTopic(Topic topic) {
        topic.setDeleted(false);
        topic.setUpdateTime(new Date());
        topicMapper.insert(topic);
        Topic topic1 = topicMapper.selectByPrimaryKey(topic.getId());
        topic.setAddTime(topic1.getAddTime());
        topic.setUpdateTime(topic1.getUpdateTime());
        return topic;
    }

    /**
     * 在数据库中更新专题内容
     * 返回更新数据
     * @param topic
     * @return
     */
    @Override
    public Integer updateTopic(Topic topic) {
        topic.setUpdateTime(new Date());
        int i = topicMapper.updateByPrimaryKeySelective(topic);
        return i;
    }

    /**
     * 删除专题
     * 假删除：将deleted属性置为true
     * @param topic
     * @return
     */
    @Override
    public Integer deleteTopic(Topic topic) {
        topic.setUpdateTime(new Date());
        topic.setDeleted(true);
        int i = topicMapper.updateByPrimaryKeySelective(topic);
        return i;
    }

    /**
     * 分页显示团购规则信息
     * 带查询
     * @param page
     * @param goodsId
     * @return
     */
    @Override
    public ListItem<List<GrouponRules>> getGrouponRulesByPage(PageProperties page, Integer goodsId) {
        GrouponRulesExample grouponRulesExample = new GrouponRulesExample();
        GrouponRulesExample.Criteria criteria = grouponRulesExample.createCriteria();
        if(goodsId != null) {
            criteria.andGoodsIdEqualTo(goodsId);
        }
        criteria.andDeletedEqualTo(false);
        PageHelper.startPage(page.getPage(),page.getLimit());
        List<GrouponRules> grouponRules = grouponRulesMapper.selectByExample(grouponRulesExample);
        ListItem<List<GrouponRules>> grouponRulesListItem = new ListItem<>();
        grouponRulesListItem.setItems(grouponRules);
        long l = grouponRulesMapper.countByExample(grouponRulesExample);
        grouponRulesListItem.setTotal(l);
        return grouponRulesListItem;
    }

    /**
     * 新增团购规则
     * 团购规则信息组装：商品信息+已有团购规则信息
     * @param grouponRules
     * @return
     */
    @Override
    public GrouponRules createGrouponRules(GrouponRules grouponRules) {
        Goods goods = goodsMapper.selectByPrimaryKey(grouponRules.getGoodsId());
        //拼装信息
        grouponRules.setDeleted(false);
        grouponRules.setGoodsName(goods.getName());
        grouponRules.setPicUrl(goods.getPicUrl());
        grouponRules.setAddTime(new Date());
        grouponRules.setUpdateTime(new Date());
        BigDecimal retailPrice = goods.getRetailPrice();
        BigDecimal discount = grouponRules.getDiscount();
        if(retailPrice.compareTo(discount) < 0) {
            grouponRules.setDiscount(retailPrice);
        }
        //插入信息
        grouponRulesMapper.insert(grouponRules);
        GrouponRules grouponRules1 = grouponRulesMapper.selectByPrimaryKey(grouponRules.getId());
        return grouponRules1;
    }

    /**
     * 修改团购规则
     * @param grouponRules
     * @return
     */
    @Override
    public Integer updateGrouponRules(GrouponRules grouponRules) {
        Goods goods = goodsMapper.selectByPrimaryKey(grouponRules.getGoodsId());
        BigDecimal retailPrice = goods.getRetailPrice();
        BigDecimal discount = grouponRules.getDiscount();
        if(retailPrice.compareTo(discount) < 0) {
            grouponRules.setDiscount(retailPrice);
        }
        grouponRules.setUpdateTime(new Date());
        grouponRules.setDeleted(false);
        int i = grouponRulesMapper.updateByPrimaryKey(grouponRules);
        return i;
    }

    /**
     * 删除团购规则
     * @param grouponRules
     * @return
     */
    @Override
    public Integer deleteGrouponRules(GrouponRules grouponRules) {
        grouponRules.setUpdateTime(new Date());
        grouponRules.setDeleted(true);
        int i = grouponRulesMapper.updateByPrimaryKey(grouponRules);
        return i;
    }

    /**
     * 分页查询团购活动信息
     * 带查询条件orderId
     * @param page
     * @param id
     * @return
     */
    @Override
    public ListItem<List<Object>>  getGrouponByPage(PageProperties page, Integer id) {

        //查出 rules数据
        GrouponRulesExample grouponRulesExample = new GrouponRulesExample();
        GrouponRulesExample.Criteria criteria = grouponRulesExample.createCriteria();
        if(id != null) {
            criteria.andGoodsIdEqualTo(id);
        }
        criteria.andDeletedEqualTo(false);
        List<GrouponRules> grouponRules = grouponRulesMapper.selectByExample(grouponRulesExample);
        //查出groupon数据，goods数据并组装
        ArrayList<Object> list = new ArrayList<>();
        for (GrouponRules grouponRule : grouponRules) {
            HashMap<Object, Object> map = new HashMap<>();
            Goods goods = goodsMapper.selectByPrimaryKey(grouponRule.getGoodsId());
            Groupon groupon = grouponMapper.selectByGrouponRulesId(grouponRule.getId());
            List<Groupon> subgroupons = grouponMapper.selectOrderIdAndUserId(grouponRule.getId());
            map.put("groupon",groupon);
            map.put("goods",goods);
            map.put("rules",grouponRule);
            map.put("subGroupons",subgroupons);
            list.add(map);
        }
        ListItem<List<Object>> listItem = new ListItem<>();
        long l = grouponRulesMapper.countByExample(grouponRulesExample);
        listItem.setItems(list);
        listItem.setTotal(l);
        return listItem;
    }

    /**
     * 显示优惠券详情
     * @param page
     * @param couponUser
     * @return
     */
    @Override
    public ListItem<List<CouponUser>> selectCouponUserByPage(PageProperties page, CouponUser couponUser) {
        CouponUserExample couponUserExample = new CouponUserExample();
        CouponUserExample.Criteria criteria = couponUserExample.createCriteria();
        if(couponUser.getCouponId() != null ) {
            criteria.andCouponIdEqualTo(couponUser.getCouponId());
        }
        if(couponUser.getUserId() != null ) {
            criteria.andUserIdEqualTo(couponUser.getUserId());
        }
        if(couponUser.getStatus() != null ) {
            criteria.andStatusEqualTo(couponUser.getStatus());
        }
        PageHelper.startPage(page.getPage(),page.getLimit());
        List<CouponUser> couponUsers = couponUserMapper.selectByExample(couponUserExample);
        long l = couponUserMapper.countByExample(couponUserExample);
        ListItem<List<CouponUser>> listListItem = new ListItem<>();
        listListItem.setTotal(l);
        listListItem.setItems(couponUsers);
        return listListItem;
    }

}
