package cn.neepi.project2.service;

import cn.neepi.project2.model.responseModel.Dashboard;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
public interface DashboardService {
    /**
     * 获取首页面板的属性
     * @return Dashboard 返回所有admin首页的数量
     */
    Dashboard getTotalNumbers();
}
