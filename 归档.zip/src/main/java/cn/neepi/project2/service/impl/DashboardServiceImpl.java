package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.GoodsMapper;
import cn.neepi.project2.mapper.GoodsProductMapper;
import cn.neepi.project2.mapper.OrderMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.GoodsExample;
import cn.neepi.project2.model.GoodsProductExample;
import cn.neepi.project2.model.ShoppingMallModel.OrderExample;
import cn.neepi.project2.model.responseModel.Dashboard;
import cn.neepi.project2.model.UserExample;
import cn.neepi.project2.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@Service
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    GoodsProductMapper productMapper;
    @Autowired
    OrderMapper orderMapper;

    @Override
    public Dashboard getTotalNumbers() {
        Dashboard dashboard = new Dashboard();

        dashboard.setGoodsTotal(goodsMapper.countByExample(new GoodsExample()));
        dashboard.setUserTotal(userMapper.countByExample(new UserExample()));
        dashboard.setProductTotal(productMapper.countByExample(new GoodsProductExample()));
        dashboard.setOrderTotal(orderMapper.countByExample(new OrderExample()));

        return dashboard;
    }
}
