package cn.neepi.project2.service.ShoppingMallManagerService;

import cn.neepi.project2.exception.shoppingMallException.CategoryChangeInvalidException;
import cn.neepi.project2.exception.shoppingMallException.CategoryNameRepeatedException;
import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import cn.neepi.project2.model.ShoppingMallModel.CateGoryL1;

import java.util.List;

public interface CategoryManagerService {

    /**
     * 获取商品类目表
     * @return 商品类目表
     */
    List<CateGory> getCategoryList();

    /**
     * 获取一级商品类目
     * @return 一级商品类目表
     */
    List<CateGoryL1> getCategoryL1();

    /**
     * 添加新的商品类目
     * @param cateGory
     * @return 新的商品类目
     */
    CateGory addCateGory(CateGory cateGory) throws CategoryNameRepeatedException;

    /**
     * @param cateGory
     * @return 更新商品类目
     * @throws CategoryNameRepeatedException
     */
    CateGory updateCateGory(CateGory cateGory) throws CategoryNameRepeatedException, CategoryChangeInvalidException;

    /**
     * 删除商品类目
     * @param cateGory
     * @return
     */
    Boolean deleteCateGory(CateGory cateGory);
}
