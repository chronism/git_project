package cn.neepi.project2.service;
import cn.neepi.project2.model.Comment;
import cn.neepi.project2.model.Goods;

import cn.neepi.project2.model.requestModel.GoodsCreateCxs;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import java.util.HashMap;

public interface GoodsService {
    /**
     *根据商品编号和名称获取商品list
     * @param pageProperties 分页属性
     * @param goodsSn  根据商品编号查询
     * @param name 根据商品名称查询
     * @return ListItem 返回对应数据
     */
    ListItem getGoodsList(PageProperties pageProperties, String goodsSn, String name);

    /**
     *根据商品编号和名称获取商品list
     * @param pageProperties 分页属性
     * @param valueId  根据商品编号查询
     * @param userId 根据用户编号查询
     * @return ListItem 返回对应数据
     */
    ListItem getCommentList(PageProperties pageProperties,Integer valueId,Integer userId);

    /**
     *删除商品
     */
    Integer  goodsDelete(Goods goods);

    /**
     *更新商品
     */
    Integer goodsUpdate(GoodsCreateCxs info);

    /**
     * 删除评价
     */
    Integer commentDelete(Comment comment);

    /**
     * 商品类别
     * @return
     */
    HashMap queryCatAndBrand( );

    /**
     * 上架商品
     */
    Integer createGoods(GoodsCreateCxs info);

    /**
     * 得到商品详情
     * @param id
     * @return
     */
    HashMap getGoodsDetail(Integer id);

}
