package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.FeedbackMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.Feedback;
import cn.neepi.project2.model.User;
import cn.neepi.project2.service.wx_service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class FeedbackServiceImpl implements FeedbackService {
    @Autowired
    FeedbackMapper feedbackMapper;
    @Autowired
    UserMapper userMapper;
    @Override
    public Integer insertFeedback(Feedback feedback) {
        feedback.setAddTime(new Date());
        feedback.setUpdateTime(new Date());
        feedback.setDeleted(false);
        feedback.setStatus(0);
        User user = userMapper.selectByPrimaryKey(feedback.getUserId());
        feedback.setUsername(user.getUsername());
        int insert = feedbackMapper.insert(feedback);
        return insert;
    }
}
