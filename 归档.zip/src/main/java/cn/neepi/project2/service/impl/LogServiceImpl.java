package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.LogMapper;
import cn.neepi.project2.model.Log;
import cn.neepi.project2.model.LogExample;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.LogService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author heyongbin
 * @date  2019/12/24
 * @version V1.0
 **/
@Service
public class LogServiceImpl implements LogService {
    @Autowired
    LogMapper logMapper;

    @Override
    public Integer addLoginOrLogoutLog() {
        return null;
    }

    @Override
    public ListItem queryLogList(PageProperties pageProperties, String name) {
        LogExample logExample = new LogExample();
        LogExample.Criteria criteria = logExample.createCriteria();
        if (name != null) {
            criteria.andAdminLike("%" + name + "%");
        }
        logExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        // 分页插件
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        // 调用mapper
        List<Log> logs = logMapper.selectByExample(logExample);
        ListItem<List<Log>> logListItem = new ListItem<>();
        logListItem.setItems(logs);
        logListItem.setTotal(logMapper.countByExample(logExample));
        return logListItem;
    }
}
