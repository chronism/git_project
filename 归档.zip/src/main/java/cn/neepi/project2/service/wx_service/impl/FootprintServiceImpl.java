package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.FootprintMapper;
import cn.neepi.project2.mapper.GoodsMapper;
import cn.neepi.project2.model.Footprint;
import cn.neepi.project2.model.FootprintExample;
import cn.neepi.project2.model.Goods;
import cn.neepi.project2.service.wx_service.FootprintService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Service
public class FootprintServiceImpl implements FootprintService {
    @Autowired
    FootprintMapper footprintMapper;
    @Autowired
    GoodsMapper goodsMapper;
    /**
     * 分页查询足迹信息
     * 多表查询，足迹信息+商品信息
     * @param id
     * @param page
     * @param size
     * @return
     */
    @Override
    public HashMap selectFootprint(Integer id, Integer page, Integer size) {
        FootprintExample footprintExample = new FootprintExample();
        footprintExample.setOrderByClause("add_time desc");
        FootprintExample.Criteria criteria = footprintExample.createCriteria();
        criteria.andUserIdEqualTo(id);
        criteria.andDeletedEqualTo(false);
        PageHelper.startPage(page,size);
        List<Footprint> footprintList = footprintMapper.selectByExample(footprintExample);
        long l = footprintMapper.countByExample(footprintExample);
        for (Footprint footprint : footprintList) {
            Goods goods = goodsMapper.selectByPrimaryKey(footprint.getGoodsId());
            footprint.setBrief(goods.getBrief());
            footprint.setPicUrl(goods.getPicUrl());
            footprint.setName(goods.getName());
            footprint.setRetailPrice(goods.getRetailPrice());
        }
        HashMap<Object, Object> map = new HashMap<>();
        map.put("footprintList",footprintList);
        map.put("totalPages",l);
        return map;
    }

    /**
     *
     * @param footprintId
     * @return
     */
    @Override
    public Integer deleteFootprint(Integer footprintId) {
        Integer i = footprintMapper.updateForDeleteFootprint(footprintId);
        return i;
    }
}
