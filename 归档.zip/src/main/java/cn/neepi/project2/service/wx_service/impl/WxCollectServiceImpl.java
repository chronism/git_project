package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.CollectMapper;
import cn.neepi.project2.mapper.GoodsMapper;
import cn.neepi.project2.model.Collect;
import cn.neepi.project2.model.CollectExample;
import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.wx_responseModel.CollectResponse;
import cn.neepi.project2.service.wx_service.WxCollectService;
import com.github.pagehelper.PageHelper;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class WxCollectServiceImpl implements WxCollectService {
    @Autowired
    CollectMapper collectMapper;

    @Autowired
    GoodsMapper goodsMapper;
    /**
     * 获取收藏列表
     * @param type
     * @param pageProperties
     * @return
     */
    @Override
    public Map getCollectList(Byte type, PageProperties pageProperties) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();

        CollectExample collectExample = new CollectExample();
        CollectExample.Criteria criteria = collectExample.createCriteria();
        criteria.andUserIdEqualTo(user.getId());
        criteria.andTypeEqualTo(type);
        criteria.andDeletedEqualTo(false);

        List<Collect> collects = collectMapper.selectByExample(collectExample);
        ArrayList<CollectResponse> collectList = new ArrayList<>();

        for (Collect collect : collects) {
            Goods goods = goodsMapper.selectByPrimaryKey(collect.getValueId());
            CollectResponse collectResponse = new CollectResponse();
            collectResponse.setId(collect.getId());
            collectResponse.setValueId(goods.getId());
            collectResponse.setName(goods.getName());
            collectResponse.setPicUrl(goods.getPicUrl());
            collectResponse.setRetailPrice(goods.getRetailPrice());
            collectResponse.setType(collect.getType());
            collectResponse.setBrief(goods.getBrief());

            collectList.add(collectResponse);
        }
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getSize());

        HashMap<Object, Object> map = new HashMap<>();
        map.put("collectList",collectList);
        map.put("totalPages",collectMapper.countByExample(collectExample));

        return map;
    }

    @Override
    public Map addOrDeleteCollect(Map<String,Integer> map) {
        Byte type = Byte.valueOf(map.get("type").toString());
        Integer valueId = map.get("valueId");

        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        CollectExample collectExample = new CollectExample();
        CollectExample.Criteria criteria = collectExample.createCriteria();
        criteria.andUserIdEqualTo(user.getId());
        criteria.andTypeEqualTo(type);
        criteria.andDeletedEqualTo(false);
        criteria.andValueIdEqualTo(valueId);
        List<Collect> collects = collectMapper.selectByExample(collectExample);
        Date date = new Date();
        Map<Object, Object> returnMap = new HashMap<>();
        if(!collects.isEmpty()&&collects.size()!=0){
            for (Collect collect : collects) {
                collect.setDeleted(true);
                collect.setUpdateTime(date);
                collectMapper.updateByExample(collect,collectExample);
            }
            returnMap.put("type","delete");
            return returnMap;
        }else{
            Collect collect = new Collect();

            collect.setUserId(user.getId());
            collect.setValueId(valueId);
            collect.setType(type);
            collect.setAddTime(date);
            collect.setUpdateTime(date);
            collect.setDeleted(false);
            collectMapper.insert(collect);
            returnMap.put("type","add");
            return returnMap;
        }
    }
}
