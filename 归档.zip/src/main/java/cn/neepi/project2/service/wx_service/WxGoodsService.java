package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.Goods;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.wx_responseModel.GoodsCategroyGoodList;
import cn.neepi.project2.model.wx_responseModel.GoodsCategroyList;
import cn.neepi.project2.model.wx_responseModel.GoodsDetail;

import java.util.List;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
public interface WxGoodsService {

    GoodsCategroyList getGoodsCategoryList(Integer id);

    GoodsCategroyGoodList getCategoryGoods(Integer categoryId,Integer page,Integer size,Class type);

    GoodsDetail getGoodsDetail(Integer id);

    List<Goods> getRelatedGoodsList(Integer id);

    GoodsCategroyGoodList getGoodsList(PageProperties pageProperties, String keyword);

    void addSearchHistory(String keyword, Integer id);
}
