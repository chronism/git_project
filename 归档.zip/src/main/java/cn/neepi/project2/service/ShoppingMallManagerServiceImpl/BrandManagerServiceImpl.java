package cn.neepi.project2.service.ShoppingMallManagerServiceImpl;

import cn.neepi.project2.exception.shoppingMallException.ManufacturerRepeatedException;
import cn.neepi.project2.mapper.BrandMapper;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.model.ShoppingMallModel.Brand;
import cn.neepi.project2.model.ShoppingMallModel.BrandExample;
import cn.neepi.project2.service.ShoppingMallManagerService.BrandManagerService;
import com.github.pagehelper.PageHelper;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class BrandManagerServiceImpl implements BrandManagerService {


    @Autowired
    BrandMapper brandMapper;

    /**
     * 获取制造商列表，delete为false，名字模糊查询
     * @param pageProperties
     * @param name
     * @param id
     * @return 获取制造商列表
     */
    @Override
    public ListItem<List<Brand>> getBrandList(PageProperties pageProperties, String name, Integer id) {
        BrandExample brandExample = new BrandExample();
        brandExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());

        BrandExample.Criteria criteria = brandExample.createCriteria();
        if (id != null && id != 0) {
            criteria.andIdEqualTo(id);
        }
        if (name != null && !StringUtils.isEmpty(name)) {
            criteria.andNameLike("%" + name + "%");
        }
        criteria.andDeletedEqualTo(false);

        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Brand> brands = brandMapper.selectByExample(brandExample);
        ListItem<List<Brand>> brandListItem = new ListItem<>();
        brandListItem.setItems(brands);
        brandListItem.setTotal(brandMapper.countByExample(brandExample));
        return brandListItem;
    }

    /**
     * 添加商品牌（若品牌相同则不与添加）
     * @param brand
     * @return
     */
    @Override
    public Brand addBrand(Brand brand) throws ManufacturerRepeatedException {

        Date date = new Date();
        brand.setAddTime(date);
        brand.setUpdateTime(date);
        brand.setDeleted(false);


        BrandExample brandExample = new BrandExample();
        BrandExample.Criteria criteria = brandExample.createCriteria();
        criteria.andNameEqualTo(brand.getName());
        criteria.andDeletedEqualTo(false);
        long l = brandMapper.countByExample(brandExample);
        if (l!=0L){
            throw new ManufacturerRepeatedException();
        }else{
            int insert = brandMapper.insert(brand);
            if(insert ==1 ){
                return brand;
            }else{
                return null;
            }
        }
    }

    /**
     * 先更新，数据库中检索品牌商名称，0则系统异常，1则返回brand，其他报重复异常，报异常，则回退
     * @param brand
     * @return 更新品牌商信息
     * @throws ManufacturerRepeatedException
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Brand updateBrand(Brand brand) throws ManufacturerRepeatedException {
        Date date = new Date();
        brand.setUpdateTime(date);

        BrandExample brandExample = new BrandExample();
        BrandExample.Criteria criteria = brandExample.createCriteria();
        criteria.andIdEqualTo(brand.getId());
        brandMapper.updateByExample(brand,brandExample);

        BrandExample brandExample1 = new BrandExample();
        BrandExample.Criteria criteria1 = brandExample1.createCriteria();
        criteria1.andNameEqualTo(brand.getName());
        criteria1.andDeletedEqualTo(false);
        long l = brandMapper.countByExample(brandExample1);
        if (l==0L){
            return null;
        }else if(l==1){
            return brand;
        }else{
            throw new ManufacturerRepeatedException();
        }

    }

    /**
     * 删除品牌商信息，将brand的deleted更新为true；
     * @param brand
     */
    @Override
    public Boolean deleteBrand(Brand brand) {
        brand.setDeleted(true);
        BrandExample brandExample = new BrandExample();
        BrandExample.Criteria criteria = brandExample.createCriteria();
        criteria.andIdEqualTo(brand.getId());
        int i = brandMapper.updateByExample(brand, brandExample);
        if(i==1){
            return true;
        }else {
            return false;
        }
    }
}
