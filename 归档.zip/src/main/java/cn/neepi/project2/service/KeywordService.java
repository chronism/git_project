package cn.neepi.project2.service;

import cn.neepi.project2.model.Keyword;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import java.util.List;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/30/030 上午 08:59
 */
public interface KeywordService {

   ListItem<List<Keyword>> queryIssues(PageProperties pageProperties, String keyword,String url);

    boolean createKeyword(Keyword keyword);

    boolean updateKeyword(Keyword keyword);

    boolean deleteKeyword(Keyword keyword);
}
