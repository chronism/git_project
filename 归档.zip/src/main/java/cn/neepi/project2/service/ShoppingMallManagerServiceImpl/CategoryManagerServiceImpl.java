package cn.neepi.project2.service.ShoppingMallManagerServiceImpl;

import cn.neepi.project2.exception.shoppingMallException.CategoryChangeInvalidException;
import cn.neepi.project2.exception.shoppingMallException.CategoryNameRepeatedException;
import cn.neepi.project2.mapper.CateGoryL1Mapper;
import cn.neepi.project2.mapper.CateGoryMapper;
import cn.neepi.project2.model.ShoppingMallModel.CateGory;
import cn.neepi.project2.model.ShoppingMallModel.CateGoryExample;
import cn.neepi.project2.model.ShoppingMallModel.CateGoryL1;
import cn.neepi.project2.service.ShoppingMallManagerService.CategoryManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
@Service
public class CategoryManagerServiceImpl implements CategoryManagerService {
    @Autowired
    CateGoryMapper cateGoryMapper;

    @Autowired
    CateGoryL1Mapper cateGoryL1Mapper;

    /**
     * 查询未删除商品类目deleted为false
     * @return 商品类目列表
     */
    @Override
    public List<CateGory> getCategoryList() {
        int pid1=0;
        CateGoryExample cateGoryExample = new CateGoryExample();
        CateGoryExample.Criteria criteria = cateGoryExample.createCriteria();
        criteria.andPidEqualTo(pid1);
        criteria.andDeletedEqualTo(false);
        List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExample);

        CateGoryExample cateGoryExample1 =null;
        CateGoryExample.Criteria criteria1 =null;
        for (CateGory cateGory : cateGories) {
            cateGoryExample1 = new CateGoryExample();
            criteria1 = cateGoryExample1.createCriteria();
            criteria1.andPidEqualTo(cateGory.getId());
            criteria1.andDeletedEqualTo(false);
            List<CateGory> cateGories1 = cateGoryMapper.selectByExample(cateGoryExample1);

            cateGory.setChildren(cateGories1);
        }
        return cateGories;
    }

    /**
     * 查询未被删除的一级类目列表deleted为false
     * @return 一级类目列表
     */
    @Override
    public List<CateGoryL1> getCategoryL1() {
        String level = "L1";
        Boolean deleted = false;
        List<CateGoryL1> cateGoryList = cateGoryL1Mapper.getCateGoryList(level,deleted);
        return cateGoryList;
    }

    /**
     * 添加新类目，同级类目不可以重名，不同级类目可以重名
     * @param cateGory
     * @return 添加新类目
     * @throws CategoryNameRepeatedException
     */
    @Override
    public CateGory addCateGory(CateGory cateGory) throws CategoryNameRepeatedException {
        Date date = new Date();
        cateGory.setAddTime(date);
        cateGory.setUpdateTime(date);
        cateGory.setDeleted(false);

        String level1 ="L1";
        String level2 ="L2";
        if(level1.equals(cateGory.getLevel())){
            return insertCategoryBylevel(level1,cateGory);
        }
        if(level2.equals(cateGory.getLevel())){
            return insertCategoryBylevel(level2, cateGory);

        }
        return null;
    }


    /**
     * @param level
     * @param cateGory
     * @return 根据类目级别添加类目
     * @throws CategoryNameRepeatedException
     */
    private CateGory insertCategoryBylevel(String level ,CateGory cateGory) throws CategoryNameRepeatedException {
        Boolean flag = checkRepeatedName(level, cateGory);
        if(flag){
            int insert = cateGoryMapper.insert(cateGory);
            if(insert==1){
                return cateGory;
            }else{
                return null;
            }
        }else {
            throw new CategoryNameRepeatedException();
        }
    }

    /**
     * 更新商品类目（id不变），同级商品类目不能重复
     * 一级变二级：如果有子级类目，则不可以变为二级目录;不可以变为自己的子级
     * 二级变一级：
     * @param cateGory
     * @return 更新商品类目
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CateGory updateCateGory(CateGory cateGory) throws CategoryNameRepeatedException, CategoryChangeInvalidException {

        Date date = new Date();
        cateGory.setUpdateTime(date);
        cateGory.setDeleted(false);

        String level1 ="L1";
        String level2 ="L2";
        CateGoryExample cateGoryExample = new CateGoryExample();
        CateGoryExample.Criteria criteria = cateGoryExample.createCriteria();
        criteria.andIdEqualTo(cateGory.getId());
        CateGory cateGoryOrigin = cateGoryMapper.selectByPrimaryKey(cateGory.getId());

        CateGoryExample cateGoryExample1 = new CateGoryExample();
        CateGoryExample.Criteria criteria1 = cateGoryExample1.createCriteria();
        criteria1.andPidEqualTo(cateGoryOrigin.getId());
        criteria1.andDeletedEqualTo(false);
        List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExample1);

        if(level1.equals(cateGoryOrigin.getLevel())){
            if(cateGories!=null && cateGories.size()!=0 && level2.equals(cateGory.getLevel())){
                throw new CategoryChangeInvalidException("402.category.invalid1");
            }
            if(cateGory.getPid().equals(cateGoryOrigin.getId())){
                throw new CategoryChangeInvalidException("402.category.invalid2");
            }
            return updateCategoryByLevel(cateGory.getLevel(), cateGory);
        }
        if(level2.equals(cateGoryOrigin.getLevel())){
            return updateCategoryByLevel(cateGory.getLevel(), cateGory);
        }
        return null;
    }

    /**
     * 删除商品类目，如果是一级类目，则将一级和二级类目的deleted 状态 变更为true
     * 如果是二级目录，则将二级类目的deleted 状态 变更为true
     * @param cateGory
     * @return
     */
    @Override
    public Boolean deleteCateGory(CateGory cateGory) {
        String level1 ="L1";
        String level2 ="L2";


        if(level1.equals(cateGory.getLevel())){
            CateGoryExample cateGoryExample = new CateGoryExample();
            CateGoryExample.Criteria criteria = cateGoryExample.createCriteria();
            cateGory.setDeleted(true);
            criteria.andIdEqualTo(cateGory.getId());
            int i = cateGoryMapper.updateByExample(cateGory, cateGoryExample);
            if(i==1){
                CateGoryExample cateGoryExampleSon = new CateGoryExample();
                CateGoryExample.Criteria criteriaSon = cateGoryExampleSon.createCriteria();
                criteriaSon.andPidEqualTo(cateGory.getId());

                List<CateGory> cateGories = cateGoryMapper.selectByExample(cateGoryExampleSon);
                for (CateGory gory : cateGories) {
                    gory.setDeleted(true);
                    cateGoryMapper.updateByExample(gory,cateGoryExampleSon);
                }
                return true;

            }else{
                return false;
            }


        }
        if(level2.equals(cateGory.getLevel())){
            CateGoryExample cateGoryExample = new CateGoryExample();
            CateGoryExample.Criteria criteria = cateGoryExample.createCriteria();
            cateGory.setDeleted(true);
            criteria.andIdEqualTo(cateGory.getId());
            int i = cateGoryMapper.updateByExample(cateGory, cateGoryExample);
            if (i==1){
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * 根据类目级别，更新类目信息
     * @param level
     * @param cateGory
     * @return 商品类目
     * @throws CategoryNameRepeatedException
     */
    private CateGory updateCategoryByLevel(String level ,CateGory cateGory) throws CategoryNameRepeatedException {
        Boolean flag = checkRepeatedName(level, cateGory);
        CateGoryExample cateGoryExample = new CateGoryExample();
        CateGoryExample.Criteria criteria = cateGoryExample.createCriteria();
        criteria.andIdEqualTo(cateGory.getId());

        if(flag){
            int i = cateGoryMapper.updateByExample(cateGory, cateGoryExample);
            if(i==1){
                return cateGory;
            }else{
                return null;
            }
        }else {
            throw new CategoryNameRepeatedException();
        }
    }

    /**
     * 判断类目是否重名
     * @param level
     * @param cateGory
     * @return 类目
     * @throws CategoryNameRepeatedException
     */
    private Boolean checkRepeatedName(String level,CateGory cateGory){
        CateGoryExample cateGoryExample = new CateGoryExample();
        CateGoryExample.Criteria criteria = cateGoryExample.createCriteria();
        criteria.andDeletedEqualTo(false);
        criteria.andLevelEqualTo(level);
        criteria.andNameEqualTo(cateGory.getName());
        if(cateGory.getId()!=null){
            criteria.andIdNotEqualTo(cateGory.getId());
        }

        long l = cateGoryMapper.countByExample(cateGoryExample);
        if(l!=0){
            return false;
        }else{
            return true;
        }

        /*if(l!=0){
            throw new CategoryNameRepeatedException();
        }else{
            int insert = cateGoryMapper.insert(cateGory);
            if(insert==1){
                return cateGory;
            }else{
                return null;
            }
        }*/
    }
}
