package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.*;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.UserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/24
 **/
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserMapper userMapper;

    @Autowired
    AddressMapper addressMapper;

    @Autowired
    CollectMapper collectMapper;

    @Autowired
    FootprintMapper footprintMapper;

    @Autowired
    SearchHistoryMapper searchHistoryMapper;

    @Autowired
    FeedbackMapper feedbackMapper;

    @Override
    public ListItem getUserList(PageProperties pageProperties, String username, String mobile) {
        UserExample userExample = new UserExample();
        userExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());

        UserExample.Criteria criteria = userExample.createCriteria();
        if (username != null && !StringUtil.isEmpty(username)) {
            criteria.andUsernameLike("%" + username + "%");
        }
        if (mobile != null && !StringUtil.isEmpty(mobile)) {
            criteria.andMobileLike("%" + mobile + "%");
        }
        criteria.andDeletedEqualTo(false);
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<User> users = userMapper.selectByExample(userExample);
        ListItem<List<User>> listItem = new ListItem();
        listItem.setItems(users);
        listItem.setTotal(userMapper.countByExample(userExample));
        return listItem;
    }

    @Override
    public ListItem<List<Address>> getAddressList(PageProperties pageProperties, Integer userId, String name) {
        AddressExample addressExample = new AddressExample();
        addressExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        AddressExample.Criteria criteria = addressExample.createCriteria();
        if (userId != null && userId != 0) {
            criteria.andUserIdEqualTo(userId);
        }
        if (name != null && !StringUtil.isEmpty(name)) {
            criteria.andNameLike("%" + name + "%");
        }
        criteria.andDeletedEqualTo(false);
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        //  List<Address> addresses = addressMapper.selectByExampleAll(addressExample);
        List<Address> addresses = addressMapper.selectByIdOrName(userId,name);
        ListItem<List<Address>> listItem = new ListItem<>();
        listItem.setItems(addresses);
        listItem.setTotal(addressMapper.countByExample(addressExample));
        return listItem;
    }

    @Override
    public ListItem<List<Collect>> getCollectList(PageProperties pageProperties, Integer userId, Integer valueId) {
        CollectExample collectExample = new CollectExample();
        collectExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());

        CollectExample.Criteria criteria = collectExample.createCriteria();
        if (userId != null && userId != 0) {
            criteria.andUserIdEqualTo(userId);
        }
        if (valueId != null && valueId != 0) {
            criteria.andValueIdEqualTo(valueId);
        }
        criteria.andDeletedEqualTo(false);
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Collect> collects = collectMapper.selectByExample(collectExample);
        ListItem<List<Collect>> listItem = new ListItem<>();
        listItem.setItems(collects);
        listItem.setTotal(collectMapper.countByExample(collectExample));
        return listItem;
    }

    @Override
    public ListItem<List<Footprint>> getFootprintList(PageProperties pageProperties, Integer userId, Integer
            goodsId) {
        FootprintExample footprintExample = new FootprintExample();
        footprintExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        FootprintExample.Criteria criteria = footprintExample.createCriteria();
        if (userId != null && userId != 0) {
            criteria.andUserIdEqualTo(userId);
        }
        if (goodsId != null && goodsId != 0) {
            criteria.andGoodsIdEqualTo(goodsId);
        }

        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Footprint> footprints = footprintMapper.selectByExample(footprintExample);
        ListItem<List<Footprint>> listItem = new ListItem<>();
        listItem.setItems(footprints);
        listItem.setTotal(footprintMapper.countByExample(footprintExample));
        return listItem;

    }

    @Override
    public ListItem<List<SearchHistory>> getHistoryList(PageProperties pageProperties, Integer userId, String
            keyword) {
        SearchHistoryExample searchHistoryExample = new SearchHistoryExample();

        searchHistoryExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());

        SearchHistoryExample.Criteria criteria = searchHistoryExample.createCriteria();


        if (userId != null && userId != 0) {
            criteria.andUserIdEqualTo(userId);
        }
        if (keyword != null && !StringUtil.isEmpty(keyword)) {
            criteria.andKeywordLike("%" + keyword + "%");
        }

        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<SearchHistory> searchHistories = searchHistoryMapper.selectByExample(searchHistoryExample);
        ListItem<List<SearchHistory>> listItem = new ListItem<>();
        listItem.setItems(searchHistories);
        listItem.setTotal(searchHistoryMapper.countByExample(searchHistoryExample));
        return listItem;

    }

    @Override
    public ListItem<List<Feedback>> getFeedbackList(PageProperties pageProperties, String username, Integer id) {
        FeedbackExample feedbackExample = new FeedbackExample();
        feedbackExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        FeedbackExample.Criteria criteria = feedbackExample.createCriteria();
        if (username != null && !StringUtil.isEmpty(username)) {
            criteria.andUsernameLike("%" + username + "%");
        }
        if (id != null && id != 0) {
            criteria.andIdEqualTo(id);
        }

        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Feedback> feedbacks = feedbackMapper.selectByExample(feedbackExample);
        ListItem<List<Feedback>> listItem = new ListItem<>();
        listItem.setItems(feedbacks);
        listItem.setTotal(feedbackMapper.countByExample(feedbackExample));
        return listItem;
    }
}
