package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.Footprint;

import java.util.HashMap;
import java.util.List;

public interface FootprintService {
    /**
     * 分页查询物流信息
     * @param id
     * @param page
     * @param size
     * @return
     */
    HashMap selectFootprint(Integer id, Integer page, Integer size);

    /**
     * 删除足迹
     * 假删除：将delete置为true
     * @param footprintId
     * @return
     */
    Integer deleteFootprint(Integer footprintId);
}
