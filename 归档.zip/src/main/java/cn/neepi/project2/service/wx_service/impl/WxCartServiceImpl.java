package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.*;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.wx_requestModel.WxCartCheckOut;
import cn.neepi.project2.model.wx_responseModel.CartConfirmation;
import cn.neepi.project2.model.wx_responseModel.CartIndex;
import cn.neepi.project2.model.wx_responseModel.CartTotal;
import cn.neepi.project2.service.wx_service.WxCartService;
import cn.neepi.project2.service.wx_service.WxCouponService;
import io.swagger.models.auth.In;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class WxCartServiceImpl implements WxCartService {
    @Autowired
    CartMapper cartMapper;
    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    GoodsProductMapper goodsProductMapper;
    @Autowired
    AddressMapper addressMapper;
    @Autowired
    CouponMapper couponMapper;
    @Autowired
    GrouponMapper grouponMapper;
    @Autowired
    GrouponRulesMapper grouponRulesMapper;
    @Autowired
    WxCouponService wxCouponService;

    /**
     * 根据用户id，deleted为false查询购物车信息
     *
     * @return 购物车信息
     */
    @Override
    public CartIndex getCartIndex() {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();

        CartIndex cartIndex = new CartIndex();

        CartExample cartExample = new CartExample();
        CartExample.Criteria criteria = cartExample.createCriteria();
        criteria.andUserIdEqualTo(user.getId());
        criteria.andDeletedEqualTo(false);
        List<Cart> cartList = cartMapper.selectByExample(cartExample);
        List<Integer> productIdList = new ArrayList<>();
        ArrayList<Integer> productIdListRepeat = new ArrayList<>();

        for (Cart cart : cartList) {
            if(productIdList.contains(cart.getProductId())){
                productIdListRepeat.add(cart.getProductId());
            }
            productIdList.add(cart.getProductId());
        }
        if(productIdListRepeat.size()!=0){
            criteria.andProductIdIn(productIdListRepeat);
            List<Cart> cartListRepeat = cartMapper.selectByExample(cartExample);
            int count = 0;
            short number = 0;
            for (Cart cart : cartListRepeat) {
                if(count<cartListRepeat.size()-1){
                    cart.setDeleted(true);
                    cartMapper.updateByPrimaryKey(cart);
                    number += cart.getNumber();
                    count++;
                }else {
                    number += cart.getNumber();
                    cart.setNumber(number);
                    cartMapper.updateByPrimaryKey(cart);
                }
            }
        }


        /*CartExample cartExample1 = new CartExample();
        CartExample.Criteria criteria1 = cartExample1.createCriteria();
        criteria1.andUserIdEqualTo(user.getId());
        criteria1.andDeletedEqualTo(false);
        List<Cart> cartList1 = cartMapper.selectByExample(cartExample1);*/

        CartTotal cartTotal = getCartTotal(user.getId());
        cartIndex.setCartList(cartList);
        cartIndex.setCartTotal(cartTotal);
        return cartIndex;
    }

    /**
     * 添加商品到购物车,如果规格id相同，直接更新数量；没有规格相同，则新添加一个cart
     *
     * @param cart
     * @return 购物车中deleted为false的商品数目
     */
    @Override
    public Integer addCart(Cart cart) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();

        CartExample cartExample = new CartExample();
        CartExample.Criteria criteria = cartExample.createCriteria();
        criteria.andUserIdEqualTo(user.getId());
        criteria.andDeletedEqualTo(false);
        int number = 0;
        List<Cart> cartList = cartMapper.selectByExample(cartExample);

        boolean flag = false;
        for (Cart cart1 : cartList) {
            number += cart1.getNumber();
            if (cart1.getProductId().equals(cart.getProductId())) {
                number+=cart.getNumber();
                cart1.setNumber((short) (cart1.getNumber().intValue() + cart.getNumber().intValue()));
                cartMapper.updateByPrimaryKey(cart1);
                flag = true;
            }
        }

        if (flag) {
            return number;
        } else {
            cart.setUserId(user.getId());
            Goods goods = goodsMapper.selectByPrimaryKey(cart.getGoodsId());
            cart.setGoodsSn(goods.getGoodsSn());
            cart.setGoodsName(goods.getName());
            cart.setPrice(goods.getRetailPrice());
            GoodsProduct goodsProduct = goodsProductMapper.selectByPrimaryKey(cart.getProductId());
            cart.setSpecifications(goodsProduct.getSpecifications());
            cart.setChecked(true);
            cart.setPicUrl(goods.getPicUrl());
            Date date = new Date();
            cart.setAddTime(date);
            cart.setUpdateTime(date);
            cart.setDeleted(false);
            cartMapper.insert(cart);
            number += cart.getNumber();
            return number;
        }
    }

    /**
     * 选择或取消选择商品，更新购物车信息
     * 更改checked状态
     * 并更改GoodsCount CheckedGoodsCount GoodsAccount CheckedGoodsAccount
     * 更新更新时间
     *
     * @param map
     * @return 购物车列表
     */
    @Override
    public CartIndex checkedCart(Map map) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();

        Integer isChecked = null;
        if (map.containsKey("isChecked")) {
            isChecked = (Integer) map.get("isChecked");
        }
        List<Integer> productIds = null;
        if (map.containsKey("productIds")) {
            productIds = (List<Integer>) map.get("productIds");
        }

        CartTotal cartTotal = getCartTotal(user.getId());

        CartExample cartExample = new CartExample();
        CartExample.Criteria criteria = cartExample.createCriteria();
        criteria.andUserIdEqualTo(user.getId());
        criteria.andDeletedEqualTo(false);
        List<Cart> carts = cartMapper.selectByExample(cartExample);
        Date date = new Date();
        int size = productIds.size();
        if (size == 1) {
            for (Cart cart : carts) {
                if (productIds.contains(cart.getProductId())) {
                    cart.setUpdateTime(date);
                    if (isChecked.equals(1)) {
                        cart.setChecked(true);
                        cartTotal.setCheckedGoodsCount(cart.getNumber() + cartTotal.getCheckedGoodsCount());
                        cartTotal.setCheckedGoodsAmount(BigDecimal.valueOf(cartTotal.getCheckedGoodsAmount().doubleValue() + cart.getNumber() * cart.getPrice().doubleValue()));
                    } else {
                        cart.setChecked(false);
                        cartTotal.setCheckedGoodsCount(cartTotal.getCheckedGoodsCount() - cart.getNumber());
                        cartTotal.setCheckedGoodsAmount(BigDecimal.valueOf(cartTotal.getCheckedGoodsAmount().doubleValue() - cart.getNumber() * cart.getPrice().doubleValue()));
                    }
                    cartMapper.updateByPrimaryKey(cart);
                }
            }
        } else {
            for (Cart cart : carts) {
                if (productIds.contains(cart.getProductId())) {
                    cart.setUpdateTime(date);
                    if (isChecked.equals(1)) {
                        cart.setChecked(true);
                    } else {
                        cart.setChecked(false);
                    }
                    cartMapper.updateByPrimaryKey(cart);
                }
            }
            if (isChecked.equals(1)) {
                cartTotal.setCheckedGoodsCount(cartTotal.getGoodsCount());
                cartTotal.setCheckedGoodsAmount(cartTotal.getGoodsAmount());
            } else {
                cartTotal.setCheckedGoodsCount(0);
                cartTotal.setCheckedGoodsAmount(BigDecimal.valueOf(0));
            }
        }

        CartIndex cartIndex = new CartIndex();
        cartIndex.setCartList(carts);
        cartIndex.setCartTotal(cartTotal);
        return cartIndex;
    }

    /**
     * 根据userID获取商品数目
     *
     * @return 购物车商品数目
     */
    @Override
    public Integer getCartGoodsCount() {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        CartTotal cartTotal = getCartTotal(user.getId());
        Integer goodsCount = cartTotal.getGoodsCount();
        return goodsCount;
    }

    /**
     * 根据userID，cartId更新购物车商品数目,更新updateTime
     *
     * @param cart
     * @return 更新未删除的条目数
     */
    @Override
    public Integer updateCart(Cart cart) {
        Date date = new Date();
        Cart cartOrigin = cartMapper.selectByPrimaryKey(cart.getId());
        cartOrigin.setUpdateTime(date);
        cartOrigin.setNumber(cart.getNumber());

        CartExample cartExample = new CartExample();
        CartExample.Criteria criteria = cartExample.createCriteria();
        criteria.andIdEqualTo(cart.getId());

        int i = cartMapper.updateByExample(cartOrigin, cartExample);
        if (i == 1) {
            return i;
        } else {
            return null;
        }

    }

    /**
     * 根据productList 删除购物车商品
     * 更新cartList : deleted为false，updatetime
     * 更新cartTotal:
     *
     * @param map
     * @return 购物车列表信息
     */
    @Override
    public CartIndex deleteCart(Map map) {
        Date date = new Date();
        CartIndex cartIndex = new CartIndex();
        List<Integer> productList = (List<Integer>) map.get("productIds");

        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();

        CartTotal cartTotal = getCartTotal(user.getId());
        Integer goodsCount = cartTotal.getGoodsCount();
        BigDecimal goodsAmount = cartTotal.getGoodsAmount();
        Integer checkedGoodsCount = cartTotal.getCheckedGoodsCount();
        BigDecimal checkedGoodsAmount = cartTotal.getCheckedGoodsAmount();

        CartExample cartExample = new CartExample();
        CartExample.Criteria criteria = cartExample.createCriteria();
        criteria.andUserIdEqualTo(user.getId());
        criteria.andDeletedEqualTo(false);
        criteria.andProductIdIn(productList);

        List<Cart> carts = cartMapper.selectByExample(cartExample);
        for (Cart cart : carts) {
            cart.setUpdateTime(date);
            cart.setDeleted(true);
            cartMapper.updateByPrimaryKey(cart);
            goodsCount -= cart.getNumber();
            goodsAmount = BigDecimal.valueOf(goodsAmount.doubleValue() - (cart.getPrice().doubleValue() * cart.getNumber().intValue()));
            if (cart.getChecked()) {
                checkedGoodsCount -= cart.getNumber();
                checkedGoodsAmount = BigDecimal.valueOf(checkedGoodsAmount.doubleValue() - cart.getPrice().doubleValue() * cart.getNumber());
            }

        }
        cartTotal.setGoodsCount(goodsCount);
        cartTotal.setGoodsAmount(goodsAmount);
        cartTotal.setCheckedGoodsCount(checkedGoodsCount);
        cartTotal.setCheckedGoodsAmount(checkedGoodsAmount);

        CartExample cartExample1 = new CartExample();
        CartExample.Criteria criteria1 = cartExample1.createCriteria();
        criteria1.andUserIdEqualTo(user.getId());
        criteria1.andDeletedEqualTo(false);
        List<Cart> carts1 = cartMapper.selectByExample(cartExample1);
        cartIndex.setCartList(carts1);
        cartIndex.setCartTotal(cartTotal);
        return cartIndex;
    }

    @Override
    public CartConfirmation checkoutCart(WxCartCheckOut wxCartCheckOut) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();

        //根据 cartID =0和不为0 做不同的处理 为0全选购物车中的checked方法 不为0 只选最新添加的购物车
        //根据 userID 获取购物车信息 deleted为 false checked为true
        CartExample cartExample = new CartExample();
        CartExample.Criteria cartCriteria = cartExample.createCriteria();
        cartCriteria.andUserIdEqualTo(user.getId());
        cartCriteria.andDeletedEqualTo(false);
        cartCriteria.andCheckedEqualTo(true);

        if(!wxCartCheckOut.getCartId().equals(0)){
            cartCriteria.andIdEqualTo(wxCartCheckOut.getCartId());
        }
        List<Cart> cartList = cartMapper.selectByExample(cartExample);
        //根据addressID获取地址
        Address address =null;
        if(wxCartCheckOut.getAddressId().equals(0)){
            AddressExample addressExample = new AddressExample();
            AddressExample.Criteria addressExampleCriteria = addressExample.createCriteria();
            addressExampleCriteria.andUserIdEqualTo(user.getId());
            addressExampleCriteria.andIsDefaultEqualTo(true);
            addressExampleCriteria.andDeletedEqualTo(false);
            List<Address> addresses = addressMapper.selectByExample(addressExample);
            if(addresses!=null&&addresses.size()!=0){
                address =addresses.get(0);
            }

        }else {
            address = addressMapper.selectByPrimaryKey(wxCartCheckOut.getAddressId());
        }


        //根据grouponRulesID 获取团购信息(团购有误）
        BigDecimal grouponRulesDiscount =null;
        if(wxCartCheckOut.getGrouponRulesId().equals(0)){
            grouponRulesDiscount = BigDecimal.valueOf(0);
        }else {
            GrouponRules grouponRules = grouponRulesMapper.selectByPrimaryKey(wxCartCheckOut.getGrouponRulesId());
            grouponRulesDiscount = grouponRules.getDiscount();
        }

        //根据couponId 获取优惠券信息
        BigDecimal couponDiscount =null;
        int couponSize = 0;
        Coupon coupon =null;
        Integer couponId =null;
        if(wxCartCheckOut.getCouponId()==0){

            List couponList = wxCouponService.selectCoupon(wxCartCheckOut.getCartId(), wxCartCheckOut.getCouponId());
            if(couponList!=null &&couponList.size()!=0){
                coupon = (Coupon) couponList.get(0);
                couponDiscount =coupon.getDiscount();
                couponSize = couponList.size();
                couponId=coupon.getId();
            }else{
                couponId=wxCartCheckOut.getCouponId();
                couponDiscount = BigDecimal.valueOf(0);
                couponSize =0;
            }

        }else{
            coupon = couponMapper.selectByPrimaryKey(wxCartCheckOut.getCouponId());
            couponDiscount = coupon.getDiscount();
            List couponList = wxCouponService.selectCoupon(wxCartCheckOut.getCartId(), wxCartCheckOut.getCouponId());
            couponSize = couponList.size();
            couponId =coupon.getId();
        }

        //计算goodsTotalPrice
        BigDecimal checkedGoodsAmount =null;
        double goodsTotalPrice =0;
        if(!wxCartCheckOut.getCartId().equals(0)){
            for (Cart cart : cartList) {
                goodsTotalPrice +=cart.getNumber()*cart.getPrice().doubleValue();
            }
            checkedGoodsAmount = BigDecimal.valueOf(goodsTotalPrice);
        }else{
            CartTotal cartTotal = getCartTotal(user.getId());
            checkedGoodsAmount = cartTotal.getCheckedGoodsAmount();
            goodsTotalPrice = checkedGoodsAmount.doubleValue();
        }

        //计算orderTotalPrice
        BigDecimal orderTotalPrice = BigDecimal.valueOf(goodsTotalPrice-couponDiscount.doubleValue()-grouponRulesDiscount.doubleValue());
        //运费
        BigDecimal freightPrice=null;
        if(goodsTotalPrice>=88){
            freightPrice = BigDecimal.valueOf(0);
        }else {
            freightPrice = BigDecimal.valueOf(10);
        }
        //计算actualPrice
        BigDecimal actualPrice = BigDecimal.valueOf(orderTotalPrice.doubleValue()+freightPrice.doubleValue());
        //cartConfirmation
        CartConfirmation cartConfirmation = new CartConfirmation();

        cartConfirmation.setActualPrice(actualPrice);
        cartConfirmation.setAddressId(address.getId());

        cartConfirmation.setAvailableCouponLength(couponSize);
        cartConfirmation.setCheckedAddress(address);
        cartConfirmation.setCheckedGoodsList(cartList);
        cartConfirmation.setCouponId(couponId);
        cartConfirmation.setCouponPrice(couponDiscount);
        cartConfirmation.setFreightPrice(freightPrice);
        cartConfirmation.setGoodsTotalPrice(checkedGoodsAmount);
        cartConfirmation.setGrouponPrice(grouponRulesDiscount);
        cartConfirmation.setGrouponRulesId(wxCartCheckOut.getGrouponRulesId());
        cartConfirmation.setOrderTotalPrice(orderTotalPrice);
        return cartConfirmation;
    }

    /**
     * 获取新的订单号
     * @param map
     * @return 新的订单号
     */
    @Override
    public Integer fastAddCart(Map map) {
        Integer goodsId = (Integer) map.get("goodsId");
        Short number = Short.valueOf(map.get("number").toString());
        Integer productId = (Integer) map.get("productId");
        Goods goods = goodsMapper.selectByPrimaryKey(goodsId);
        GoodsProduct goodsProduct = goodsProductMapper.selectByPrimaryKey(productId);

        Date date = new Date();
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Cart cart = new Cart();

        cart.setUserId(user.getId());
        cart.setGoodsId(goodsId);
        cart.setGoodsSn(goods.getGoodsSn());
        cart.setGoodsName(goods.getName());
        cart.setProductId(productId);
        cart.setPrice(goodsProduct.getPrice());
        cart.setNumber(number);
        cart.setSpecifications(goodsProduct.getSpecifications());
        cart.setChecked(true);
        cart.setPicUrl(goods.getPicUrl());
        cart.setAddTime(date);
        cart.setUpdateTime(date);
        cart.setDeleted(false);
//如果购物车里存在同规格该商品，没付款则自动加1 false；付款则生成一个cart为true的cartId
        cartMapper.insert(cart);
        Integer id = cart.getId();
        return id;

    }

    /**
     * 根据userID获取cartTotal
     * @param id
     * @return CartTotal
     */
    private CartTotal getCartTotal(Integer id) {

        CartTotal cartTotal = new CartTotal();
        int number = 0;
        int checkedNumber = 0;
        double price = 0;
        double checkedPrice = 0;

        CartExample cartExample = new CartExample();
        CartExample.Criteria criteria = cartExample.createCriteria();
        criteria.andUserIdEqualTo(id);
        criteria.andDeletedEqualTo(false);
        List<Cart> cartList = cartMapper.selectByExample(cartExample);

        for (Cart cart : cartList) {
            number += cart.getNumber();
            price += cart.getPrice().doubleValue() * cart.getNumber();
            if (cart.getChecked() == true) {
                checkedNumber += cart.getNumber();
                checkedPrice += cart.getPrice().doubleValue() * cart.getNumber();
            }
        }
        cartTotal.setGoodsCount(number);
        cartTotal.setCheckedGoodsCount(checkedNumber);
        cartTotal.setGoodsAmount(BigDecimal.valueOf(price));
        cartTotal.setCheckedGoodsAmount(BigDecimal.valueOf(checkedPrice));
        return cartTotal;
    }
}
