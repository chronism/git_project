package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.*;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.ShoppingMallModel.Order;
import cn.neepi.project2.model.responseModel.WxListItem;
import cn.neepi.project2.model.wx_responseModel.GrouponDetail;
import cn.neepi.project2.model.wx_responseModel.GrouponResp;
import cn.neepi.project2.model.wx_responseModel.MyGroupon;
import cn.neepi.project2.model.wx_responseModel.OrderInfoCxs;
import cn.neepi.project2.service.WxOrderService;
import cn.neepi.project2.service.wx_service.WxGrouponService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
public class WxGrouponServiceImpl implements WxGrouponService {

    @Autowired
    GrouponMapper grouponMapper;
    @Autowired
    GrouponRulesMapper grouponRulesMapper;
    @Autowired
    GoodsMapper goodsMapper;
    @Autowired
    OrderMapper orderMapper;
    @Autowired
    OrderGoodsMapper orderGoodsMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    WxOrderService wxOrderService;

    @Override
    public WxListItem getGroupList(Integer page, Integer size) {
        GrouponRulesExample grouponRulesExample = new GrouponRulesExample();
        GrouponRulesExample.Criteria criteria = grouponRulesExample.createCriteria();
        // 未删除 未过期
        criteria.andDeletedEqualTo(false);
        criteria.andExpireTimeGreaterThan(new Date());
        // 分页
        PageHelper.startPage(page, size);
        List<GrouponRules> grouponRules = grouponRulesMapper.selectByExample(grouponRulesExample);
        ArrayList<GrouponResp> grouponResps = new ArrayList<>();
        // 封装成需要的返回值类型
        for (GrouponRules grouponRule : grouponRules) {
            Integer goodsId = grouponRule.getGoodsId();
            Goods goods = goodsMapper.selectByPrimaryKey(goodsId);
            GrouponResp grouponResp = new GrouponResp();
            grouponResp.setGoods(goods);
            grouponResp.setGroupon_member(grouponRule.getDiscountMember());
            grouponResp.setGroupon_price(grouponRule.getDiscount());
            grouponResps.add(grouponResp);
        }
        WxListItem<List<GrouponResp>> listWxListItem = new WxListItem<>();
        listWxListItem.setCount(grouponRulesMapper.countByExample(grouponRulesExample));
        listWxListItem.setData(grouponResps);
        return listWxListItem;
    }

    @Override
    public WxListItem getMyGrouponList(Integer userId, Integer showType) {
        GrouponExample grouponExample = new GrouponExample();
        GrouponExample.Criteria criteria = grouponExample.createCriteria();
        criteria.andDeletedEqualTo(false);
        criteria.andUserIdEqualTo(userId);
        boolean isCreator = false;
        // 0代表是用户创建的
        if (showType == 0) {
            criteria.andCreatorUserIdEqualTo(userId);
            isCreator = true;
        }
        if (showType == 1) {
            criteria.andUserIdNotEqualTo(userId);
            isCreator = false;
        }
        List<Groupon> groupons = grouponMapper.selectByExample(grouponExample);
        // 对每个groupon都需要封装一个Mygroupon
        ArrayList<MyGroupon> myGroupons = new ArrayList<>();
        for (Groupon groupon : groupons) {
            MyGroupon myGroupon = new MyGroupon();
            myGroupon.setGroupon(groupon);
            GrouponRules grouponRules = grouponRulesMapper.selectByPrimaryKey(groupon.getRulesId());
            myGroupon.setRules(grouponRules);
            // 订单有关的状态封装一个方法
            Integer orderId = groupon.getOrderId();
            BigDecimal discount = grouponRules.getDiscount();
            setOrderStatus(myGroupon, groupon, orderId, discount);
            // 设置其他参数
            myGroupon.setId(groupon.getId());
            myGroupon.setIsCreator(isCreator);
            Integer creatorUserId = groupon.getCreatorUserId();
            String nickname = userMapper.selectByPrimaryKey(creatorUserId).getNickname();
            myGroupon.setCreator(nickname);
            String aLong = grouponMapper.countJoiner(creatorUserId, grouponRules.getId()).toString();
            myGroupon.setJoinerCount(Integer.valueOf(aLong));
            // 塞进list
            myGroupons.add(myGroupon);
        }
        WxListItem<List<MyGroupon>> listWxListItem = new WxListItem<>();
        listWxListItem.setData(myGroupons);
        listWxListItem.setCount(grouponMapper.countByExample(grouponExample));
        return listWxListItem;
    }

    @Override
    public GrouponDetail getGrouponDetail(Integer grouponId) {
        GrouponDetail grouponDetail = new GrouponDetail();
        grouponDetail.setLinkGrouponId(grouponId);
        Groupon groupon = grouponMapper.selectByPrimaryKey(grouponId);
        grouponDetail.setGroupon(groupon);
        Integer orderId = groupon.getOrderId();
        // orderGoods
        List<OrderGoods> orderGoods = orderGoodsMapper.selectByOrderId(orderId);
        grouponDetail.setOrderGoods(orderGoods);
        // orderInfo
        Map<String, Object> map = wxOrderService.orderDetail(orderId);
        OrderInfoCxs orderInfo = (OrderInfoCxs) map.get("orderInfo");
        grouponDetail.setOrderInfo(orderInfo);
        // rules
        Integer rulesId = groupon.getRulesId();
        GrouponRules grouponRules = grouponRulesMapper.selectByPrimaryKey(rulesId);
        grouponDetail.setRules(grouponRules);
        // creator
        Integer creatorUserId = groupon.getCreatorUserId();
        User user = userMapper.selectByPrimaryKey(creatorUserId);
        grouponDetail.setCreator(user);
        // joiners
        GrouponExample grouponExample = new GrouponExample();
        GrouponExample.Criteria criteria = grouponExample.createCriteria();
        criteria.andOrderIdEqualTo(orderId);
        criteria.andCreatorUserIdEqualTo(creatorUserId);
        criteria.andRulesIdEqualTo(rulesId);
        List<Groupon> groupons = grouponMapper.selectByExample(grouponExample);
        List<User> joiners = new ArrayList<>();
        for (Groupon groupon1 : groupons) {
            Integer userId = groupon1.getUserId();
            User user1 = userMapper.selectByPrimaryKey(userId);
            joiners.add(user1);
        }
        grouponDetail.setJoiners(joiners);
        return grouponDetail;
    }

    /**
     * 用来封装mygroupon中和订单状态有关对象
     * @param myGroupon
     * @param groupon
     * @param orderId
     * @param discount
     */
    private void setOrderStatus(MyGroupon myGroupon, Groupon groupon, Integer orderId, BigDecimal discount) {
        Order order = orderMapper.selectByPrimaryKey(orderId);
        myGroupon.setOrderId(orderId);
        myGroupon.setOrderSn(order.getOrderSn());
        // 抄的OrderService有关部分
        HashMap<String, Boolean> handleOption = new HashMap<>();
        boolean cancel = false;
        boolean delete = false;
        boolean pay = false;
        boolean comment = false;
        boolean confirm = false;
        boolean refund = false;
        boolean rebuy = false;
        Short orderStatus = order.getOrderStatus();
        //对不同订单状态的订单给予不同订单能点击操作的选项
        // 返回map中含有的orderStatusText
        String orderStatusText = null;
        if (orderStatus == 101) {
            orderStatusText = "未付款";
            cancel = true;
            pay = true;
        } else if (orderStatus == 201 || orderStatus == 202 || orderStatus == 203) {
            orderStatusText = "未发货";  //  【201：已付款 202：申请退款 203：退款中】 其中202、203在分配订单可操作性选项还存疑?
            refund = true;
        } else if (orderStatus == 301) {
            orderStatusText = "未收货";
            confirm = true;
        } else if (orderStatus == 401 || orderStatus == 402) {
            orderStatusText = "已收货";
            delete = true;
            comment = true;
            rebuy = true;
        } else if (orderStatus == 102) {
            orderStatusText = "已取消";
            delete = true;
        } else if (orderStatus == 103) {
            orderStatusText = "已取消(系统)";
            delete = true;
        }
        handleOption.put("cancel", cancel);
        handleOption.put("delete", delete);
        handleOption.put("pay", pay);
        handleOption.put("comment", comment);
        handleOption.put("confirm", confirm);
        handleOption.put("refund", refund);
        handleOption.put("rebuy", rebuy);
        myGroupon.setHandleOption(handleOption);
        myGroupon.setOrderStatusText(orderStatusText);
        //price
        BigDecimal actualPrice = order.getActualPrice();
        myGroupon.setActualPrice(actualPrice.subtract(discount));
        List<OrderGoods> orderGoods = orderGoodsMapper.selectByOrderId(orderId);
        myGroupon.setGoodsList(orderGoods);
    }
}
