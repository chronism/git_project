package cn.neepi.project2.service.wx_service.impl;
import java.util.Date;

import cn.neepi.project2.mapper.CskaoyanMallPhoneCodeMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.CskaoyanMallPhoneCodeExample;
import cn.neepi.project2.model.LoginVo;
import cn.neepi.project2.model.User;
import cn.neepi.project2.model.UserExample;
import cn.neepi.project2.model.wx_requestModel.WxLoginRequest;
import cn.neepi.project2.model.wx_requestModel.WxRegister;
import cn.neepi.project2.model.wx_requestModel.WxUserInfo;
import cn.neepi.project2.service.wx_service.WxAuthService;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
@Service
public class WxAuthServiceImpl implements WxAuthService {
    @Autowired
    UserMapper userMapper;
    @Autowired
    CskaoyanMallPhoneCodeMapper cskaoyanMallPhoneCodeMapper;

    @Override
    public User getUser(LoginVo loginVo) {

        UserExample userExample = new UserExample();
        userExample.createCriteria().andUsernameEqualTo(loginVo.getUsername());
        List<User> users = userMapper.selectByExample(userExample);
        return users.get(0);
    }

    @Override
    public User register(WxRegister wxRegister) {
        CskaoyanMallPhoneCodeExample phoneCodeExample = new CskaoyanMallPhoneCodeExample();
        phoneCodeExample.createCriteria().andPhoneEqualTo(wxRegister.getMobile()).andDeletetimeGreaterThan(new Date()).andCodeEqualTo(wxRegister.getCode());
        long count = cskaoyanMallPhoneCodeMapper.countByExample(phoneCodeExample);
        if (count!=1){
            User user = new User();
            user.setId(-1);
            return user ;
        }
        UserExample userExample = new UserExample();
        userExample.createCriteria().andDeletedEqualTo(false).andUsernameEqualTo(wxRegister.getUsername());
        List<User> users = userMapper.selectByExample(userExample);
        if (users!=null&&users.size()>0){
            User user = new User();
            user.setId(-2);
            return user;
        }
        User user = new User();
        user.setUsername(wxRegister.getUsername());
        user.setPassword(BCrypt.hashpw(wxRegister.getPassword(),BCrypt.gensalt()));
        user.setUserLevel((byte)0);
        user.setGender((byte)0);
        user.setNickname(wxRegister.getUsername());
        user.setMobile(wxRegister.getMobile());
        user.setAvatar("https://oss.aliyuncs.com/aliyun_id_photo_bucket/default_handsome.jpg");
        Date date = new Date();
        user.setStatus((byte)0);
        user.setAddTime(date);
        user.setUpdateTime(date);
        user.setDeleted(false);
        userMapper.insert(user);
        return user;
    }

    @Override
    public User register(WxLoginRequest wx, WxRegister wxRegister) {

        CskaoyanMallPhoneCodeExample phoneCodeExample = new CskaoyanMallPhoneCodeExample();
        phoneCodeExample.createCriteria().andPhoneEqualTo(wxRegister.getMobile()).andDeletetimeGreaterThan(new Date()).andCodeEqualTo(wxRegister.getCode());
        long count = cskaoyanMallPhoneCodeMapper.countByExample(phoneCodeExample);
        if (count!=1){
            return null;
        }
        WxUserInfo userInfo = wx.getUserInfo();
        User user = new User();
        user.setUsername(wxRegister.getUsername());
        user.setPassword(BCrypt.hashpw(wxRegister.getPassword(),BCrypt.gensalt()));
        user.setUserLevel((byte)0);
        user.setNickname(userInfo.getNickName());
        user.setMobile(wxRegister.getMobile());
        user.setAvatar(userInfo.getAvatarUrl());
        Date date = new Date();
        user.setStatus((byte)0);
        user.setWeixinOpenid(userInfo.getAvatarUrl());
        user.setAddTime(date);
        user.setUpdateTime(date);
        user.setDeleted(false);
        userMapper.insert(user);
        return user;
    }
}
