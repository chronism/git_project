package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.CartMapper;
import cn.neepi.project2.mapper.CouponMapper;
import cn.neepi.project2.mapper.CouponUserMapper;
import cn.neepi.project2.mapper.GrouponMapper;
import cn.neepi.project2.model.*;
import cn.neepi.project2.model.responseModel.WxListItem;
import cn.neepi.project2.service.wx_service.WxCouponService;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.lang.System;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class WxCouponServiceImpl implements WxCouponService {
    @Autowired
    CouponUserMapper couponUserMapper;
    @Autowired
    CouponMapper couponMapper;
    @Autowired
    CartMapper cartMapper;
    @Autowired
    GrouponMapper grouponMapper;

    @Override
    public WxListItem queryMyCouponList(int userId, Integer status, Integer page, Integer size) {
        // 通过CouponUserMapper获取这个人对应的 有效 优惠券
        Date date = new Date();
        List<Integer> couponIds = couponUserMapper.selectUsefulCouponByStatus(userId, status);
        if (couponIds.size() == 0) {
            WxListItem wxListItem = new WxListItem();
            wxListItem.setCount(0L);
            wxListItem.setData("");
            return wxListItem;
        }
        // 通过id获得对应优惠券
        CouponExample couponExample = new CouponExample();
        CouponExample.Criteria criteria = couponExample.createCriteria();
        criteria.andIdIn(couponIds);

        criteria.andDeletedEqualTo(false);
        // 分页
        PageHelper.startPage(page, size);
        List<Coupon> coupons = couponMapper.selectByExample(couponExample);
        long total = couponMapper.countByExample(couponExample);
        WxListItem<List<Coupon>> listListItem = new WxListItem<>();
        listListItem.setCount(total);
        listListItem.setData(coupons);
        return listListItem;
    }

    @Override
    public WxListItem queryCouponList(Integer page, Integer size) {
        CouponExample couponExample = new CouponExample();
        CouponExample.Criteria criteria = couponExample.createCriteria();
        criteria.andDeletedEqualTo(false);
        criteria.andTypeEqualTo(0);
        criteria.andStatusEqualTo(0);

        PageHelper.startPage(page, size);
        List<Coupon> coupons = couponMapper.selectByExample(couponExample);
        long count = couponMapper.countByExample(couponExample);
        WxListItem<List<Coupon>> couponListItem = new WxListItem<>();
        couponListItem.setData(coupons);
        couponListItem.setCount(count);
        return couponListItem;
    }

    @Override
    public int receiveCoupon(Integer couponId, Integer userId) {
        Coupon coupon = couponMapper.selectByPrimaryKey(couponId);
        // 判断是否被删除 判断是否过期? 判断是否能领取type,total
        if (coupon.getDeleted() == true || coupon.getType() != 0 || coupon.getStatus() != 0) {
            return 500;
        }
        // 判断是否拥有
        // 获取此用户已有优惠券
        List<Integer> userfulCoupons = couponUserMapper.selectUsefulCoupon(userId);
        if (coupon.getLimit() == 1 && userfulCoupons.contains(couponId)) {
            // 优惠券已经领取过
            return 740;
        }
        // 走到这里说明可以领取
        boolean flag = receive(coupon, userId);
        if (flag) {
            return 1;
        }
        return 400;
    }

    @Override
    public int exchangeCoupon(String code, int userId) {
        // 查找对应能用的优惠券
        CouponExample couponExample = new CouponExample();
        CouponExample.Criteria criteria = couponExample.createCriteria();
        criteria.andStatusEqualTo(0);
        criteria.andTypeEqualTo(2);
        criteria.andCodeEqualTo(code);
        criteria.andDeletedEqualTo(false);
        // ?
        // criteria.andEndTimeGreaterThan(new Date());
        List<Coupon> coupons = couponMapper.selectByExample(couponExample);
        if (coupons.size() == 0) {
            return 742;
        }
        // 理论上一个code对应一个优惠券
        Coupon coupon = coupons.get(0);
        // 判断是否拥有
        // 获取此用户已有优惠券
        List<Integer> userfulCoupons = couponUserMapper.selectUsefulCoupon(userId);
        if (coupon.getLimit() == 1 && userfulCoupons.contains(coupon.getId())) {
            // 优惠券已经领取过
            return 740;
        }
        boolean receive = receive(coupon, userId);
        if (receive) {
            return 1;
        }
        return 400;
    }

    @Override
    public List selectCoupon(Integer cartId, Integer grouponRules) {
        List<Coupon> coupons;
        BigDecimal price = BigDecimal.valueOf(0);
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Integer userId = user.getId();
        if (cartId > 0) {
            Cart cart = cartMapper.selectByPrimaryKey(cartId);
            price = cart.getPrice();
        }
        // 0则查询用户所有选中的购物车
        if (cartId == 0) {
            CartExample cartExample = new CartExample();
            CartExample.Criteria criteria = cartExample.createCriteria();
            criteria.andUserIdEqualTo(userId);
            criteria.andCheckedEqualTo(true);
            criteria.andDeletedEqualTo(false);
            List<Cart> carts = cartMapper.selectByExample(cartExample);
            for (Cart cart : carts) {
                BigDecimal price1 = cart.getPrice();
                int number = cart.getNumber();
                for (int i = 0; i < number-1; i++) {
                    price1 = price1.add(price1);
                }
               price= price.add(price1);
            }
        }
        // 选择优惠券
        // 先找到用户有的优惠券
        List<Integer> couponIds = couponUserMapper.selectUsefulCouponByStatus(userId, 0);
        // 通过id获得对应优惠券
        CouponExample couponExample = new CouponExample();
        CouponExample.Criteria criteria = couponExample.createCriteria();
        criteria.andIdIn(couponIds);
        criteria.andDeletedEqualTo(false);
        criteria.andMinLessThanOrEqualTo(price);
        criteria.andEndTimeGreaterThan(new Date());

        coupons = couponMapper.selectByExample(couponExample);

        return coupons;
    }

    /**
     * 领取优惠券的具体逻辑 内置方法private
     *
     * @param coupon
     * @param userId
     */
    private boolean receive(Coupon coupon, Integer userId) {
        Integer total = coupon.getTotal();
        // total = 0/1/others
        if (total == 1) {
            // 如果优惠券只有一张 领取后把数量设置为-1 同时下架（status=2） 删除的逻辑是后端管理系统做
            coupon.setTotal(-1);
            coupon.setStatus((short) 2);
            couponMapper.updateByPrimaryKey(coupon);
        }
        if (total > 1) {
            coupon.setTotal(total - 1);
            couponMapper.updateByPrimaryKey(coupon);
        }
        // 更新coupon-user表 下面为必须项
        CouponUser couponUser = new CouponUser();
        couponUser.setCouponId(coupon.getId());
        couponUser.setUserId(userId);
        couponUser.setStatus((short) 0);
        Date date = new Date();
        couponUser.setAddTime(date);
        couponUser.setUpdateTime(date);
        couponUser.setDeleted(false);
        // 判断有效期
        Short timeType = coupon.getTimeType();
        if (timeType == 1) {
            couponUser.setStartTime(coupon.getStartTime());
            couponUser.setEndTime(coupon.getEndTime());
        }
        if (timeType == 0) {
            Short days = coupon.getDays();
            // 有效期为现在日期加天数
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, days);
            Date realDate = calendar.getTime();
            couponUser.setStartTime(date);
            couponUser.setEndTime(realDate);
        }
        // 插入表中
        int insert = couponUserMapper.insert(couponUser);
        if (insert == 1) {
            return true;
        }
        return false;
    }

    /**
     * 定时刷新 不知道有没有用
     *
     * @author xcy
     */
    @Scheduled(fixedRate = 60000)
    private void updateCouponStatus() {
        Date date = new Date();
        CouponExample couponExample = new CouponExample();
        CouponExample.Criteria criteria1 = couponExample.createCriteria();
        // 挑出过期且未删除且status为0的项
        criteria1.andDeletedEqualTo(false);
        criteria1.andEndTimeLessThan(date);
        criteria1.andStatusEqualTo(0);
        List<Coupon> coupons = couponMapper.selectByExample(couponExample);
        // 若有 将他们的状态都改为1
        if (coupons.size() != 0) {
            for (Coupon coupon : coupons) {
                coupon.setStatus((short) 1);
                couponMapper.updateByPrimaryKey(coupon);
            }
        }

    }

}
