package cn.neepi.project2.service.impl;

import cn.neepi.project2.mapper.KeywordMapper;
import cn.neepi.project2.model.Keyword;
import cn.neepi.project2.model.KeywordExample;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;
import cn.neepi.project2.service.KeywordService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @author niko
 * @version 1.0
 * @date 19/12/30/030 上午 09:32
 */
@Service
public class KeywordServiceImpl implements KeywordService {
    @Autowired
    KeywordMapper keywordMapper;

    @Override
    public ListItem<List<Keyword>> queryIssues(PageProperties pageProperties, String keyword, String url) {
        ListItem<List<Keyword>> listItem = new ListItem<>();
        KeywordExample issueExample = new KeywordExample();
        KeywordExample.Criteria criteria = issueExample.createCriteria();
        if (keyword != null) {
            criteria.andKeywordLike("%" + keyword + "%");
        }
        if (url != null) {
            criteria.andUrlLike("%" + url + "%");
        }
        criteria.andDeletedEqualTo(false);
        issueExample.setOrderByClause(pageProperties.getSort() + " " + pageProperties.getOrder());
        //分页插件
        PageHelper.startPage(pageProperties.getPage(), pageProperties.getLimit());
        List<Keyword> keywords = keywordMapper.selectByExample(issueExample);

        PageInfo<Keyword> pageInfo = new PageInfo<>(keywords);
        long total = pageInfo.getTotal();
        listItem.setItems(keywords);
        listItem.setTotal(total);
        return listItem;
    }

    @Override
    public boolean createKeyword(Keyword keyword) {
        Date date = new Date();
        keyword.setAddTime(date);
        keyword.setUpdateTime(date);
        keyword.setDeleted(false);
        if (keywordMapper.insertSelective(keyword) == 1) {
            return true;
        } else
            return false;
    }

    @Override
    public boolean updateKeyword(Keyword keyword) {
        keyword.setUpdateTime(new Date());
        if (keywordMapper.updateByPrimaryKeySelective(keyword) == 1) {
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteKeyword(Keyword keyword) {
        keyword.setUpdateTime(new Date());
        keyword.setDeleted(true);
        if (keywordMapper.updateByPrimaryKeySelective(keyword) > 0) {
            return true;
        }
        return false;
    }
}
