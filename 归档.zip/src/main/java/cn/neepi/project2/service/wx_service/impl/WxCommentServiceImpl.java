package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.CommentMapper;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.*;
import cn.neepi.project2.service.wx_service.WxCommentService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


@Service
public class WxCommentServiceImpl implements WxCommentService {

    @Autowired
    CommentMapper commentMapper;

    @Autowired
    UserMapper userMapper;

    /**
     * 发表评论
     * @param comment
     * @return
     */
    @Override
    public Comment postComment(Comment comment) {
        comment.setDeleted(false);
        comment.setAddTime(new Date());
        comment.setUpdateTime(new Date());
        commentMapper.insertSelective(comment);
        return comment;
    }

    /**
     * 显示评论列表
     * @param valueId
     * @param page
     * @param showType
     * @param type
     * @return
     */
    @Override
    public HashMap showCommentList(Integer valueId, Integer page, Integer size, Byte showType, Byte type) {
        CommentExample commentExample = new CommentExample();
        CommentExample.Criteria criteria = commentExample.createCriteria();
        criteria.andTypeEqualTo(type);
        criteria.andDeletedEqualTo(false);
        criteria.andValueIdEqualTo(valueId);
        PageHelper.startPage(page,size);
        List<Comment> comments = commentMapper.selectByExample(commentExample);
        long l = commentMapper.countByExample(commentExample);
        ArrayList<Object> data = new ArrayList<>();
        for (Comment comment : comments) {
            User user = userMapper.selectByPrimaryKey(comment.getUserId());
            UserInfo userInfo = new UserInfo();
            if(user != null ){
                userInfo.setAvatarUrl(user.getAvatar());
                userInfo.setNickName(user.getNickname());
            }
            UserInfoAndTopicComment userInfoAndTopicComment = new UserInfoAndTopicComment();
            userInfoAndTopicComment.setUserInfo(userInfo);
            userInfoAndTopicComment.setAddTime(comment.getAddTime());
            userInfoAndTopicComment.setContent(comment.getContent());
            userInfoAndTopicComment.setPicList(comment.getPicUrls());
            data.add(userInfoAndTopicComment);
        }

        HashMap<Object, Object> map = new HashMap<>();
        map.put("data",data);
        map.put("count",l);
        map.put("currentPage",page);
        return map;
    }

    /**
     * 查询评论总数
     * 总数allCount AND 有图片的总数hasPicCount
     * @param valueId
     * @param type
     * @return
     */
    @Override
    public HashMap getCommentCount(Integer valueId, Byte type) {
        CommentExample commentExample = new CommentExample();
        CommentExample.Criteria criteria = commentExample.createCriteria();
        criteria.andDeletedEqualTo(false);
        criteria.andValueIdEqualTo(valueId);
        criteria.andTypeEqualTo(type);
        long allCount = commentMapper.countByExample(commentExample);
        criteria.andPicUrlsIsNotNull();
        long hasPicCount = commentMapper.countByExample(commentExample);
        HashMap<Object, Object> map = new HashMap<>();
        map.put("hasPicCount",hasPicCount);
        map.put("allCount",allCount);
        return map;
    }
}
