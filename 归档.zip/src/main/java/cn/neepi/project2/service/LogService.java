package cn.neepi.project2.service;

import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;

/**
 * @author heyongbin  xcy
 * @date 2019-12-24   12-27
 * @version V1.0
 **/

public interface LogService {
    /**
     * 增加登录登出日志 此方法未实装
     * @return Integer 返回一个增加记录数
     */
    Integer addLoginOrLogoutLog();

    /**
     * 查找对应的log信息
     * @param pageProperties 分页信息
     * @param name 模糊查找管理员名
     * @return
     */
    ListItem queryLogList(PageProperties pageProperties, String name);
}
