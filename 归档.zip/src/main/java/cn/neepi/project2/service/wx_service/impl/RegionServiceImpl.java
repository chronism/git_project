package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.RegionMapper;
import cn.neepi.project2.model.ShoppingMallModel.Region;
import cn.neepi.project2.service.wx_service.RegionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegionServiceImpl implements RegionService {
    @Autowired
    RegionMapper regionMapper;
    @Override
    public List<Region> selectAllRegionByPid(Integer pid) {
        List<Region> regionList = regionMapper.selectRegionByPid(pid);
        return regionList;
    }
}
