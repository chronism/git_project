package cn.neepi.project2.service;

import cn.neepi.project2.model.Admin;
import cn.neepi.project2.model.LoginVo;
import cn.neepi.project2.model.requestModel.PageProperties;
import cn.neepi.project2.model.responseModel.ListItem;

import java.util.List;

/**
 * @author heyongbin  xcy
 * @date  2019/12/24 12/26
 * @version V1.0
 **/
public interface AdminService {
    /**
     * 用于管理用户登录
     * @param loginVo 登录的账号密码
     * @return Admin 返回一个登录对象用于保存到session
     */
    Admin login(LoginVo loginVo);

    /**
     * 获取所有detele=false的admin 根据传入参数分页
     * @param pageProperties 分页 排序
     * @return AdminList
     */
    ListItem queryAdmin(PageProperties pageProperties, String username);

    /**
     * 创建新admin 并将其返回
     * @param admin
     * @return
     */
    Admin createAdmin(Admin admin);

    /**
     * 更新admin 将其返回
     * @param admin
     * @return
     */
    Admin updateAdmin(Admin admin);

    /**
     * 删除admin delete改为true
     * @param admin
     * @return
     */
    Integer deleteAdmin(Admin admin);

    /**
     * 获取用户权限
     * @param admin
     * @return
     */
    List<String> getPermissions(Admin admin);

    List<String> getRoles(Admin admin);

    void changePassword(String newPassword, Admin admin);
}

