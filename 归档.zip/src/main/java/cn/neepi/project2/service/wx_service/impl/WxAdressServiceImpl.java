package cn.neepi.project2.service.wx_service.impl;

import cn.neepi.project2.mapper.AddressMapper;
import cn.neepi.project2.mapper.RegionMapper;
import cn.neepi.project2.model.Address;
import cn.neepi.project2.model.AddressExample;
import cn.neepi.project2.model.Address_liuyu;
import cn.neepi.project2.model.ShoppingMallModel.Region;
import cn.neepi.project2.service.wx_service.WxAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class WxAdressServiceImpl implements WxAddressService {
    @Autowired
    AddressMapper addressMapper;
    @Autowired
    RegionMapper regionMapper;
    /**
     * 查询并组装用户地址信息 返回地址列表
     * @return
     * @param id
     */
    @Override
    public List<Address_liuyu> selectAllAdressByUserId(Integer id) {
        //查出用户的地址信息
        AddressExample addressExample = new AddressExample();
        AddressExample.Criteria criteria = addressExample.createCriteria();
        criteria.andDeletedEqualTo(false);
        criteria.andUserIdEqualTo(id);
        addressExample.setOrderByClause("is_default desc");
        List<Address> addresses = addressMapper.selectByExample(addressExample);
        //数据拼装
        ArrayList<Address_liuyu> address_liuyus = new ArrayList<>();
        for (Address address : addresses) {
            Address_liuyu address_liuyu = new Address_liuyu();
            String province = regionMapper.selectLocalNameById(address.getProvinceId());
            String city = regionMapper.selectLocalNameById(address.getCityId());
            String area = regionMapper.selectLocalNameById(address.getAreaId());
            address_liuyu.setDetailedAddress(province+city+area+address.getAddress());
            address_liuyu.setId(address.getId());
            address_liuyu.setIsDefault(address.getIsDefault());
            address_liuyu.setMobile(address.getMobile());
            address_liuyu.setName(address.getName());
            address_liuyus.add(address_liuyu);
        }
        return address_liuyus;
    }

    /**
     * 查询地址详情
     * @param id
     * @return
     */
    @Override
    public Address selectAddressById(Integer id) {
        Address address = addressMapper.selectByPrimaryKey(id);
        String province = regionMapper.selectLocalNameById(address.getProvinceId());
        String city = regionMapper.selectLocalNameById(address.getCityId());
        String area = regionMapper.selectLocalNameById(address.getAreaId());
        address.setProvinceName(province);
        address.setCityName(city);
        address.setAreaName(area);
        return address;
    }

    /**
     * 新建地址
     * 将原地址置为不可见
     * @param address
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer updateAddress(Address address) {
        address.setUpdateTime(new Date());
        address.setAddTime(new Date());
        address.setDeleted(true);
        addressMapper.updateAddress(address);
        if(address.getIsDefault()) {
            addressMapper.updateAllAddressIsNotDefault();
        }
        address.setId(null);
        address.setDeleted(false);
        Integer i = addressMapper.insert(address);

        return i;
    }

    /**
     * 删除地址
     * 将地址的 deleted 属性置为true
     * 若该地址为默认地址，则设置最新的、未删除的、其他地址为默认地址
     * @param id,userId
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Integer deleteAddress(Integer id, Integer userId) {
        Address address = addressMapper.selectByPrimaryKey(id);
        if (address.getIsDefault()) {
            addressMapper.updateNewstAddressIsDefaule(id);
        }
        address.setDeleted(true);
        address.setUpdateTime(new Date());
        Integer i = addressMapper.updateAddress(address);
        return i;
    }

}
