package cn.neepi.project2.service.wx_service;

import cn.neepi.project2.model.ShoppingMallModel.Brand;

import java.util.List;
import java.util.Map;

/**
 * @author heyongbin
 * @version V1.0
 * @date 2019/12/30
 **/
public interface WxBrandService {

    Brand getBrandDetail(Integer brandId);

    Map getBrandList(Integer page, Integer size);
}
