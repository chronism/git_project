package cn.neepi.project2.exception.shoppingMallException;

public class ManufacturerRepeatedException extends Exception {
    String repeatedMessage;

    public ManufacturerRepeatedException() {
    }

    public String getRepeatedMessage() {
        return repeatedMessage;
    }

    public void setRepeatedMessage(String repeatedMessage) {
        this.repeatedMessage = repeatedMessage;
    }

    public ManufacturerRepeatedException(String repeatedMessage) {
        this.repeatedMessage = repeatedMessage;
    }

    public ManufacturerRepeatedException(String message, String repeatedMessage) {
        super(message);
        this.repeatedMessage = repeatedMessage;
    }
}
