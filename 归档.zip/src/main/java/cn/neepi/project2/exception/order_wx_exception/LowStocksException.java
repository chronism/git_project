package cn.neepi.project2.exception.order_wx_exception;

/**
 * @author niko
 * @version 1.0
 * @date 20/01/1/001 下午 04:36
 */
public class LowStocksException extends Exception {
    String exceptionMessage;

    public LowStocksException(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    public LowStocksException(String message, String exceptionMessage) {
        super(message);
        this.exceptionMessage = exceptionMessage;
    }

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }
}
