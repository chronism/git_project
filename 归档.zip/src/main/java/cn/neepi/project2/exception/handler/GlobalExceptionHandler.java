package cn.neepi.project2.exception.handler;

import cn.neepi.project2.exception.order_wx_exception.LowStocksException;
import cn.neepi.project2.exception.shoppingMallException.CategoryChangeInvalidException;
import cn.neepi.project2.exception.shoppingMallException.CategoryNameRepeatedException;
import cn.neepi.project2.exception.shoppingMallException.ManufacturerRepeatedException;
import cn.neepi.project2.model.CodeMsg;
import cn.neepi.project2.model.Result;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

/**
 * @ClassName GlobalExceptionHandler
 * @Description: TODO
 * @Author heyongbin
 * @Date 2019-12-22
 * @Version V1.0
 **/
@ResponseBody
@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(value = Exception.class)
    public Result<String> exceptionHandler(HttpServletRequest request, Exception e) {
        e.printStackTrace();
        //对于自定义异常的处理
        /*if(e instanceof GlobalException) {
            GlobalException ex = (GlobalException)e;
            return Result.error(ex.getCm());
            //对于绑定异常的处理，使用jsr303中的自定义注解抛出的异常属于绑定异常
        }else*/
        if (e instanceof BindException) {
            BindException ex = (BindException) e;
            List<ObjectError> errors = ex.getAllErrors();
            ObjectError error = errors.get(0);
            String msg = error.getDefaultMessage();
            return Result.error(CodeMsg.BIND_ERROR.fillArgs(msg));
        }else {
            return Result.error(CodeMsg.SERVER_ERROR);
        }

    }

    /**
     * @author xcy
     * 参数校验异常的校验
     */
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public Result methodArgumentNotValidException(MethodArgumentNotValidException e) {
        String defaultMessage = e.getBindingResult().getFieldError().getDefaultMessage();
        switch (defaultMessage) {
            case "601.admin.name":
                return Result.error(CodeMsg.ADMIN_NAME_ERROR);
            case "602.admin.pwd":
                return Result.error(CodeMsg.ADMIN_PASSWORD_SHORT);
            case "601.role.name":
                return Result.error(CodeMsg.ROLE_NAME_ERROR);
            case "401.brand.name":
                return Result.error(CodeMsg.Brand_NAME_ERROR);
            case "401.brand.desc":
                return Result.error(CodeMsg.Brand_DESC_ERROR);
            case "401.brand.picUrl":
                return Result.error(CodeMsg.Brand_PICURL_ERROR);
            case "401.brand.floorPrice":
                return Result.error(CodeMsg.Brand_FLOORPRICE_ERROR);
            case "402.order.comment":
            case "402.order.unpaid":
            case "402.order.unconfirm":
            case "402.wx.index.new":
            case "402.wx.catlog.goods":
            case "402.wx.catlog.list":
            case "402.wx.index.brand":
            case "402.wx.index.hot":
            case "402.wx.index.topic":
            case "402.express.freight.min":
            case "402.express.freight.value":
                return Result.error(CodeMsg.NOT_POSITIVE_INTEGER);
            case "402.categoryId":
                return Result.error(CodeMsg.CATEGORYID_NOTNULL);
            case "402.brandId":
                return Result.error(CodeMsg.BRANDID_NOTNULL);
            case "402.mall.mall.phone":
                return Result.error(CodeMsg.NOT_PHONE);
            case "402.mall.mall.qq":
                return Result.error(CodeMsg.NOT_QQ);
            case "402.category.name":
                return Result.error(CodeMsg.CATEGORY_NAME_ERROR);
            case "402.category.keywords":
                return Result.error(CodeMsg.CATEGORY_KEYWORDS_ERROR);
            case "402.category.desc":
                return Result.error(CodeMsg.CATEGORY_DESC_ERROR);
            case "402.category.iconUrl":
                return Result.error(CodeMsg.CATEGORY_ICONURL_ERROR);
            case "402.category.picUrl":
                return Result.error(CodeMsg.CATEGORY_PICURL_ERROR);
            case "402.category.pid":
                return Result.error(CodeMsg.CATEGORY_PID_ERROR);
            default:
                return Result.error(CodeMsg.SERVER_ERROR);
        }
    }


    public Result<String> ioExceptionHandler(IOException e) {
        return new Result<>(602, "图片上传异常");
    }


    /**
     * 制造商名字重复
     * @author lxt
     * @param e
     * @return
     */
    @ExceptionHandler(value = ManufacturerRepeatedException.class)
    public Result<String> manufacturerRepeatedExceptionHandler(ManufacturerRepeatedException e){
        return new Result<>(402, "制造商名字已注册");
    }

    @ExceptionHandler(value = CategoryNameRepeatedException.class)
    public Result<String> categoryNameRepeatedExceptionHandler(CategoryNameRepeatedException e){
        return new Result<>(402, "商品类目名已注册");
    }

    @ExceptionHandler(value = CategoryChangeInvalidException.class)
    public Result<String> categoryChangeInvalidExceptionHandler(CategoryChangeInvalidException e){
        String exceptionMessage = e.getExceptionMessage();
        switch (exceptionMessage){
            case "402.category.invalid1":
                return new Result<>(402,"该类目含有二级类目不可以变更为二级类目");
            case "402.category.invalid2":
                return new Result<>(402,"该类目不可以变更为本身类目的二级类目");
            default:
                return new Result<>(402, "商品类目变更异常");
        }
    }
    @ExceptionHandler(value = HttpMessageNotReadableException.class)
    public Result<String> invalidFormatExceptionHandler(HttpMessageNotReadableException e){
        return new Result<>(402, "参数异常，请检查参数是否合法");
    }

    /**
     * 付款前prepay时订单中有商品库存不足
     * @author cxs
     * @param e
     * @return
     */
    @ExceptionHandler(value = LowStocksException.class)
    public Result LowStocksExceptionHandler(LowStocksException e){
        return Result.error(CodeMsg.LOW_STOCKS);
    }

    @ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
    public Result<String> methodArgumentTypeMismatchException() {
        return new Result<>(402, "参数异常");
    }

}
