package cn.neepi.project2.exception.shoppingMallException;

public class CategoryChangeInvalidException extends Exception {
    String exceptionMessage;

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    public CategoryChangeInvalidException(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    public CategoryChangeInvalidException() {
    }

    public CategoryChangeInvalidException(String message, String exceptionMessage) {
        super(message);
        this.exceptionMessage = exceptionMessage;
    }
}
