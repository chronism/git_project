package cn.neepi.project2.exception.shoppingMallException;

public class CategoryNameRepeatedException extends Exception {
    String repeatedMessage;

    public CategoryNameRepeatedException() {
    }

    public String getRepeatedMessage() {
        return repeatedMessage;
    }

    public void setRepeatedMessage(String repeatedMessage) {
        this.repeatedMessage = repeatedMessage;
    }

    public CategoryNameRepeatedException(String repeatedMessage) {
        this.repeatedMessage = repeatedMessage;
    }

    public CategoryNameRepeatedException(String message, String repeatedMessage) {
        super(message);
        this.repeatedMessage = repeatedMessage;
    }
}
