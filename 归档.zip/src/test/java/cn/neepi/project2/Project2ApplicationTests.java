package cn.neepi.project2;


import cn.neepi.project2.config.AliyunConfig;
import cn.neepi.project2.mapper.UserMapper;
import cn.neepi.project2.model.User;
import org.junit.jupiter.api.Test;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

@SpringBootTest
class Project2ApplicationTests {
    @Autowired
    AliyunConfig aliyunConfig;
    @Autowired
    UserMapper userMapper;
    @Test
    void contextLoads() {

    }
    @Test
    void md5() throws Exception {
        String password="123";
        String hashpw = BCrypt.hashpw(password, BCrypt.gensalt());
        System.out.println("hashpw = " + hashpw);
		System.out.println("hashpw1 = " + hashpw);
        String accessKeyId = aliyunConfig.getAccessKeyId();
        User user = userMapper.selectByPrimaryKey(1);
        System.out.println(user);

    }

}
